package com.deepcode.farmnet.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentTransaction;

import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.core.FarmNetStatic;
import com.deepcode.farmnet.farmnet_interface.UpdateInterface;

public class HomeFragment extends BaseFragment implements UpdateInterface
{
    @Override
    public void constructorView()
    {

    }

    @Override
    public void setOnClick()
    {

    }

    @Override
    public void loadDateView()
    {

    }
    RelativeLayout btnShoppingCart;

    RelativeLayout btnChat;

    RelativeLayout relativeSearch;

    TextView tvCountCart;
    TextView tvCountMessage;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //
    super.onCreateView(inflater,container,savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        relativeSearch = (RelativeLayout)view.findViewById(R.id.relative_search);
        btnShoppingCart = (RelativeLayout)view.findViewById(R.id.r_shoppingcar);

        btnChat = (RelativeLayout)view.findViewById(R.id.r_r);

        tvCountCart = (TextView)view.findViewById(R.id.tvCountCart);
        tvCountMessage = (TextView)view.findViewById(R.id.tvCountMessage);
        btnChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                MainActivity mainActivity = (MainActivity)getActivity();
                mainActivity.showTabChat();

               // FarmNetStatic.getInstance().setAccount(account);

                //  Fragment chatFragment = (Fragment)findViewById(R.id.chat_fragment);

                ChatFragment fragment = (ChatFragment)getActivity().getSupportFragmentManager().findFragmentById(R.id.chat_fragment);
                fragment.refresh();



            }
        });

        btnShoppingCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                MainActivity mainActivity = (MainActivity)getActivity();
                mainActivity.showTabOrder();

                ListOrderFragment fragment = (ListOrderFragment)getActivity().getSupportFragmentManager().findFragmentById(R.id.order_fragment);
                fragment.refresh();

               // FragmentTransaction ft = getFragmentManager().beginTransaction();
               // ft.replace(R.id.order_fragment,new ListOrderFragment()).addToBackStack("").commit();

            }
        });

        relativeSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                MainActivity mainActivity = (MainActivity)getActivity();
                mainActivity.showTabSearch();

            }
        });

        return view;

    }


    @Override
    public void updateCountCart() {

        tvCountCart.setText(FarmNetStatic.getInstance().getSizeCart()+"");
    }

    @Override
    public void updateCountMessage() {
        tvCountMessage.setText(FarmNetStatic.getInstance().getSizeMassage()+"");

    }
}
