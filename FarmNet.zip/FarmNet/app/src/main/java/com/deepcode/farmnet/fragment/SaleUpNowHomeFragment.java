package com.deepcode.farmnet.fragment;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.adapter.MediumSaleHomeAdapter;
import com.deepcode.farmnet.adapter.SaleUpNowHomeAdapter;
import com.deepcode.farmnet.bean.TopProduct;
import com.deepcode.farmnet.core.Connector;
import com.deepcode.farmnet.core.ImageUtil;
import com.deepcode.farmnet.request.TopRequest;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SaleUpNowHomeFragment extends BaseFragment {
    @Override
    public void constructorView() {

    }

    @Override
    public void setOnClick() {

    }

    @Override
    public void loadDateView() {

    }

    ImageView imageView1;
    ImageView imageView2;
    ImageView imageView3;
    SaleUpNowHomeAdapter saleUpNowHomeAdapter;
    RecyclerView recyclerView;
    List<TopProduct> topProductList = new ArrayList<>();
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
         super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_home_saleup_now, container, false);
      //  imageView1 = (ImageView)view.findViewById(R.id.imgIcon1);
        recyclerView = (RecyclerView)view.findViewById(R.id.rcv_saleUpHome);

//        imageView2 = (ImageView)view.findViewById(R.id.imgIcon2);
//        imageView3 = (ImageView)view.findViewById(R.id.imgIcon3);

//        imageView1 = (ImageView)view.findViewById(R.id.imgIcon1);
//        imageView2 = (ImageView)view.findViewById(R.id.imgIcon2);
//        imageView3 = (ImageView)view.findViewById(R.id.imgIcon3);


//        LinearLayout sale1;
//        sale1 = view.findViewById(R.id.ln_saleupnow1);
      // sale2 = view.findViewById(R.id.ln_saleupnow2);
     //   sale3 = view.findViewById(R.id.ln_saleupnow3);

//        sale1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                TopProduct topProduct = topProductList.get(0);
//               // MainActivity.showTabProductDetail();
//
//                if(topProduct.isCombo())
//                {
//                    // if topproduct is a combo .. go to combo fragment
//                    MainActivity.showTabCombo();
//                    ComboDetailFragment.getInstance().refresh(topProduct.getProductId());
//                }else {
//                    // go to product fragment
//                    MainActivity.showTabProductDetail();
//                    System.out.println("PPPPPPPPP");
//                    ProductDetailFragment.getInstance().refresh(topProduct.getProductId());
//                }
//            }
//        });



//        sale2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                TopProduct topProduct = topProductList.get(1);
//
//               // MainActivity.showTabProductDetail();
//                if(topProduct.isCombo())
//                {
//                    // if topproduct is a combo .. go to combo fragment
//                    MainActivity.showTabCombo();
//                    ComboDetailFragment.getInstance().refresh(topProduct.getProductId());
//                }else {
//                    // go to product fragment
//                    MainActivity.showTabProductDetail();
//                    System.out.println("PPPPPPPPP");
//                    ProductDetailFragment.getInstance().refresh(topProduct.getProductId());
//                }
//            }
//        });
//        sale3.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                MainActivity.showTabProductDetail();
//                TopProduct topProduct = topProductList.get(2);
//
//                if(topProduct.isCombo())
//                {
//                    // if topproduct is a combo .. go to combo fragment
//                    MainActivity.showTabCombo();
//                    ComboDetailFragment.getInstance().refresh(topProduct.getProductId());
//                }else {
//                    // go to product fragment
//                    MainActivity.showTabProductDetail();
//                    System.out.println("PPPPPPPPP");
//                    ProductDetailFragment.getInstance().refresh(topProduct.getProductId());
//                }
//
//            }
//        });

        new LoadDataAsyncTask().execute();

        return  view;
    }

    class  LoadDataAsyncTask extends AsyncTask {
        String url = Connector.rootURL+ "topproduct/SearchByTypeOnMobile";
        String responseString = null;
        Gson gson = new Gson();
        TopRequest topRequest = new TopRequest();

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            topRequest.setType(7);
        }

        @Override
        protected Object doInBackground(Object[] objects) {
            try
            {
                responseString = Connector.doPostRequest(url,gson.toJson(topRequest));


            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            Gson gson = new Gson();
            TypeToken<List<TopProduct>> token = new TypeToken<List<TopProduct>>() {};
            topProductList = gson.fromJson(responseString, token.getType());
            saleUpNowHomeAdapter = new SaleUpNowHomeAdapter(topProductList);
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
            recyclerView.setLayoutManager(linearLayoutManager);
            recyclerView.setAdapter(saleUpNowHomeAdapter);

            //            boolean check1 = false;
//            boolean check2 = false;
//            boolean check3 = false;
//
//            for(TopProduct topProduct: topProductList)
//            {
//
//                System.out.println("Category:"+ topProduct.getProductName());
//                if(!check1)
//                {
//                    imageView1.setImageBitmap(ImageUtil.bitmapFromBase64(topProduct.getImage()));
//
//                    check1 = true;
//                    continue;
//                }
//                if(!check2)
//                {
//                    imageView2.setImageBitmap(ImageUtil.bitmapFromBase64(topProduct.getImage()));
//
//                    check2 = true;
//                    continue;
//                }
//
//                if(!check3)
//                {
//                    imageView3.setImageBitmap(ImageUtil.bitmapFromBase64(topProduct.getImage()));
//
//                    check3 = true;
//                }
//            }
        }
    }

}
