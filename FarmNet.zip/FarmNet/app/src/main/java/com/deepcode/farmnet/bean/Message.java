package com.deepcode.farmnet.bean;

import java.util.Date;

public class Message {
    private String sendName;
    private String recieveName;
    private long _id;
    private String deviceId;
    private long sendId;
    private long recieveId;

    private String msg;
    private Date createdDate;
    private boolean delete;

    @Override
    public String toString() {
        return "Message{" +
                "sendName='" + sendName + '\'' +
                ", recieveName='" + recieveName + '\'' +
                ", messageID=" + _id +
                ", deviceId='" + deviceId + '\'' +
                ", sendId=" + sendId +
                ", recieveId=" + recieveId +
                ", msg='" + msg + '\'' +
                ", createdDate=" + createdDate +
                ", delete=" + delete +
                '}';
    }

    public void setRecieveName(String recieveName) {
        this.recieveName = recieveName;
    }

    public long getMessageID() {
        return _id;
    }

    public void setMessageID(long messageID) {
        this._id = messageID;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public long getSendId() {
        return sendId;
    }

    public void setSendId(long sendId) {
        this.sendId = sendId;
    }

    public long getRecieveId() {
        return recieveId;
    }

    public void setRecieveId(long recieveId) {
        this.recieveId = recieveId;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public boolean isDelete() {
        return delete;
    }

    public void setDelete(boolean delete) {
        this.delete = delete;
    }

    public void setSendName(String sendName) {
        this.sendName = sendName;
    }

    public String getSendName() {
        return sendName;
    }

    public String getRecieveName() {
        return recieveName;
    }
}
