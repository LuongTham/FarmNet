package com.deepcode.farmnet.adapter;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.bean.TopProduct;
import com.deepcode.farmnet.core.ImageUtil;
import com.deepcode.farmnet.fragment.ProductDetailFragment;
import com.deepcode.farmnet.model.ProductModel;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class HeaderHomeAdapter extends RecyclerView.Adapter<HeaderHomeAdapter.RecyclerViewHolder>
{
    List<TopProduct> topProductList;
    public HeaderHomeAdapter(List<TopProduct> topProductList)
    {
        this.topProductList = topProductList;
    }
    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.home_header_cell, parent, false);
        return new RecyclerViewHolder(view);    }
    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position)
    {
       // ProductModel productModel = listProduct.get(position);

        //        holder.txtUserName.setText(data.get(position));
        final TopProduct topProduct = topProductList.get(position);
        holder.txtDescription.setText(topProduct.getDesc());
       // holder.txtProductName.setText(topProduct.getProductName()+"-"+ topProduct.getPrice());
        holder.txtFarm.setText(topProduct.getFarmName());
        holder.imageView.setImageBitmap(ImageUtil.bitmapFromBase64(topProduct.getImage()));
        String colors = topProduct.getColor();
        String[] arrayColor = colors.split("-");
        holder.imageView.setBorderColor(Color.RED);
        holder.relativeLayout.setBackground(ImageUtil.getGradientRectangleColor(arrayColor[0], arrayColor[1]));



        holder.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

        if(topProduct.isCombo())
        { // if topproduct is a combo .. go to combo fragment

        MainActivity.showTabCombo();

        }else {
            // go to product fragment
            //MainActivity mainActivity = (MainActivity) contex;
            MainActivity.showTabProductDetail();

        } }
        });
        holder.relativeLayoutBorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                }
        });


    }
    @Override
    public int getItemCount()
    {
        return topProductList.size();
    }
    public class RecyclerViewHolder extends RecyclerView.ViewHolder
    {
        TextView txtDescription;
        TextView txtFarm;
        TextView txtProductName;
        CircleImageView imageView;

        RelativeLayout relativeLayout;

        RelativeLayout relativeLayoutBorder;

        public RecyclerViewHolder(View itemView)
        {
            super(itemView);
            relativeLayoutBorder = (RelativeLayout)itemView.findViewById(R.id.r_border) ;

            relativeLayout = (RelativeLayout)itemView.findViewById(R.id.r_bounder) ;
            txtDescription = (TextView)itemView.findViewById(R.id.tvDescription);
            txtFarm = (TextView)itemView.findViewById(R.id.tvFarm);
            txtProductName = (TextView)itemView.findViewById(R.id.tvProductName);
            imageView = (CircleImageView) itemView.findViewById(R.id.imgProduct);


           // txtUserName = (TextView) itemView.findViewById(R.id.user_name);
        }
    }
}
