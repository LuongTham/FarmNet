package com.deepcode.farmnet.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.adapter.NotificationAdapter;
import com.deepcode.farmnet.adapter.OrderAdapter;
import com.deepcode.farmnet.model.NotificationModel;
import com.deepcode.farmnet.model.Order;
import com.deepcode.farmnet.model.OrderStatus;
import com.deepcode.farmnet.model.ProductMoreOrder;
import com.deepcode.farmnet.model.UpdateOrder;

import java.util.ArrayList;
import java.util.List;

public class NotificationFragment extends BaseFragment
{

    @Override
    public void constructorView()
    {


    }

    @Override
    public void setOnClick()
    {

    }

    @Override
    public void loadDateView()
    {
    }


    public List<NotificationModel> notificationModelList = new ArrayList<>();
    public List<OrderStatus> orderStatusList= new ArrayList<>();
    public List<UpdateOrder> updateOrderList= new ArrayList<>();
    public void getData()
    {
        for(int i = 0;i<4;i++)
        {
            notificationModelList.add(new NotificationModel());

        }
        orderStatusList.add(new OrderStatus());

        for (int i = 0;i<10;i++)
        {
            updateOrderList.add(new UpdateOrder());

        }
    }
    NotificationAdapter notificationAdapter;
    RecyclerView recyclerView;
    RelativeLayout btnChat;
    RelativeLayout btnShoppingCart;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        super.onCreateView(inflater,container,savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_notification, container, false);
        getData();

        recyclerView = (RecyclerView)view.findViewById(R.id.recyclerViewNotification);
        notificationAdapter = new NotificationAdapter(notificationModelList,updateOrderList, orderStatusList);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(notificationAdapter);

        btnChat = (RelativeLayout)view.findViewById(R.id.r_r);

        btnChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity mainActivity = (MainActivity)getActivity();
                mainActivity.showTabChat();
            }
        });
        btnShoppingCart = (RelativeLayout)view.findViewById(R.id.r_shoppingcar);
        btnShoppingCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                MainActivity mainActivity = (MainActivity)getActivity();
                mainActivity.showTabOrder();

                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.order_fragment,new ListOrderFragment()).addToBackStack("").commit();

            }
        });

        return view;    }
}
