package com.deepcode.farmnet.fragment;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.adapter.ListMessageAdapter;
import com.deepcode.farmnet.bean.Message;
import com.deepcode.farmnet.core.Connector;
import com.deepcode.farmnet.core.FarmNetStatic;
import com.deepcode.farmnet.core.URL_FarmNet;
import com.deepcode.farmnet.request.GetMessageId;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;

public class ChatFragment extends  BaseFragment
{
    public static ChatFragment instance  = null;

    public static ChatFragment getInstance() {
        if (instance == null) {
            instance = new ChatFragment();
        }
        return instance;
    }
    public  void refresh()
    {


        new AsyncTaskGetMessage().execute();
    }

    @Override
    public void constructorView() {

    }

    @Override
    public void setOnClick() {

    }

    @Override
    public void loadDateView() {

    }
    RecyclerView recyclerView;
    ListMessageAdapter listMessageAdapter;
    List<Message> listMessage = new ArrayList<Message>();


    public class AsyncTaskGetMessage extends AsyncTask<Void, Void, Void>
    {
        String responseString = null;
        Gson gson = new Gson();
        GetMessageId getMessageId = new GetMessageId();

        @Override
        protected void onPreExecute() {

            try{
                getMessageId.setRecieveId(FarmNetStatic.getInstance().getAccount().getAccountID());
                getMessageId.setSendId(0);

                System.out.println("Message:"+ getMessageId.toString());
            }catch (Exception ex)
            {

            }
            System.out.println("GETMESS:"+ getMessageId.toString());
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... voids) {

            try {
                responseString =  Connector.doPostRequest(Connector.rootURL+ URL_FarmNet.url_getMessage
                        ,gson.toJson(getMessageId));

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            try{

                System.out.println("AAAA"+responseString);
                TypeToken<List<Message>> token = new TypeToken<List<Message>>() {};
                listMessage = gson.fromJson(responseString, token.getType());

                if(listMessage!= null)
                {
                    listMessageAdapter = new ListMessageAdapter(listMessage);
                }else
                {

                    listMessage = new ArrayList<>();
                    listMessageAdapter = new ListMessageAdapter(listMessage);

                }
                recyclerView.setAdapter(listMessageAdapter);


            }catch (Exception ex){

            }

            try{
                if(listMessageAdapter.getItemCount()>0)
                {
                    recyclerView.scrollToPosition(listMessageAdapter.getItemCount()-1);
                }
            }catch (Exception xe){
            }

            int sizeMessage = listMessage.size();

            FarmNetStatic.getInstance().setSizeMassage(sizeMessage);

            updateCountMessage();
        }
    }

    public   void  updateCountMessage()
    {
        HomeFragment fragment = (HomeFragment) getActivity().getSupportFragmentManager().findFragmentById(R.id.home_fragment);
        fragment.updateCountMessage();

    }


    public class AsyncTaskSendMessage extends AsyncTask<Void, Void,Void>
    {
        String responseString = null;
        Gson gson = new Gson();
        Message message = new Message();
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            message.setMessageID(1);
          //  message.setCreatedDate(new Date());
            message.setDelete(false);
            message.setRecieveId(0);
            message.setSendId(FarmNetStatic.getInstance().getAccount().getAccountID());
            message.setMsg(txt_sendMsg.getText().toString());
            message.setSendName("Me");
            message.setRecieveName("Admin");
            message.setDeviceId(FarmNetStatic.getInstance().getDeviceId());

            System.out.println("Message:"+ message.toString());
        }

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                responseString =  Connector.doPostRequest(Connector.rootURL+ URL_FarmNet.ADD_MESSAGE
                        ,gson.toJson(message));

                System.out.println("Response:"+ responseString);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            startSocket();
            txt_sendMsg.setText("");
            new AsyncTaskGetMessage().execute();

        }
    }
    private void startSocket( ) {
      OkHttpClient  client = new OkHttpClient();
        Request request = new Request.Builder().url("ws://10.30.60.90:8081/WebSocket/server").build();
        EchoWebSocketListener listener = new EchoWebSocketListener();
        WebSocket ws = client.newWebSocket(request, listener);

        ws.send("add_message");
      ///  ws.cancel();
        client.dispatcher().executorService().shutdown();

    }

    public final class EchoWebSocketListener extends WebSocketListener {
        private static final int NORMAL_CLOSURE_STATUS = 1000;
        @Override
        public void onOpen(WebSocket webSocket, Response response) {
        }
        @Override
        public void onMessage(WebSocket webSocket, String text) {

            System.out.println("MESSSSSSS:"+text);

            if(text.contains("add_message"))
            {
                ChatFragment fragment = (ChatFragment)getActivity().getSupportFragmentManager().findFragmentById(R.id.chat_fragment);
                fragment.refresh();
            }
        }
        @Override
        public void onMessage(WebSocket webSocket, ByteString bytes) {
        }
        @Override
        public void onClosing(WebSocket webSocket, int code, String reason) {
            webSocket.close(NORMAL_CLOSURE_STATUS, null);
        }
        @Override
        public void onFailure(WebSocket webSocket, Throwable t, Response response) {
        }
    }

    Button btnBack;
    EditText txt_sendMsg;
    Button btnSend;
    RelativeLayout btnShoppingCart;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_chat, container, false);
        recyclerView = (RecyclerView)view.findViewById(R.id.recyclerView);
        btnBack = (Button)view.findViewById(R.id.btnBack);
        txt_sendMsg = (EditText)view.findViewById(R.id.txt_sendMsg);
        btnSend = (Button)view.findViewById(R.id.btnSend);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity mainActivity = (MainActivity)getActivity();
                mainActivity.backFromSubView(MainActivity.currentTab);
            }
        });
       // loadData();
        txt_sendMsg.requestFocus();
        InputMethodManager imm = (InputMethodManager)getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInput(txt_sendMsg, InputMethodManager.SHOW_IMPLICIT);
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                new AsyncTaskSendMessage().execute();
            }
        });

        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
       // layoutManager.setReverseLayout(true);
        recyclerView.setLayoutManager(layoutManager);


//        txt_sendMsg.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                try{
//                    recyclerView.smoothScrollToPosition(listMessageAdapter.getItemCount());
//
//                    listMessageAdapter.notifyDataSetChanged();
//                }catch (Exception xe){
//                }
//            }
//        });

        try{
            new AsyncTaskGetMessage().execute();


        }catch (Exception ex){

        }

        return view;
    }
}
