package com.deepcode.farmnet.bean;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class ProductOrder {
    private long productOrderID;
    private long productId;
    private int count;
    private int price;

    public long getProductOrderID() {
        return productOrderID;
    }

    public void setProductOrderID(long productOrderID) {
        this.productOrderID = productOrderID;
    }

    public long getProductId() {
        return productId;
    }

    public void setProductId(long productId) {
        this.productId = productId;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public ProductOrder() {
    }

    public ProductOrder(String json) throws Exception {
        this(new JsonParser().parse(json).getAsJsonObject());
    }

    public ProductOrder(JsonObject obj) throws Exception {
        parse(obj);
    }

    public void parse(JsonObject obj) throws Exception {
        this.productOrderID = obj.get("productOrderID").getAsLong();
        this.productId = obj.get("productId").getAsLong();
        this.count = obj.get("count").getAsInt();
        this.price = obj.get("price").getAsInt();
    }

    public JsonObject toJsonObject() {
        JsonObject obj = new JsonObject();
        obj.addProperty("productOrderID", this.productOrderID);
        obj.addProperty("productId", this.productId);
        obj.addProperty("count", this.count);
        obj.addProperty("price", this.price);
        return obj;
    }


}
