package com.deepcode.farmnet.fragment;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.adapter.CategoryAdapter;
import com.deepcode.farmnet.adapter.OrderAdapter;
import com.deepcode.farmnet.adapter.SearchAdapter;
import com.deepcode.farmnet.adapter.SuggestionSearchAdapter;
import com.deepcode.farmnet.extend.WrappingGridView;
import com.deepcode.farmnet.model.CategoryModel;
import com.deepcode.farmnet.model.ProductModel;

import java.util.ArrayList;
import java.util.List;

public class SearchFragment extends  BaseFragment{


    @Override
    public void constructorView() {

    }

    @Override
    public void setOnClick() {

    }

    @Override
    public void loadDateView() {

    }

    TextView textViewTopSearch;
    TextView textViewTopSale;
    TextView textViewFreeShip;
    TextView textViewSearchResult;


    EditText edtSearch;
    WrappingGridView gridViewItem;

    SuggestionSearchAdapter suggestionSearchAdapter;

    List<ProductModel> productModelList = new ArrayList<>();


    WrappingGridView gridViewItem2;

    SuggestionSearchAdapter suggestionSearchAdapter2;

    WrappingGridView gridViewItem3;

    SuggestionSearchAdapter suggestionSearchAdapter3;



    RecyclerView recyclerView;


    Button btnBack;


    SearchAdapter searchAdapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
         super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_search, container, false);


        textViewFreeShip = (TextView)view.findViewById(R.id.tvFreeship);
        textViewTopSale = (TextView)view.findViewById(R.id.tvTopSale);
        textViewTopSearch = (TextView)view.findViewById(R.id.tvTopSearch);
        textViewSearchResult = (TextView)view.findViewById(R.id.tvSearhResult);

        recyclerView = (RecyclerView)view.findViewById(R.id.recyclerView);

        gridViewItem  = (WrappingGridView)view.findViewById(R.id.gridView);
        suggestionSearchAdapter = new SuggestionSearchAdapter(getActivity(), productModelList);
        gridViewItem.setAdapter(suggestionSearchAdapter);


        gridViewItem2  = (WrappingGridView)view.findViewById(R.id.gridView2);
        suggestionSearchAdapter2 = new SuggestionSearchAdapter(getActivity(), productModelList);
        gridViewItem2.setAdapter(suggestionSearchAdapter2);

        edtSearch = (EditText)view.findViewById(R.id.edt_Search);


        btnBack = (Button)view.findViewById(R.id.btnBack);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                MainActivity mainActivity  = (MainActivity)getActivity();
                mainActivity.backFromSubView(MainActivity.currentTab);


            }
        });

        edtSearch.addTextChangedListener(new TextWatcher()
        {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after)
            {

            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count)
            {
                if(edtSearch.getText().length()>0)
                {
                    gridViewItem.setVisibility(View.GONE);
                    gridViewItem2.setVisibility(View.GONE);
                    gridViewItem3.setVisibility(View.GONE);
                    recyclerView.setVisibility(View.VISIBLE);
                    textViewSearchResult.setVisibility(View.VISIBLE);
                    textViewFreeShip.setVisibility(View.GONE);
                    textViewTopSale.setVisibility(View.GONE);
                    textViewTopSearch.setVisibility(View.GONE);

                }else
                {
                    gridViewItem.setVisibility(View.VISIBLE);
                    gridViewItem2.setVisibility(View.VISIBLE);
                    gridViewItem3.setVisibility(View.VISIBLE);
                    recyclerView.setVisibility(View.GONE);
                    textViewSearchResult.setVisibility(View.GONE);

                    textViewFreeShip.setVisibility(View.VISIBLE);
                    textViewTopSale.setVisibility(View.VISIBLE);
                    textViewTopSearch.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void afterTextChanged(Editable s)
            {

            }
        });

        gridViewItem3  = (WrappingGridView)view.findViewById(R.id.gridView3);
        suggestionSearchAdapter3 = new SuggestionSearchAdapter(getActivity(), productModelList);
        gridViewItem3.setAdapter(suggestionSearchAdapter3);
        searchAdapter = new SearchAdapter(productModelList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(searchAdapter);


        gridViewItem.setVisibility(View.VISIBLE);
        gridViewItem2.setVisibility(View.VISIBLE);
        gridViewItem3.setVisibility(View.VISIBLE);
        textViewFreeShip.setVisibility(View.VISIBLE);
        textViewTopSale.setVisibility(View.VISIBLE);
        textViewTopSearch.setVisibility(View.VISIBLE);
        recyclerView.setVisibility(View.GONE);
        textViewSearchResult.setVisibility(View.GONE);



        return view;
    }
}
