package com.deepcode.farmnet.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.model.ProductModel;
import java.util.List;

public class GroupTextAdapter extends RecyclerView.Adapter<GroupTextAdapter.RecyclerViewHolder>
{
    List<ProductModel> listProduct;
    public GroupTextAdapter(List<ProductModel> list)
    {
        listProduct = list;
    }
    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.home_list_product_final_group_cell, parent, false);
        return new RecyclerViewHolder(view);    }
    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position)
    {
        ProductModel productModel = listProduct.get(position);
        String name = productModel.getName().toUpperCase();
        holder.txtProduct.setText(name);

    }
    @Override
    public int getItemCount()
    {
        return listProduct.size();
    }
    public class RecyclerViewHolder extends RecyclerView.ViewHolder
    {

        TextView txtProduct;

        public RecyclerViewHolder(View itemView)
        {
            super(itemView);
            txtProduct = (TextView)itemView.findViewById(R.id.tvNameGroup);
            // txtUserName = (TextView) itemView.findViewById(R.id.user_name);
        }
    }
}