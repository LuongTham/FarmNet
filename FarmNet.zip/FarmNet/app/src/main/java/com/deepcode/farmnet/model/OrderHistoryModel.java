package com.deepcode.farmnet.model;

public class OrderHistoryModel {
    private String name;
    private String address;
    private String time;

    private boolean status; //true = done, false = pending;

    public OrderHistoryModel(String name, String address, String time, boolean status) {
        this.name = name;
        this.address = address;
        this.time = time;
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
}
