package com.deepcode.farmnet.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.R;
import com.deepcode.farmnet.bean.TopProduct;
import com.deepcode.farmnet.core.ImageUtil;
import com.makeramen.roundedimageview.RoundedImageView;

import java.util.ArrayList;
import java.util.List;

public class SmallSaleHomeAdapter extends RecyclerView.Adapter <SmallSaleHomeAdapter.ViewHolder> {
    List<TopProduct> listProductsale;
    public SmallSaleHomeAdapter(List<TopProduct> list)
    {
        listProductsale = list;
    }
    @NonNull
    @Override
    public SmallSaleHomeAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.item_small_sale_home, parent,false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SmallSaleHomeAdapter.ViewHolder holder, int position) {
        TopProduct productModel = listProductsale.get(position);
        holder.picture.
                setImageBitmap(ImageUtil.bitmapFromBase64(productModel.getImage()));
        holder.nameFarm.setText(productModel.getFarmName());
        holder.nameCombo.setText(productModel.getProductName());
        holder.bnt_Discount.setText(productModel.getFarmName());

    }

    @Override
    public int getItemCount() {
        return listProductsale.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView nameFarm;
        TextView nameCombo;
        RoundedImageView picture;
        Button bnt_Discount;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nameFarm = (TextView)itemView.findViewById(R.id.tvFarm);
            nameCombo = (TextView)itemView.findViewById(R.id.tvDes);
            picture = (RoundedImageView) itemView.findViewById(R.id.imgIcon);
            bnt_Discount = (Button)itemView.findViewById(R.id.btn_discount);
        }
    }
}
