package com.deepcode.farmnet.adapter;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.util.JsonToken;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.core.Data;
import com.deepcode.farmnet.core.ImageUtil;
import com.deepcode.farmnet.model.Order;
import com.deepcode.farmnet.model.ProductModel;

import java.util.List;


public class ListProductFinalHomeAdapter extends RecyclerView.Adapter<ListProductFinalHomeAdapter.RecyclerViewHolder>
{
    List<ProductModel> listProduct;
    Context contex;
    public ListProductFinalHomeAdapter(List<ProductModel> list, Context mContex)
    {
        contex = mContex;
        listProduct = list;
    }
    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.home_list_product_final_cell, parent, false);
        return new RecyclerViewHolder(view);    }
    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position)
    {
        if (listProduct.size()>0){
            final ProductModel productModel = listProduct.get(position);

            holder.txtName.setText(productModel.getName());
            String ss = String.format("%,d",Long.parseLong(""+productModel.getPrice()));
            holder.txtPrice.setText(ss+"đ");
            holder.txtFarm.setText(productModel.getFarm());

            if(productModel.getImage()!=null) {

                Glide.with(contex).load(productModel.getImage()).into(holder.imageView);
                // holder.imageView.setImageURI(new Uri(productModel.getImage()));
                //setImageBitmap(ImageUtil.bitmapFromBase64(productModel.getImage()));
            }

            holder.btnBuy.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Order acc = new Order(productModel.getName(),productModel.getImage(),1,productModel.getPrice(),0);
                    Data.orderList.add(acc);

                    Toast.makeText(contex, "Thêm vào giỏ hàng: "+productModel.getName(), Toast.LENGTH_SHORT).show();
                }
            });

            holder.rl_item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    MainActivity mainActivity = (MainActivity) contex;
                    mainActivity.showTabProductDetail();
                    Toast.makeText(contex, "Chi tiết SP: "+productModel.getName(), Toast.LENGTH_SHORT).show();
                }
            });



        }
    }
    @Override
    public int getItemCount()
    {
        return listProduct.size();
    }
    public class RecyclerViewHolder extends RecyclerView.ViewHolder
    {
        Button btnBuy;
        TextView txtName;
        TextView txtPrice;
        TextView txtFarm;
        //        TextView txtProduct;
        ImageView imageView;
        RelativeLayout rl_item;

        public RecyclerViewHolder(View itemView)
        {
            super(itemView);
            btnBuy = (Button) itemView.findViewById(R.id.btnBuy);
            txtName = (TextView) itemView.findViewById(R.id.tvProduct);
            txtPrice = (TextView) itemView.findViewById(R.id.tvPrice);
            txtFarm = (TextView) itemView.findViewById(R.id.tvFarm);
            rl_item = (RelativeLayout) itemView.findViewById(R.id.rl_item);
            imageView = (ImageView) itemView.findViewById(R.id.avaImage);

        }
    }

    public void refreshData( List<ProductModel> newList) {
        listProduct = newList;
        this.notifyDataSetChanged();
    }
}

