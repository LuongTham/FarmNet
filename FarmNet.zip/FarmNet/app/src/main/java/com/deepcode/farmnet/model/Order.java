package com.deepcode.farmnet.model;

public class Order {
    String name;
    String img;
    int count;
    int price;
    float discount;
    boolean selected;

    public Order(String name, String img, int count, int price, float discount) {
        this.name = name;
        this.img = img;
        this.count = count;
        this.price = price;
        this.discount = discount;
    }


    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public float getDiscount() {
        return discount;
    }

    public void setDiscount(float discount) {
        this.discount = discount;
    }
}
