package com.deepcode.farmnet.fragment.ManageOderFragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.deepcode.farmnet.R;
import com.deepcode.farmnet.fragment.BaseFragment;

public class SuccessfullFragment extends BaseFragment
{
    @Override
    public void constructorView() {

    }

    @Override
    public void setOnClick() {

    }

    @Override
    public void loadDateView() {

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
      View view = inflater.inflate(R.layout.fragment_successfull_manage_order , container, false);
        return  view;
    }
}
