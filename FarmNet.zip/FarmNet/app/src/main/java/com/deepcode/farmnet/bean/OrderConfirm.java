package com.deepcode.farmnet.bean;

import java.util.Date;
import java.util.List;

public class OrderConfirm {
    private long orderID;
    private List<Product> listProduct;
    private List<ProductCombo> listCombo;
    private Long userId;
    private String address;
    private String phone;
    private String deviceId;
    private boolean delete;
    private Date createDate;
    private String status;
    private AddressOrder addressOrder;

    public OrderConfirm(){

    }
    public OrderConfirm(long orderID, List<Product> listProduct, List<ProductCombo> listCombo, Long userId, String address, String phone, String deviceId, boolean delete, Date createDate, String status, AddressOrder addressOrder) {
        this.orderID = orderID;
        this.listProduct = listProduct;
        this.listCombo = listCombo;
        this.userId = userId;
        this.address = address;
        this.phone = phone;
        this.deviceId = deviceId;
        this.delete = delete;
        this.createDate = createDate;
        this.status = status;
        this.addressOrder = addressOrder;
    }

    public long getOrderID() {
        return orderID;
    }

    public void setOrderID(long orderID) {
        this.orderID = orderID;
    }

    public List<Product> getListProduct() {
        return listProduct;
    }

    public void setListProduct(List<Product> listProduct) {
        this.listProduct = listProduct;
    }

    public List<ProductCombo> getListCombo() {
        return listCombo;
    }

    public void setListCombo(List<ProductCombo> listCombo) {
        this.listCombo = listCombo;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public boolean isDelete() {
        return delete;
    }

    public void setDelete(boolean delete) {
        this.delete = delete;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public AddressOrder getAddressOrder() {
        return addressOrder;
    }

    public void setAddressOrder(AddressOrder addressOrder) {
        this.addressOrder = addressOrder;
    }
}
