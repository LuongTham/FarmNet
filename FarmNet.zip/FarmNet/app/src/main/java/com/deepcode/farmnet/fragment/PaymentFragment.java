package com.deepcode.farmnet.fragment;

import android.app.AlertDialog;
import android.media.Image;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.adapter.CategoryTextAdapter;
import com.deepcode.farmnet.adapter.ListOrderPaymentAdapter;
import com.deepcode.farmnet.adapter.OrderAdapter;
import com.deepcode.farmnet.bean.AddressOrder;
import com.deepcode.farmnet.bean.Category;
import com.deepcode.farmnet.bean.OrderConfirm;
import com.deepcode.farmnet.bean.Product;
import com.deepcode.farmnet.bean.ProductCombo;
import com.deepcode.farmnet.core.Connector;
import com.deepcode.farmnet.core.FarmNetStatic;
import com.deepcode.farmnet.core.URL_FarmNet;
import com.deepcode.farmnet.model.Combo;
import com.deepcode.farmnet.model.Order;
import com.deepcode.farmnet.model.ProductModelReal;
import com.deepcode.farmnet.request.AccountId;
import com.deepcode.farmnet.request.CartId;
import com.deepcode.farmnet.response.CartResponse;
import com.google.android.material.navigation.NavigationView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class PaymentFragment extends BaseFragment {
    @Override
    public void constructorView() {

    }

    @Override
    public void setOnClick() {

    }

    @Override
    public void loadDateView() {

    }
    ListOrderPaymentAdapter listOrderPaymentAdapter;
    RecyclerView rcv_listOrderPayment;
    ImageView ic_next;
    LinearLayout btn_buy;
    Button btnBack_payment;
    RelativeLayout cst_payment;
    List<CartResponse> lstOrder = new ArrayList<CartResponse>();
    TextView txt_address, txt_phone;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_payment, container, false);
        cst_payment = view.findViewById(R.id.cst_payment);

        btnBack_payment = view.findViewById(R.id.btnBack_payment);
        btnBack_payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                MainActivity mainActivity = (MainActivity)getActivity();
                mainActivity.showTabAddress();
            }
        });
        rcv_listOrderPayment = view.findViewById(R.id.rcv_listOrderPayment);

        btn_buy = view.findViewById(R.id.btn_buy);
        btn_buy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toBuy();
                MainActivity mainActivity = (MainActivity)getActivity();
                mainActivity.showTabManageOrder();


            }
        });


        txt_phone = view.findViewById(R.id.txt_phone_defaul);
        txt_address = view.findViewById(R.id.txt_addrees_defaul);

        try{
            new AsyncTaskcConfirmItemOrder().execute();

        }catch (Exception ex){


        }

        return view;
    }

    public void reload()
    {
        AddressOrder addressOrder = FarmNetStatic.getAddressDefaul();

        System.out.println("Add:"+ addressOrder.getDetailAddress());
        System.out.println("Add:"+ addressOrder.getDistrict());
        System.out.println("Add:"+ addressOrder.getProvince());

        if(addressOrder!= null)
        {

            String addressFull = addressOrder.getDetailAddress()+"," +addressOrder.getDistrict()+"," + addressOrder.getProvince();
            System.out.println("ADDFULL:"+addressFull);
            txt_address.setText(addressFull.toString());
            txt_phone.setText(addressOrder.getPhone());
        }

        try{
            new AsyncTaskcConfirmItemOrder().execute();

        }catch (Exception ex){


        }

    }

    public class AsyncTaskcConfirmItemOrder extends AsyncTask {
        Gson gson = new Gson();
        String jsonString = null;
        //OrderConfirm orderConfirm = new OrderConfirm();
        AccountId accountId = new AccountId();

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            try {
                accountId.setId(FarmNetStatic.getInstance().getAccount().getAccountID());

            } catch (Exception ex) {

            }

//            orderConfirm.setAddress(FarmNetStatic.getInstance().getAccount().getAddress());
//            orderConfirm.setAddressOrder(FarmNetStatic.getAddresss());
//            orderConfirm.setCreateDate(new Date());
//            orderConfirm.setDeviceId(FarmNetStatic.getInstance().getDeviceId());
//            orderConfirm.setDelete(false);
//            orderConfirm.setOrderID(1);
//            orderConfirm.setPhone(FarmNetStatic.getInstance().getAccount().getPhone());
//            orderConfirm.setStatus("");
//
//            List<Product> productList = new ArrayList<Product>();
//            List<ProductCombo> comboList = new ArrayList<ProductCombo>();
//
//            for(CartResponse cartResponse: FarmNetStatic.cartResponseList)
//            {
//
//                if(cartResponse.isCombo())
//                {
//
//                    ProductCombo combo = new ProductCombo();
//                    combo.setCreatedDate(new Date());
//                    combo.setProductComboID(cartResponse.getId());
//                    combo.setDelete(false);
//                    combo.setImage(cartResponse.getImage());
//                    combo.setName(cartResponse.getName());
//                    comboList.add(combo);
//                }else
//                {
//                    Product product = new Product();
//                    product.setCity("");
//                    product.setCount(1);
//                    product.setDiscount((int)cartResponse.getDiscount());
//                    product.setFarmId(cartResponse.getId());
//                    product.setGroupId(1);
//                    productList.add(product);
//                    product.setFarmId(cartResponse.getFarmId());
//                    product.setName(cartResponse.getName());
//                    product.setPrice((int)cartResponse.getPrice());
//                    productList.add(product);
//
//                }
//            }
//
//            orderConfirm.setListProduct(productList);
//            orderConfirm.setListCombo(comboList);


        }

        @Override
        protected Object doInBackground(Object[] objects) {
            try {
                jsonString = Connector.doPostRequest(Connector.rootURL + URL_FarmNet.GETLIST_CART, gson.toJson(accountId));


            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }
        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);

            TypeToken<List<CartResponse>> token = new TypeToken<List<CartResponse>>() {
            };

            System.out.println("JSON:"+ jsonString);
            lstOrder = gson.fromJson(jsonString, token.getType());
            listOrderPaymentAdapter = new ListOrderPaymentAdapter(getContext(), lstOrder);
            LinearLayoutManager layoutManager2 = new LinearLayoutManager(getContext());
            layoutManager2.setOrientation(LinearLayoutManager.VERTICAL);
            rcv_listOrderPayment.setLayoutManager(layoutManager2);
            rcv_listOrderPayment.setAdapter(listOrderPaymentAdapter);
        }
    }

    private void toBuy() {

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

        LayoutInflater inflater = LayoutInflater.from(getContext());
        View dialogView = inflater.inflate(R.layout.dialog_processing_order, null);
        builder.setView(dialogView);

        final AlertDialog dialog = builder.create();
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.show();
        final ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
        executorService.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                dialog.cancel();
            }
        }, 3, 3, TimeUnit.SECONDS);

    }

}
