package com.deepcode.farmnet.model;

import com.google.gson.annotations.SerializedName;


public class CategoryModel {

    public String name;


    public String imageUr;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImageUr() {
        return imageUr;
    }

    public void setImageUr(String imageUr) {
        this.imageUr = imageUr;
    }


}
