package com.deepcode.farmnet.bean;

import com.deepcode.farmnet.model.ProductModel;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Category {
    @SerializedName("categoryID")
    private long categoryID;


    @SerializedName("name")
    public String name;


    @SerializedName("image")
    public String image;

    @SerializedName("createdDate")
    private Date createdDate;

    @SerializedName("delete")
    private boolean delete;

    @SerializedName("colorBg")
    private String colorBg;



    public void setCategoryID(long categoryID) {
        this.categoryID = categoryID;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public void setDelete(boolean delete) {
        this.delete = delete;
    }

    public void setColorBg(String colorBg) {
        this.colorBg = colorBg;
    }

    public long getCategoryID() {
        return categoryID;
    }

    public String getName() {
        return name;
    }

    public String getImage() {
        return image;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public boolean isDelete() {
        return delete;
    }

    public String getColorBg() {
        return colorBg;
    }


    @Override
    public String toString() {
        return "Category{" +
                "categoryID=" + categoryID +
                ", name='" + name + '\'' +
                ", image='" + image + '\'' +
                ", createdDate=" + createdDate +
                ", delete=" + delete +
                ", colorBg='" + colorBg + '\'' +
                '}';
    }

}
