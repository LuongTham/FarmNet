package com.deepcode.farmnet.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.R;
import com.deepcode.farmnet.bean.Category;
import com.deepcode.farmnet.core.Data;
import com.deepcode.farmnet.model.CheckButton;
import com.deepcode.farmnet.model.ProductModel;

import java.util.ArrayList;
import java.util.List;


public class CategoryTextAdapter extends RecyclerView.Adapter<CategoryTextAdapter.RecyclerViewHolder>
{
    Context mContext;
    private int selectedpoint = 0;
    List<Category> listCategory = new ArrayList<>();
    public CategoryTextAdapter(List<Category> list, Context context)
    {
        mContext = context;
        listCategory = list;
        // this.checkButtonList = checkButtonList;
    }
    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.home_list_product_final_category_cell, parent, false);
        return new RecyclerViewHolder(view);    }
    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, final int position)
    {

        if (listCategory.size()>0){
            Category category = listCategory.get(position);
            holder.txtCategory.setText(category.getName());



            if(position== Data.positionCategoryCurent)
            {
                holder.rl_item.setBackgroundColor(Color.parseColor("#78B374"));
                holder.txtCategory.setTextColor(Color.WHITE);
            }else {
                holder.rl_item.setBackgroundColor(Color.WHITE);
                holder.txtCategory.setTextColor(Color.GRAY);

            }



        }
    }
    @Override
    public int getItemCount()
    {
        return listCategory.size();
    }
    public class RecyclerViewHolder extends RecyclerView.ViewHolder
    {
        TextView txtCategory;
        RelativeLayout rl_item;
        public RecyclerViewHolder(View itemView)
        {
            super(itemView);
            rl_item = (RelativeLayout) itemView.findViewById(R.id.rl_item);
            txtCategory = (TextView) itemView.findViewById(R.id.tvname);
        }
    }

    public void refreshData( List<Category> newList) {
        listCategory = newList;
        this.notifyDataSetChanged();
    }

}
