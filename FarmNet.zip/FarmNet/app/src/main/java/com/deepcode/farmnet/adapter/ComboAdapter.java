package com.deepcode.farmnet.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.model.Combo;
import java.util.List;
public class ComboAdapter extends RecyclerView.Adapter<ComboAdapter.RecyclerViewHolder>
{
    List<Combo> listProduct;
    public ComboAdapter(List<Combo> list)
    {
        listProduct = list;
    }


    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.combo_item, parent, false);
        return new RecyclerViewHolder(view);    }
    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position)
    {
        // ProductModel productModel = listProduct.get(position);

        //        holder.txtUserName.setText(data.get(position));

    }
    @Override
    public int getItemCount()
    {
        return 5;
    }
    public class RecyclerViewHolder extends RecyclerView.ViewHolder
    {
        Button txtPrice;
        TextView txtFarm;
        TextView txtProduct;
        ImageView imageView;
        TextView txtUserName;

        public RecyclerViewHolder(View itemView)
        {
            super(itemView);
         //   txtUserName = (TextView) itemView.findViewById(R.id.tvName);
            imageView = itemView.findViewById(R.id.imgIcon);


        }
    }

}