package com.deepcode.farmnet.adapter;

import android.content.Context;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.R;
import com.deepcode.farmnet.bean.Cart;
import com.deepcode.farmnet.bean.TopProduct;
import com.deepcode.farmnet.core.Connector;
import com.deepcode.farmnet.core.Data;
import com.deepcode.farmnet.core.FarmNetStatic;
import com.deepcode.farmnet.core.ImageUtil;
import com.deepcode.farmnet.core.URL_FarmNet;
import com.deepcode.farmnet.model.Order;
import com.deepcode.farmnet.model.ProductModel;
import com.deepcode.farmnet.model.ProductModelReal;
import com.google.gson.Gson;
import com.makeramen.roundedimageview.RoundedImageView;

import java.io.IOException;
import java.util.List;


public class ListProductHomeAdapter extends RecyclerView.Adapter<ListProductHomeAdapter.RecyclerViewHolder>
{
    List<TopProduct> listProduct ;
    Context context;

    public ListProductHomeAdapter(Context context, List<TopProduct> listProduct) {
        this.context = context;
        this.listProduct = listProduct;
    }



    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.home_list_product_cell, parent, false);

        return new RecyclerViewHolder(view);    }
    @Override
    public void onBindViewHolder(@NonNull final RecyclerViewHolder holder, final int position)
    {
        // ProductModel productModel = listProduct.get(position);

        //        holder.txtUserName.setText(data.get(position));

        final TopProduct topProduct = listProduct.get(position);

        Drawable dr = new BitmapDrawable(ImageUtil.bitmapFromBase64(topProduct.getImage()));

        holder.imageView.setBackground(dr);
                //setImageBitmap(ImageUtil.bitmapFromBase64(topProduct.getImage()));
        holder.txtProduct.setText(topProduct.getProductName());
        ///holder.txtFarm.setText(topProduct.getFarmName());
        holder.txtPrice.setText(topProduct.getPrice());


//        holder.btnAddtoCart.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                //  Order acc = new Order(productModelReal.getName(), productModelReal.getImage(), 1, productModelReal.getPrice(), 0);
//                //    Data.orderList.add(acc);
//
//                new AsyncTaskSendItemCart(topProduct).execute();
//                Toast.makeText( context, "Thêm vào giỏ hàng: " + topProduct.getProductName(), Toast.LENGTH_SHORT).show();
//
//            }
//
//        });

    }
    @Override
    public int getItemCount()
    {
        return listProduct.size();
    }
    public class RecyclerViewHolder extends RecyclerView.ViewHolder
    {
        TextView txtPrice;
        //TextView txtFarm;
        TextView txtProduct;
        RoundedImageView imageView;
       // ImageView btnAddtoCart;

        public RecyclerViewHolder(View itemView)
        {
            super(itemView);
            // txtUserName = (TextView) itemView.findViewById(R.id.user_name);
            imageView = (RoundedImageView)itemView.findViewById(R.id.imgIcon);
          //  btnAddtoCart = (ImageView)itemView.findViewById(R.id.btn_addToCart);
            txtProduct = (TextView) itemView.findViewById(R.id.tvProduct);
           // txtFarm = (TextView) itemView.findViewById(R.id.tvFarm);
            txtPrice = (TextView) itemView.findViewById(R.id.tvPrice);

        }
    }

    public class AsyncTaskSendItemCart extends AsyncTask<Void, Void, Void>
    {
        String responseString = null;
        Gson gson = new Gson();
        Cart cart = new Cart();

        TopProduct topProduct;

        public AsyncTaskSendItemCart(TopProduct topProduct)
        {
            this.topProduct = topProduct;
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            cart.set_id(1);
            cart.setAccountId(FarmNetStatic.getInstance().getAccount().getAccountID());
            cart.setAddress("");
            cart.setCreatedDate(FarmNetStatic.getInstance().getAccount().getCreatedDate());
            cart.setUserName(FarmNetStatic.getInstance().getAccount().getName());
            cart.setStatus(1);
            cart.setPhone("");
            cart.setNote("");
            cart.setDeviceId(FarmNetStatic.getInstance().getDeviceId());
            cart.setProductOrcomboId(topProduct.getProductId());
            cart.setCombo(false);
            cart.setDelete(false);

            System.out.println("IDID:"+topProduct.getProductId());

        }

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                responseString =  Connector.doPostRequest(Connector.rootURL+ URL_FarmNet.ADD_CART
                        ,gson.toJson(cart));

                System.out.println("Response1111111:"+ responseString);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
           // updateCountCart();
            // btnAddToCart.
            // new AsyncTaskSendItemCart().execute();
        }
    }
}

