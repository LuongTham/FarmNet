package com.deepcode.farmnet.fragment.ManageOderFragment;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.R;
import com.deepcode.farmnet.adapter.ManagerOrder.ProcessingAdapter;
import com.deepcode.farmnet.bean.Cart;
import com.deepcode.farmnet.bean.OrderConfirm;
import com.deepcode.farmnet.bean.Product;
import com.deepcode.farmnet.bean.ProductCombo;
import com.deepcode.farmnet.core.Connector;
import com.deepcode.farmnet.core.FarmNetStatic;
import com.deepcode.farmnet.core.URL_FarmNet;
import com.deepcode.farmnet.fragment.BaseFragment;
import com.deepcode.farmnet.fragment.PaymentFragment;
import com.deepcode.farmnet.response.CartResponse;
import com.google.gson.Gson;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ProcessingFragment extends BaseFragment {
    @Override
    public void constructorView() {

    }

    @Override
    public void setOnClick() {

    }

    @Override
    public void loadDateView() {

    }
    RecyclerView recyclerView;
    ProcessingAdapter processingAdapter;
    private ArrayList<Product> listProduct = new ArrayList<>();


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_processing_manage_order,container, false);
        recyclerView = view. findViewById(R.id.rcv_manageListOrder);
        processingAdapter = new ProcessingAdapter(getContext(), listProduct);
        recyclerView.setAdapter(processingAdapter);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);


        new AsyncTaskSendOrderToProcess().execute();
       return view;


    }
    public class AsyncTaskSendOrderToProcess extends AsyncTask{

        Gson gson = new Gson();
        String jsonString = null;
        OrderConfirm orderConfirm = new OrderConfirm();
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
         //   CartResponse cartResponse = new CartResponse();


            orderConfirm.setAddress(FarmNetStatic.getInstance().getAccount().getAddress());
            orderConfirm.setAddressOrder(FarmNetStatic.getAddresss());
            orderConfirm.setCreateDate(new Date());
            orderConfirm.setDeviceId(FarmNetStatic.getInstance().getDeviceId());
            orderConfirm.setDelete(false);
            orderConfirm.setOrderID(1);
            orderConfirm.setPhone(FarmNetStatic.getInstance().getAccount().getPhone());
            orderConfirm.setStatus("");

            List<Product> productList = new ArrayList<Product>();
            List<ProductCombo> comboList = new ArrayList<ProductCombo>();

            for(CartResponse cartResponse: FarmNetStatic.cartResponseList)
            {
                if(cartResponse.isCombo())
                {
                    ProductCombo combo = new ProductCombo();
                    combo.setCreatedDate(new Date());
                    combo.setProductComboID(cartResponse.getId());
                    combo.setDelete(false);
                    combo.setImage(cartResponse.getImage());
                    combo.setName(cartResponse.getName());
                    comboList.add(combo);
                }else
                {
                    Product product = new Product();
                    product.setCity("");
                    product.setCount(1);
                    product.setDiscount((int)cartResponse.getDiscount());
                    product.setFarmId(cartResponse.getId());
                    product.setGroupId(1);
                    product.setFarmId(cartResponse.getFarmId());
                    product.setName(cartResponse.getName());
                    product.setPrice((int)cartResponse.getPrice());
                    productList.add(product);

                }
            }
            orderConfirm.setListProduct(productList);
            orderConfirm.setListCombo(comboList);
        }

        @Override
        protected Object doInBackground(Object[] objects) {
            try {
                jsonString = Connector.doPostRequest(Connector.rootURL + URL_FarmNet.GETLIST_DeleteAddress, gson.toJson(orderConfirm));


            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;

        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);

        }


    }

}
