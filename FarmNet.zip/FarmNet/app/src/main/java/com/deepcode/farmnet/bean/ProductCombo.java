package com.deepcode.farmnet.bean;

import java.util.Date;
import java.util.List;

public class ProductCombo {
    private long productComboID;
    private String name;
    private String image;
    private Date createdDate;
    List<Product> listProduct;
    private boolean delete;
    public long getProductComboID() {
        return productComboID;
    }
    public void setProductComboID(long productComboID) {
        this.productComboID = productComboID;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getImage() {
        return image;
    }
    public void setImage(String image) {
        this.image = image;
    }
    public Date getCreatedDate() {
        return createdDate;
    }
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }
    public List<Product> getListProduct() {
        return listProduct;
    }
    public void setListProduct(List<Product> listProduct) {
        this.listProduct = listProduct;
    }
    public boolean isDelete() {
        return delete;
    }
    public void setDelete(boolean delete) {
        this.delete = delete;
    }
}
