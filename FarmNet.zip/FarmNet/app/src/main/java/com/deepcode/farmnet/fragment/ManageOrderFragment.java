package com.deepcode.farmnet.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewpager.widget.ViewPager;

import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.adapter.ManagerOrderAdapter;
import com.deepcode.farmnet.fragment.ManageOderFragment.ProcessingFragment;
import com.deepcode.farmnet.fragment.ManageOderFragment.ShippingFrgment;
import com.deepcode.farmnet.fragment.ManageOderFragment.SuccessfullFragment;
import com.google.android.material.tabs.TabLayout;

public class ManageOrderFragment extends BaseFragment{
    @Override
    public void constructorView() {

    }

    @Override
    public void setOnClick() {

    }

    @Override
    public void loadDateView() {

    }
    ManagerOrderAdapter managerOrderAdapter;
    ViewPager viewPager;
    Button btnBack_manage_order;
    TabLayout tabLayout;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_manage_order, container, false);
        viewPager = (ViewPager) view.findViewById(R.id.vp_hint);
        tabLayout = (TabLayout) view.findViewById(R.id.tl_hint);
        loadData();
        setData(view);
        btnBack_manage_order = view.findViewById(R.id.btnBack_manage_order);
        btnBack_manage_order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity mainActivity = (MainActivity)getActivity();
                mainActivity.showTabOrder();
            }
        });
        return  view;
    }

    private void setData(View view) {

    }

    private void loadData() {
        managerOrderAdapter = new ManagerOrderAdapter(getActivity().getSupportFragmentManager());
        managerOrderAdapter.addFragment(new ProcessingFragment(), "Đang xử lý");
        managerOrderAdapter.addFragment(new ShippingFrgment(), "Đang vận chuyển");
        managerOrderAdapter.addFragment(new SuccessfullFragment(), "Thành công");
        viewPager.setAdapter(managerOrderAdapter);
        tabLayout.setupWithViewPager(viewPager);
    }
}
