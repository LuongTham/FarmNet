package com.deepcode.farmnet.request;

public class GetMessageId {

    private long sendId;

    private long recieveId;

    public long getSendId() {
        return sendId;
    }

    public void setSendId(long sendId) {
        this.sendId = sendId;
    }

    public long getRecieveId() {
        return recieveId;
    }

    public void setRecieveId(long recieveId) {
        this.recieveId = recieveId;
    }

    @Override
    public String toString() {
        return "GetMessageId{" +
                "sendId=" + sendId +
                ", recieveId=" + recieveId +
                '}';
    }
}
