package com.deepcode.farmnet.fragment;

import android.app.AlertDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.adapter.CategoryTextAdapter;
import com.deepcode.farmnet.adapter.ComboAdapter;
import com.deepcode.farmnet.adapter.HeaderHomeAdapter;
import com.deepcode.farmnet.adapter.ProductDetailAdapter;
import com.deepcode.farmnet.adapter.ShowCommentAdapter;
import com.deepcode.farmnet.bean.Category;
import com.deepcode.farmnet.bean.Product;
import com.deepcode.farmnet.bean.TopProduct;
import com.deepcode.farmnet.core.Connector;
import com.deepcode.farmnet.core.Data;
import com.deepcode.farmnet.core.ImageUtil;
import com.deepcode.farmnet.model.Combo;
import com.deepcode.farmnet.model.ProductModel;
import com.deepcode.farmnet.model.ShowCommentModel;
import com.deepcode.farmnet.request.ProductID;
import com.deepcode.farmnet.request.TopRequest;
import com.deepcode.farmnet.response.ProductResponse;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.security.cert.TrustAnchor;
import java.util.ArrayList;
import java.util.List;

public class ProductDetailFragment extends BaseFragment {

    //int n = 0;
    public static ProductDetailFragment instance;

    public static ProductDetailFragment getInstance() {
        if (instance == null) {
            instance = new ProductDetailFragment();
        }
        return instance;
    }

    private ShowCommentAdapter showCommentAdapter;
    private LinearLayoutManager linearLayoutManager;
    private RecyclerView rcvShowComment;
    private ArrayList<ShowCommentModel> lstModel = new ArrayList<>();

    //
    String result = "null";

    @Override
    public void constructorView() {

    }

    @Override
    public void setOnClick() {

    }

    @Override
    public void loadDateView() {

    }

    public void refresh(int id) {
        new LoadDataAsyncTask(id).execute();
    }

    private class LoadDataAsyncTask extends AsyncTask {
        String url = Connector.rootURL + "product/ByProductId";
        String responseString = null;
        Gson gson = new Gson();
        ProductID productID = new ProductID();

        public int id;

        public LoadDataAsyncTask(int id) {
            this.id = id;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            productID.setId(id); // truyền vào ID
        }

        @Override
        protected Object doInBackground(Object[] objects) {
            try {
                responseString = Connector.doPostRequest(url, gson.toJson(productID));
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);


            Gson gson = new Gson();

            System.out.println("Response222:" + responseString);


            try {
                Product product = gson.fromJson(responseString, Product.class);

                img_cover.setImageBitmap(ImageUtil.bitmapFromBase64(product.getImage()));
                img_cover.setScaleType(ImageView.ScaleType.FIT_XY);

                tvDes.setText(product.getName() + " ăn là khoái!");
                tvTitle.setText((product.getName() + " - " + product.getCity()).toUpperCase());
                tvPricelv1.setText(String.format("%,d", Long.parseLong("" + product.getPrice())) + "đ/1" + product.getUnit().toLowerCase());

                base64Img = product.getImage();

            } catch (Exception e) {

            }

        }
    }


    ProductDetailAdapter productDetailAdapter;
    List<ProductModel> productModelList = new ArrayList<>();
    RecyclerView recyclerView;
    Button btnBack;
    TextView btnReadCmt;
    LinearLayout ln_box_cmt;
    LinearLayout btnAllReview;

    public static ImageView img_cover;
    public static TextView tvDes, tvTitle, tvPricelv1,write_cmt;
    public static String base64Img;
    public static LinearLayout rating;
    public static TextView tv_allReview;
    public static ImageView ic_downArrow, ic_downArrow_readCmt;

    RelativeLayout relative_show_cmt;
    boolean click_cmt = true;

    boolean checkShowAll = false;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_product_detail, container, false);
        rcvShowComment = view.findViewById(R.id.rcv_show_comment);
        ProductDetailFragment productDetailFragment = ProductDetailFragment.getInstance();
        linearLayoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false);
        loadLess();
        rcvShowComment.setLayoutManager(linearLayoutManager);
        rcvShowComment.setAdapter(showCommentAdapter);
        rcvShowComment.hasFixedSize();

        // get data from server
        new LoadDataAsyncTask(1).execute();

        // use data
        write_cmt = view.findViewById(R.id.txt_write_cmt);
        write_cmt.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                toRate();
            }

        });

      //  rating = view.findViewById(R.id.ln_rating);

        recyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);

        img_cover = (ImageView) view.findViewById(R.id.img_cover);

        tvDes = view.findViewById(R.id.tvDes);

        tvTitle = view.findViewById(R.id.tvTitle);

      //  tvPricelv1 = view.findViewById(R.id.price_lv1);

        tv_allReview = view.findViewById(R.id.tv_all_review);

        ic_downArrow = view.findViewById(R.id.ic_down_arrow);
        ic_downArrow_readCmt = view.findViewById(R.id.ic_down_arrow_readCmt);




        btnBack = (Button) view.findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity mainActivity = (MainActivity) getActivity();
                mainActivity.backFromSubView(MainActivity.currentTab);
            }
        });


        relative_show_cmt = view.findViewById(R.id.relative_show_cmt);
        ln_box_cmt = (LinearLayout) view.findViewById(R.id.ln_box_cmt);
        btnReadCmt = (TextView) view.findViewById(R.id.btn_readCmt);
        ln_box_cmt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                click_cmt = !click_cmt;
                if (click_cmt) {
                    relative_show_cmt.setVisibility(View.GONE);
                    btnReadCmt.setText("Read comments");
                    ic_downArrow_readCmt.setRotation(0);


                } else {
                    relative_show_cmt.setVisibility(View.VISIBLE);
                    btnReadCmt.setText("Hide comments");
                    ic_downArrow_readCmt.setRotation(180);

                }
            }
        });

        btnAllReview = (LinearLayout) view.findViewById(R.id.btn_all_review);
        btnAllReview.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                checkShowAll = !checkShowAll;
            if (checkShowAll){
                tv_allReview.setText("Show Less");
                ic_downArrow.setRotation(-90f);
                loadMore();
            } else {
                tv_allReview.setText("All Review");
                ic_downArrow.setRotation(90);
                loadLess();
            }
            }
        });

        productDetailAdapter = new ProductDetailAdapter(productModelList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(productDetailAdapter);

        return view;
    }


    public void loadMore()
    {

        lstModel.clear();
        lstModel.add( new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái",3, "21-08-2020","2:20" ));
        lstModel.add( new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái",3, "21-08-2020","2:20" ));
        lstModel.add( new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái",3, "21-08-2020","2:20" ));
        lstModel.add( new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái",3, "21-08-2020","2:20" ));
        lstModel.add( new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái",3, "21-08-2020","2:20" ));
        lstModel.add( new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái",3, "21-08-2020","2:20" ));
        lstModel.add( new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái",3, "21-08-2020","2:20" ));
        lstModel.add( new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái",3, "21-08-2020","2:20" ));

        showCommentAdapter = new ShowCommentAdapter(getContext(),lstModel);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, true);
        rcvShowComment.setLayoutManager(layoutManager);
        rcvShowComment.setAdapter(showCommentAdapter);
        showCommentAdapter.notifyDataSetChanged();
    }

    private void loadLess()
    {
        lstModel.clear();
        lstModel.add( new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái",3, "21-08-2020","2:20" ));
        lstModel.add( new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái",3, "21-08-2020","2:20" ));
        lstModel.add( new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái",3, "21-08-2020","2:20" ));

        showCommentAdapter = new ShowCommentAdapter(getContext(),lstModel);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, true);
        rcvShowComment.setLayoutManager(layoutManager);
        rcvShowComment.setAdapter(showCommentAdapter);
        showCommentAdapter.notifyDataSetChanged();
    }


    private void toRate() {

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

        LayoutInflater inflater = LayoutInflater.from(getContext());
        View dialogView = inflater.inflate(R.layout.rating_dialog, null);
        builder.setView(dialogView);

        final RatingBar rb_rating = dialogView.findViewById(R.id.rb_rating);
        final TextView txt_sendCmt = dialogView.findViewById(R.id.txt_sendCmt);
        final TextView txt_cancel = dialogView.findViewById(R.id.txt_cancel);
        final EditText txt_content_cmt = dialogView.findViewById(R.id.txt_content_cmt);

        final AlertDialog dialog = builder.create();
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

//        LinearLayout star5, star4, star3, star2;
//
//        star2 = (LinearLayout) dialogView.findViewById(R.id.ln_rating2);
//        star3 = (LinearLayout) dialogView.findViewById(R.id.ln_rating3);
//        star4 = (LinearLayout) dialogView.findViewById(R.id.ln_rating4);
//        star5 = (LinearLayout) dialogView.findViewById(R.id.ln_rating5);
//
//        star2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(getContext(), "Thank you for your rating!!", Toast.LENGTH_SHORT).show();
//                getActivity().getWindow()
//                        .setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
//                dialog.dismiss();
//            }
//        });
//
//        star3.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(getContext(), "Thank you for your rating!!", Toast.LENGTH_SHORT).show();
//                getActivity().getWindow()
//                        .setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
//                dialog.dismiss();
//            }
//        });
//
//        star4.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(getContext(), "Thank you for your rating!!", Toast.LENGTH_SHORT).show();
//                getActivity().getWindow()
//                        .setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
//                dialog.dismiss();
//            }
//        });
//
//        star5.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(getContext(), "Thank you for your rating!!", Toast.LENGTH_SHORT).show();
//                getActivity().getWindow()
//                        .setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
//                dialog.dismiss();
//            }
//        });
//
////                dialog.getWindow().setGravity(Gravity.BOTTOM);
        dialog.show();
        txt_cancel.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        txt_sendCmt.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                lstModel.add(new ShowCommentModel(1, "NGUYEN VAN A", txt_content_cmt.getText().toString(), rb_rating.getRating(), "27-8-2020", "9:47"));
                showCommentAdapter.notifyDataSetChanged();
                dialog.dismiss();
            }
        });
    }

}
