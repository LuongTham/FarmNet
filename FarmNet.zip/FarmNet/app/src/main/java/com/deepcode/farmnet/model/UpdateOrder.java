package com.deepcode.farmnet.model;

public class UpdateOrder   {
}
