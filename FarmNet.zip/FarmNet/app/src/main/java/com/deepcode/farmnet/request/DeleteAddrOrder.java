package com.deepcode.farmnet.request;

public class DeleteAddrOrder {
    private long addrID;

    private long accountID;

    public long getAddrID() {
        return addrID;
    }

    public void setAddrID(long addrID) {
        this.addrID = addrID;
    }

    public long getAccountID() {
        return accountID;
    }

    public void setAccountID(long accountID) {
        this.accountID = accountID;
    }

}
