package com.deepcode.farmnet.adapter;

import android.app.Activity;
import android.content.Context;
import android.graphics.Paint;
import android.os.AsyncTask;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.bean.Cart;
import com.deepcode.farmnet.core.Connector;
import com.deepcode.farmnet.core.Data;
import com.deepcode.farmnet.core.FarmNetStatic;
import com.deepcode.farmnet.core.ImageUtil;
import com.deepcode.farmnet.core.URL_FarmNet;
import com.deepcode.farmnet.fragment.ChatFragment;
import com.deepcode.farmnet.fragment.FarmDetailFragment;
import com.deepcode.farmnet.fragment.FarmFragment;
import com.deepcode.farmnet.fragment.HomeFragment;
import com.deepcode.farmnet.fragment.ListOrderFragment;
import com.deepcode.farmnet.model.Order;
import com.deepcode.farmnet.model.ProductModelReal;
import com.deepcode.farmnet.model.Rating;
import com.google.gson.Gson;

import java.io.IOException;
import java.util.List;

public class ListProductFarmAdapter extends RecyclerView.Adapter<ListProductFarmAdapter.RecyclerViewHolder> {

    List<ProductModelReal> listProduct;
    MainActivity contex;

    public ListProductFarmAdapter(List<ProductModelReal> list, MainActivity mContex) {
        contex = mContex;
        listProduct = list;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.item_pro_farm, parent, false);
        return new ListProductFarmAdapter.RecyclerViewHolder(view);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, final int position) {

        if (listProduct.size() > 0) {
            final ProductModelReal productModelReal = listProduct.get(position);
           holder.txtName.setText(productModelReal.getName());
          //  holder.txtFarm.setText(productModelReal.getFarmId() + "");
            if (productModelReal.getDiscount() > 0) {
                holder.txtPrice.setText(productModelReal.getPrice() + " đ/" + productModelReal.getUnit());
                holder.txtOldPrice.setPaintFlags(holder.txtOldPrice.getPaintFlags());

                if (productModelReal.getCount() == 1) {
                    holder.txtPrice.setText((productModelReal.getPrice() - productModelReal.getDiscount()) + " đ/" +
                            productModelReal.getUnit());
                } else {
                    holder.txtPrice.setText((productModelReal.getPrice() - productModelReal.getDiscount()) + " đ/" +
                            productModelReal.getCount() + productModelReal.getUnit());
                }

                holder.txtSale.setText("Sale:" + phantram(productModelReal.getDiscount(), productModelReal.getPrice()) + "%");
                System.out.println("discout+" + phantram(productModelReal.getDiscount(), productModelReal.getPrice()) + "ten" + productModelReal.getName());

            } else {
                holder.txtSale.setVisibility(View.GONE);
              //  holder.txtFarm.setVisibility(View.GONE);
                holder.txtPrice.setText(productModelReal.getPrice() + " đ/" + productModelReal.getUnit());
            }

            if (productModelReal.getImage() != null) {
                holder.imageView.setImageBitmap(ImageUtil.bitmapFromBase64(productModelReal.getImage()));
            }

            if ((position % 3) == 0) {
               // holder.rtbProductRating.setVisibility(View.GONE);
               //holder.tv_rating.setAutofillHints("Chưa có đánh giá");
            } else {
                holder.tv_rating.setVisibility(View.GONE);
            }
            holder.rl_item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    MainActivity mainActivity = (MainActivity) contex;
                    mainActivity.showTabProductDetail();
                    Toast.makeText(contex, "Chi tiết SP: " + productModelReal.getName(), Toast.LENGTH_SHORT).show();
                }
            });

            holder.btnAddToCart.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                  //  Order acc = new Order(productModelReal.getName(), productModelReal.getImage(), 1, productModelReal.getPrice(), 0);
                //    Data.orderList.add(acc);



                    new AsyncTaskSendItemCart(listProduct.get(position)).execute();
                    Toast.makeText(contex, "Thêm vào giỏ hàng: " + productModelReal.getName(), Toast.LENGTH_SHORT).show();

                }

            });

        }

    }

    @Override
    public int getItemCount() {
        return listProduct.size();
    }

    public class RecyclerViewHolder extends RecyclerView.ViewHolder {
        ImageView btnAddToCart;
        TextView txtOldPrice;
        TextView txtName;
        TextView tvDetail;
        TextView txtPrice;
   //     TextView txtFarm;
        //        TextView txtProduct;
        ImageView imageView;
        TextView txtSale;
        RelativeLayout rl_item;
        RatingBar rtbProductRating;
        RatingBar tv_rating;

        public RecyclerViewHolder(View itemView) {
            super(itemView);
            btnAddToCart = (ImageView) itemView.findViewById(R.id.btn_addToCart);
            txtName = (TextView) itemView.findViewById(R.id.tvProduct);
            txtPrice = (TextView) itemView.findViewById(R.id.tvPrice);
            tvDetail = (TextView) itemView.findViewById(R.id.tvDetail);
       //   txtFarm = (TextView) itemView.findViewById(R.id.tvFarm);
            rl_item = (RelativeLayout) itemView.findViewById(R.id.rl_item);
            imageView = (ImageView) itemView.findViewById(R.id.avaImage);
            txtSale = (TextView) itemView.findViewById(R.id.tv_sale);
            txtOldPrice = (TextView) itemView.findViewById(R.id.tv_oldPrice);
            rtbProductRating = (RatingBar) itemView.findViewById(R.id.rtbProductRating);
           tv_rating = (RatingBar) itemView.findViewById(R.id.tv_rating);
        }
    }

    public int phantram(long dis, long price) {
        int a;
        a = (int) ((dis * 100) / price);

        return a;
    }

    public class AsyncTaskSendItemCart extends AsyncTask<Void, Void, Void>
    {
        String responseString = null;
        Gson gson = new Gson();
        Cart cart = new Cart();

        ProductModelReal productModelReal;

        public AsyncTaskSendItemCart(ProductModelReal productModelReal)
        {
            this.productModelReal = productModelReal;
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            cart.set_id(1);
            cart.setAccountId(FarmNetStatic.getInstance().getAccount().getAccountID());
            cart.setAddress("");
            cart.setCreatedDate(FarmNetStatic.getInstance().getAccount().getCreatedDate());
            cart.setUserName(FarmNetStatic.getInstance().getAccount().getName());
            cart.setStatus(1);
            cart.setPhone("");
            cart.setNote("");
            cart.setDeviceId(FarmNetStatic.getInstance().getDeviceId());
            cart.setProductOrcomboId(productModelReal.getProductID());
            cart.setCombo(false);
            cart.setDelete(false);

            System.out.println("IDID:"+productModelReal.getProductID());

        }

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                responseString =  Connector.doPostRequest(Connector.rootURL+ URL_FarmNet.ADD_CART
                        ,gson.toJson(cart));

                System.out.println("Response1111111:"+ responseString);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            updateCountCart();
           // btnAddToCart.
           // new AsyncTaskSendItemCart().execute();
        }
    }
    public void updateCountCart() {
        ListOrderFragment fragment = (ListOrderFragment)contex.getSupportFragmentManager().findFragmentById(R.id.order_fragment);
        fragment.refresh();

    }
}

