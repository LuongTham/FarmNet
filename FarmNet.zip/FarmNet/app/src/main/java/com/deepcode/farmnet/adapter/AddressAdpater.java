package com.deepcode.farmnet.adapter;


import android.content.Context;
import android.icu.text.Transliterator;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.bean.AddressOrder;
import com.deepcode.farmnet.core.Connector;
import com.deepcode.farmnet.core.FarmNetStatic;
import com.deepcode.farmnet.core.URL_FarmNet;
import com.deepcode.farmnet.fragment.AddressFragment;
import com.deepcode.farmnet.fragment.ChatFragment;
import com.deepcode.farmnet.fragment.ListOrderFragment;
import com.deepcode.farmnet.request.CartId;
import com.deepcode.farmnet.request.DeleteAddrOrder;
import com.google.gson.Gson;


import net.igenius.customcheckbox.CustomCheckBox;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AddressAdpater extends RecyclerView.Adapter<AddressAdpater.ViewHolder> {
    private MainActivity context;
    private List<AddressOrder> lstAddress = new ArrayList<AddressOrder>();
    public AddressAdpater(MainActivity context, List<AddressOrder> lstAddress) {
        this.context = context;
        this.lstAddress = lstAddress;

    }




    @NonNull
    @Override
    public AddressAdpater.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_address, parent, false);

        return new ViewHolder(view);
    }

    private int selectionPosition = -1;

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int position) {
        AddressOrder address = lstAddress.get(position);
        holder.name.setText(address.getName());
        holder.addressDetail.setText(address.getDetailAddress());
        holder.phone.setText(address.getPhone());
        holder.addressDetail.setText(address.getProvince() +", "+ address.getDistrict() +", "+ address.getWard());

//        holder.btncheck.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                holder.btncheck.setClickable(true);
//                holder.btncheck.getResources().getDrawable(R.drawable.shape_checked);
//                holder.btncheck.setClickable(false);
//            }
//        });



       // holder.btncheck.setChecked(selectionPosition== position);

       if(address.isCheck())
       {
           holder.btncheck.setChecked(true);
       }else
       {
           holder.btncheck.setChecked(false);
       }
        holder.btncheck.setOnCheckedChangeListener(new CustomCheckBox.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CustomCheckBox checkBox, boolean isChecked) {
                Log.d("CustomCheckBox", String.valueOf(isChecked));


               selectionPosition = holder.getAdapterPosition();

               if(holder.btncheck.isChecked())
               {

                   FarmNetStatic.setAddressDefaul(lstAddress.get(position));
               }
              // notifyDataSetChanged();

            //    notifyItemChanged(position);

              //  AddressFragment addressFragment = (AddressFragment)context.find
                AddressFragment fragment = (AddressFragment)context.getSupportFragmentManager().findFragmentById(R.id.address_fragment);
                fragment.adpaterChange(position);
             //   this.notify();

            }
        });
        holder.btn_Edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


            }
        });
        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog(position);
            }
        });

    }

    @Override
    public int getItemCount() {
        return lstAddress.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        CustomCheckBox btncheck;
                ImageView edit, delete, btn_Edit;

        TextView name,phone, addressDetail;


        public  boolean check = false;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            btncheck = (CustomCheckBox)itemView.findViewById(R.id.checkb);
            edit = itemView.findViewById(R.id.btn_edit);
            delete = itemView.findViewById(R.id.btn_delete);
            name = itemView.findViewById(R.id.txt_name);
            phone = itemView.findViewById(R.id.txt_phone);
            addressDetail = itemView.findViewById(R.id.txt_address);
            btn_Edit = itemView.findViewById(R.id.btn_edit);
            check  = false;


        }

    }
    private void dialog(final int position){
        AlertDialog.Builder builder = new AlertDialog.Builder(context);

        LayoutInflater inflater = LayoutInflater.from(context);
        View dialogView = inflater.inflate(R.layout.dialog_delete_address_item, null);
        builder.setView(dialogView);
        //setView(dialogView);

        final TextView txt_content = dialogView.findViewById(R.id.txt_content);
        final TextView btn_accept = dialogView.findViewById(R.id.btn_accept);
        final TextView btn_no = dialogView.findViewById(R.id.btn_no);

        final AlertDialog dialog = builder.create();
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.show();
        btn_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        btn_accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DeleteAddrOrder deleteAddrOrder = new DeleteAddrOrder();
                deleteAddrOrder.setAddrID(lstAddress.get(position).getAddressOrderID());
                deleteAddrOrder.setAccountID(FarmNetStatic.getInstance().getAccount().getAccountID());
                new AsyncTaskDeleteAddress(deleteAddrOrder).execute();
                dialog.dismiss();
                Toast.makeText(context,"Xóa địa chỉ thành công", Toast.LENGTH_SHORT).show();
            }
        });

    }

    public class AsyncTaskDeleteAddress extends AsyncTask {
        Gson gson = new Gson();
        String jsonString;
        DeleteAddrOrder deleteAddrOrder;

        public AsyncTaskDeleteAddress(DeleteAddrOrder deleteAddrOrder)
        {
            this.deleteAddrOrder = deleteAddrOrder;

        }
        @Override
        protected void onPreExecute() {

        }

        @Override
        protected Object doInBackground(Object[] objects) {

            try {
                jsonString = Connector.doPostRequest(Connector.rootURL + URL_FarmNet.GETLIST_DeleteAddress, gson.toJson(deleteAddrOrder));
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            AddressFragment fragment = (AddressFragment) context.getSupportFragmentManager().findFragmentById(R.id.address_fragment);
            fragment.refresh();

            super.onPostExecute(o);
        }
    }
}
