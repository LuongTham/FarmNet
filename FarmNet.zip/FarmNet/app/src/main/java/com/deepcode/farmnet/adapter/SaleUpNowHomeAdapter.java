package com.deepcode.farmnet.adapter;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.R;
import com.deepcode.farmnet.bean.TopProduct;
import com.deepcode.farmnet.core.ImageUtil;

import java.util.List;

public class SaleUpNowHomeAdapter extends RecyclerView.Adapter<SaleUpNowHomeAdapter.ViewHolder> {
    List<TopProduct> listProductsale;
    public SaleUpNowHomeAdapter(List<TopProduct> list)
    {
        listProductsale = list;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.item_sale_up_now_home, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        TopProduct productModel = listProductsale.get(position);
        holder.imageView.setImageBitmap(ImageUtil.bitmapFromBase64(productModel.getImage()));
        holder.price.setText(productModel.getPrice());
        holder.name.setText(productModel.getProductName());

    }

    @Override
    public int getItemCount() {
        return listProductsale.size() ;
    }//listProductsale.size()

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView name;
        ImageView imageView;
        TextView price;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.tvProduct1);
            imageView = itemView.findViewById(R.id.imgIcon1);
            price = itemView.findViewById(R.id.btn_sale);
        }
    }
}
