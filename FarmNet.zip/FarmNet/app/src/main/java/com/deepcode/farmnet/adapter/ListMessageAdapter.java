package com.deepcode.farmnet.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.R;
import com.deepcode.farmnet.bean.Message;
import com.deepcode.farmnet.model.MessageModel;

import java.util.List;

public class ListMessageAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>
{

    List<Message> listMessage;

    public ListMessageAdapter(List<Message> listMessage)
    {
        this.listMessage = listMessage;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {


        switch (viewType){

            case 0:
                LayoutInflater inflater1 = LayoutInflater.from(parent.getContext());
                View view1 = inflater1.inflate(R.layout.chat_item_receive, parent, false);
                return new ViewHolderChatReceive(view1);

            case 1:

                LayoutInflater inflater2 = LayoutInflater.from(parent.getContext());
                View view2 = inflater2.inflate(R.layout.chat_item_send, parent, false);
                return new ViewHolderChatSend(view2);

        }
        LayoutInflater inflater1 = LayoutInflater.from(parent.getContext());
        View view1 = inflater1.inflate(R.layout.chat_item_receive, parent, false);
        return new ViewHolderChatReceive(view1);    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {


        Message message = listMessage.get(position);

      if(getItemViewType(position)==1)
      {

          ViewHolderChatSend viewHolderChatSend = (ViewHolderChatSend)holder;

          viewHolderChatSend.tvSend.setText(message.getMsg());

      }else
      {
          ViewHolderChatReceive viewHolderChatReceive = (ViewHolderChatReceive)holder;

          viewHolderChatReceive.tvRecieve.setText(message.getMsg());
      }

    }

    @Override
    public int getItemCount() {
        return listMessage.size();
    }

    @Override
    public int getItemViewType(int position) {
        Message message = listMessage.get(position);

        if(message.getSendId()==0)
        {
          return  0;
        }
        return 1;
    }

    class ViewHolderChatSend extends RecyclerView.ViewHolder
    {


        TextView tvSend;


        public ViewHolderChatSend(@NonNull View itemView) {
            super(itemView);

            tvSend = (TextView)itemView.findViewById(R.id.tvSend);
        }
    }

    class ViewHolderChatReceive extends RecyclerView.ViewHolder
    {

        TextView tvRecieve;
        public ViewHolderChatReceive(@NonNull View itemView) {
            super(itemView);

            tvRecieve = (TextView)itemView.findViewById(R.id.tvRecieve);
        }
    }
}
