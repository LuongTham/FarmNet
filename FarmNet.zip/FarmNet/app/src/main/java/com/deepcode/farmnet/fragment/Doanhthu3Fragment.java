package com.deepcode.farmnet.fragment;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.deepcode.farmnet.R;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;

import java.util.ArrayList;


public class Doanhthu3Fragment extends BaseFragment{
    BarChart barChart;


    private ArrayList<BarEntry> dataValue1()
    {
        ArrayList<BarEntry> dataVals = new ArrayList<>();
        dataVals.add(new BarEntry(0,110));
        dataVals.add(new BarEntry(1,50));
        dataVals.add(new BarEntry(2,80));
        dataVals.add(new BarEntry(3,120));

        return dataVals;
    }

    private ArrayList<BarEntry> dataValue2()
    {
        ArrayList<BarEntry> dataVals = new ArrayList<>();
        dataVals.add(new BarEntry(0,60));
        dataVals.add(new BarEntry(1,90));
        dataVals.add(new BarEntry(2,40));
        dataVals.add(new BarEntry(3,70));

        return dataVals;
    }

    private ArrayList<BarEntry> dataValue3()
    {
        ArrayList<BarEntry> dataVals = new ArrayList<>();
        dataVals.add(new BarEntry(0,50));
        dataVals.add(new BarEntry(1,60));
        dataVals.add(new BarEntry(2,100));
        dataVals.add(new BarEntry(3,90));

        return dataVals;
    }

    @Override
    public void constructorView() {

    }

    @Override
    public void setOnClick() {

    }

    @Override
    public void loadDateView() {

    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_doanhthu3,container,false);



        barChart = (BarChart)view.findViewById(R.id.group_BarChart);

        BarDataSet barDataSet1 = new BarDataSet(dataValue1(),"Thit bo");
        barDataSet1.setColor(Color.BLUE);

        BarDataSet barDataSet2 = new BarDataSet(dataValue2(),"Tom hum");
        barDataSet2.setColor(Color.RED);

        BarDataSet barDataSet3 = new BarDataSet(dataValue3(),"Rau cai");
        barDataSet3.setColor(Color.YELLOW);

        BarData barData = new BarData(barDataSet1, barDataSet2, barDataSet3);



        barChart.setData(barData);
        barChart.invalidate();


        String[] days = new String[]{"Thang 1", "Thang 2", "Thang 3" };
        XAxis xAxis = barChart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(days));
        xAxis.setCenterAxisLabels(true);

        xAxis.setAxisLineWidth(0.04f);     //  kich thuwoc
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1);
        xAxis.setGranularityEnabled(true);

        barChart.setDragEnabled(true);
        barChart.setVisibleXRangeMaximum(3);   // so luong cot

        float barSpace = 0.08f;
        float groupSpace = 0.40f;
        barData.setBarWidth(0.10f);
        barChart.getXAxis().setAxisMaximum(0+barChart.getBarData().getGroupWidth(groupSpace,barSpace)*3);
        barChart.getXAxis().setAxisMinimum(0);
        //barChart.getAxisLeft().setAxisMinimum(0);
        barChart.groupBars(0,groupSpace,barSpace);
        barChart.invalidate();

        return view;


    }
}
