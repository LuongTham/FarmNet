package com.deepcode.farmnet.fragment;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentTransaction;

import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.bean.Cart;
import com.deepcode.farmnet.bean.Message;
import com.deepcode.farmnet.core.Connector;
import com.deepcode.farmnet.core.FarmNetStatic;
import com.deepcode.farmnet.core.URL_FarmNet;
import com.google.gson.Gson;

import java.io.IOException;

public class FarmFragment extends  BaseFragment {
    @Override
    public void constructorView() {

    }

    @Override
    public void setOnClick() {

    }

    @Override
    public void loadDateView() {

    }
    RelativeLayout btnChat;
    RelativeLayout btnShoppingCart;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        super.onCreateView(inflater,container,savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_farm, container, false);
        btnChat = (RelativeLayout) view.findViewById(R.id.r_r);

        btnChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity mainActivity = (MainActivity)getActivity();
                mainActivity.showTabChat();

            }
        });
        btnShoppingCart = (RelativeLayout)view.findViewById(R.id.r_shoppingcar);
        btnShoppingCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                MainActivity mainActivity = (MainActivity)getActivity();
                mainActivity.showTabOrder();

                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.order_fragment,new ListOrderFragment()).addToBackStack("").commit();

            }
        });
        return view;    }

}
