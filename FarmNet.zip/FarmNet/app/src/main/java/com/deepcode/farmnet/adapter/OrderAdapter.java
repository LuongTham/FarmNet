package com.deepcode.farmnet.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Paint;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.bean.Cart;
import com.deepcode.farmnet.core.Connector;
import com.deepcode.farmnet.core.ImageUtil;
import com.deepcode.farmnet.core.URL_FarmNet;
import com.deepcode.farmnet.fragment.AddressFragment;
import com.deepcode.farmnet.fragment.ChatFragment;
import com.deepcode.farmnet.fragment.ListOrderFragment;
import com.deepcode.farmnet.fragment.OrderHistoryFragment;
import com.deepcode.farmnet.model.Order;
import com.deepcode.farmnet.model.ProductMoreOrder;
import com.deepcode.farmnet.request.CartId;
import com.deepcode.farmnet.response.CartResponse;
import com.google.gson.Gson;

import org.w3c.dom.Text;

import java.io.IOException;
import java.util.List;

import static java.lang.Math.exp;
import static java.lang.Math.round;

public class OrderAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    public List<CartResponse> listOrder;
    public List<ProductMoreOrder> productMoreOrderList;


    public MainActivity context;
    public OrderAdapter( MainActivity context, List<CartResponse> listOrder, List<ProductMoreOrder> productMoreOrders) {
        this.listOrder = listOrder;
        this.productMoreOrderList = productMoreOrderList;

        this.context = context;
    }

    public OrderAdapter() {
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        switch (viewType) {
            case 0:
                LayoutInflater inflater1 = LayoutInflater.from(parent.getContext());
                View view1 = inflater1.inflate(R.layout.order_item_row, parent, false);
                return new ViewHolderOrder(view1);
            case 1:
                LayoutInflater inflater2 = LayoutInflater.from(parent.getContext());
                View view2 = inflater2.inflate(R.layout.order_item_freeship, parent, false);
                return new ViewHolderFreeShip(view2);
            case 2:
                LayoutInflater inflater3 = LayoutInflater.from(parent.getContext());
                View view3 = inflater3.inflate(R.layout.order_item_more_like, parent, false);
                return new ViewHolderMoreLike(view3);
            case 3:
                LayoutInflater inflater4 = LayoutInflater.from(parent.getContext());
                View view4 = inflater4.inflate(R.layout.order_item_more_product, parent, false);
                return new ViewHolderMoreProduct(view4);
        }
        return null;
    }

    int itemCount = 0;

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {

        if (position < listOrder.size()) {

            final ViewHolderOrder mHolder = (ViewHolderOrder) holder;
            //show name
            mHolder.tvName.setText(listOrder.get(position).getName());

            //show ava
            if (listOrder.get(position).getImage() != null) {
                mHolder.avatar.setImageBitmap(ImageUtil.bitmapFromBase64(listOrder.get(position).getImage()));
            }

            //format number price
            int txt = round(listOrder.get(position).getPrice() * (1 - listOrder.get(position).getDiscount()));
//            String ss = String.format("%,d", Long.parseLong("" + txt));
//            mHolder.tvPriceKM.setText(ss + "đ");
//            String ss1 = String.format("%,d", Long.parseLong("" + listOrder.get(position).getPrice()));
//            mHolder.tvPriceOrigin.setText(ss1 + "đ");

            //non strike original price if discount = 0
            if (listOrder.get(position).getDiscount() == 0) {
                mHolder.tvPriceOrigin.setPaintFlags(mHolder.tvPriceOrigin.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
            }


//            mHolder.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//                @Override
//                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
//                    if (b) {
//                        listOrder.get(position).setCount(Integer.parseInt(mHolder.txtCount.getText().toString()));
//                        updateTotalMoney();
//                    } else {
//                        listOrder.get(position).setCount(0);
//                        updateTotalMoney();
//                    }
//                }
//            });

            //resolve amount
            //  mHolder.txtCount.setText(listOrder.get(position).getCount() + "");
            mHolder.btnDec.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (Integer.parseInt(mHolder.txtCount.getText().toString()) == 1) {
                        // listOrder.get(position).setCount(listOrder.get(position).getCount() - 1);
                        //mHolder.txtCount.setText(listOrder.get(position).getCount() + "");
                    }
                    if (Integer.parseInt(mHolder.txtCount.getText().toString()) > 0) {
                        //   mHolder.checkBox.setChecked(true);
                        // listOrder.get(position).setCount(listOrder.get(position).getCount() - 1);
                        mHolder.txtCount.setText(1 + "");
                        updateTotalMoney();
                    } else {
                        //   mHolder.checkBox.setChecked(false);
                        updateTotalMoney();
                    }
                }
            });

            mHolder.btnInc.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //    mHolder.checkBox.setChecked(true);
                    // listOrder.get(position).setCount( 1);
                    /// mHolder.txtCount.setText(listOrder.get(position).getCount() + "");
                    updateTotalMoney();
                }
            });
            mHolder.btnDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    toDelete(position);
                }
            });


        }

    }

    private void toDelete(final int position) {

        AlertDialog.Builder builder = new AlertDialog.Builder(context);

        LayoutInflater inflater = LayoutInflater.from(context);
        View dialogView = inflater.inflate(R.layout.delete_item_cart_dialog, null);
        builder.setView(dialogView);

        final TextView txt_content = dialogView.findViewById(R.id.txt_content);
        final TextView btn_accept = dialogView.findViewById(R.id.btn_accept);
        final TextView btn_no = dialogView.findViewById(R.id.btn_no);

        final AlertDialog dialog = builder.create();
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.show();
        btn_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        btn_accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                CartId  cartId = new CartId();
                cartId.setId(listOrder.get(position).getId());
                new AsyncTackDeleteCart(cartId).execute();
                dialog.dismiss();
                Toast.makeText(context,"Xóa sản phẩm thành công!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateTotalMoney() {
        long money = 0;
        for (int i = 0; i < listOrder.size(); i++) {
            money = money + round(listOrder.get(i).getPrice()
                    * (1 - listOrder.get(i).getDiscount()));
        }
        ListOrderFragment.totalMoney.setText("Tổng tiền: " + String.format("%,d", Long.parseLong("" + money)));
    }

    @Override
    public int getItemCount() {
        return listOrder.size();
    }

    @Override
    public int getItemViewType(int position) {
        if (position < listOrder.size()) {
            return 0;
        } else if (position == listOrder.size()) {
            return 1;
        } else if (position == listOrder.size() + 1) {
            return 2;
        } else {
            return 3;
        }
    }

    class ViewHolderOrder extends RecyclerView.ViewHolder {
        TextView tvName, txtCount;
        ImageView btnDec, btnInc;
        Button expandFarm;
        ImageView avatar, btnDelete;
        TextView tvPriceOrigin;
        TextView tvPriceKM;
        TextView checkBox;

        public ViewHolderOrder(@NonNull View itemView) {
            super(itemView);

            avatar = (ImageView) itemView.findViewById(R.id.imgIcon);
            btnDec = (ImageView) itemView.findViewById(R.id.decItemUnit);
            btnInc = (ImageView) itemView.findViewById(R.id.incItemUnit);
            expandFarm = (Button) itemView.findViewById(R.id.expandFarm);
            // checkBox = (TextView) itemView.findViewById(R.id.btnDelete);
            tvName = (TextView) itemView.findViewById(R.id.tvProduct);
            txtCount = (TextView) itemView.findViewById(R.id.txtCount);
            tvPriceKM = (TextView) itemView.findViewById(R.id.tvPriceKM);
            btnDelete = (ImageView) itemView.findViewById(R.id.btnDelete);
            tvPriceOrigin = (TextView) itemView.findViewById(R.id.tvPriceOrigin);
            tvPriceOrigin.setPaintFlags(tvPriceOrigin.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);

        }
    }

    class ViewHolderFreeShip extends RecyclerView.ViewHolder {
        public ViewHolderFreeShip(@NonNull View itemView) {
            super(itemView);
        }
    }

    class ViewHolderMoreLike extends RecyclerView.ViewHolder {
        public ViewHolderMoreLike(@NonNull View itemView) {
            super(itemView);
        }
    }

    class ViewHolderMoreProduct extends RecyclerView.ViewHolder {

        public ViewHolderMoreProduct(@NonNull View itemView) {
            super(itemView);

        }
    }
    public class AsyncTackDeleteCart extends AsyncTask {
        Gson gson = new Gson();
        String jsonString = null;

        CartId cartId;
        public AsyncTackDeleteCart(CartId cartId)
        {
            this.cartId = cartId;

        }
        @Override
        protected void onPreExecute() {

            super.onPreExecute();
        }

        @Override
        protected Object doInBackground(Object[] objects) {
            try
            {
                jsonString = Connector.doPostRequest(Connector.rootURL+ URL_FarmNet.DELETE_CART, gson.toJson(cartId));
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            ListOrderFragment fragment = (ListOrderFragment) context.getSupportFragmentManager().findFragmentById(R.id.order_fragment);
            fragment.refresh();

            super.onPostExecute(o);


        }
    }


}
