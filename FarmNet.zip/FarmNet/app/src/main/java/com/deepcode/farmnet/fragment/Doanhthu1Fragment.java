package com.deepcode.farmnet.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.deepcode.farmnet.R;
import com.deepcode.farmnet.adapter.DoanhthuAdapter;
import com.deepcode.farmnet.model.ProductDemo;

import java.util.ArrayList;
import java.util.List;

public class Doanhthu1Fragment extends BaseFragment {
    RecyclerView recyclerView;
    DoanhthuAdapter doanhthuAdapter;
    List<ProductDemo> productDemoList = new ArrayList<>();



    @Override
    public void constructorView() {

    }

    @Override
    public void setOnClick() {

    }

    @Override
    public void loadDateView() {

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_doanhthu1, container, false);

        recyclerView = view.findViewById(R.id.rv_doanhthu);
        System.out.println("111111111111");
        for(int i = 0;i<20;i++)
        {
            ProductDemo pro = new ProductDemo();
            pro.setStt(i+1);
            pro.setName("Thitbo");
           pro.setSoLuong((i+1)*2);
           if((i%2)==0)
           {
               pro.setType("single");
            }
           else pro.setType("combo");
            pro.setDoanhThu(10*(i+1));
            productDemoList.add(pro);
            System.out.println("2222");
        }

        doanhthuAdapter = new DoanhthuAdapter(productDemoList,getContext());
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(doanhthuAdapter);
        recyclerView.setLayoutManager(layoutManager);
        return view ;
    }

}
