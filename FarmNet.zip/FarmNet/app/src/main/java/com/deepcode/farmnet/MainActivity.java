package com.deepcode.farmnet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Resources;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.deepcode.farmnet.adapter.OrderAdapter;
import com.deepcode.farmnet.bean.Account;
import com.deepcode.farmnet.bean.Message;
import com.deepcode.farmnet.core.Connector;
import com.deepcode.farmnet.core.Data;
import com.deepcode.farmnet.core.FarmNetStatic;
import com.deepcode.farmnet.core.URL_FarmNet;
import com.deepcode.farmnet.farmnet_interface.UpdateInterface;
import com.deepcode.farmnet.fragment.AccountFragment;
import com.deepcode.farmnet.fragment.ChatFragment;
import com.deepcode.farmnet.fragment.HomeFragment;
import com.deepcode.farmnet.fragment.ListOrderFragment;
import com.deepcode.farmnet.fragment.OrderHistoryFragment;
import com.deepcode.farmnet.request.AccountId;
import com.deepcode.farmnet.request.DeviceId;
import com.deepcode.farmnet.request.GetMessageId;
import com.deepcode.farmnet.response.CartResponse;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;

public class MainActivity extends AppCompatActivity implements UpdateInterface
{
    public boolean isChecked = false;
    public static RelativeLayout btnHome;
    public static RelativeLayout btnProduct;
    public static RelativeLayout btnFarm;
    //RelativeLayout btnOrder;
    public static RelativeLayout btnAccount;
    public static RelativeLayout btnNotification;

    public static RelativeLayout tabHome;
    public static RelativeLayout tabProduct;
    public static RelativeLayout tabOrder;
    public static RelativeLayout tabBottom;
    public static RelativeLayout tabNotification;
    public static RelativeLayout tabChat;
    public static RelativeLayout tabAddress;
    public static RelativeLayout tabAccount;
    public static RelativeLayout tabFarm;
    public static RelativeLayout tabSearch;
    public static RelativeLayout tabCombo;
    public static RelativeLayout tabProductDetail;
    public static RelativeLayout tabPayment;
    public static RelativeLayout tabAddNewAddress;
    public static RelativeLayout tabManageOrder;



    public static ImageView imageViewHome;
    public static ImageView imageViewProduct;
    public static ImageView imageViewFarm;
    public static ImageView imageViewNotification;
    public static ImageView imageViewAccount;


    public static TextView textViewHome;


    public  static  MainActivity newInstance = null;

    public static  MainActivity getInstance()
    {
        if(newInstance == null){
            newInstance = new MainActivity();
        }
        return  newInstance;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        constructorView();
        setOnAction();

         String android_id = Settings.Secure.getString(getApplication().getContentResolver(),
                Settings.Secure.ANDROID_ID);

        FarmNetStatic.getInstance().setDeviceId(android_id);
        new AsyncTaskCheckAccount().execute();

        startSocket();
        ChatFragment fragment = (ChatFragment)getSupportFragmentManager().findFragmentById(R.id.chat_fragment);
        fragment.refresh();



    }

    public void updateOrderFragment()
    {
        ListOrderFragment fragment = (ListOrderFragment)getSupportFragmentManager().findFragmentById(R.id.order_fragment);
        fragment.refresh();

    }

    @Override
    public void updateCountCart() {
        HomeFragment fragment = (HomeFragment)getSupportFragmentManager().findFragmentById(R.id.home_fragment);
        fragment.updateCountCart();

    }

    @Override
    public void updateCountMessage() {
        HomeFragment fragment = (HomeFragment)getSupportFragmentManager().findFragmentById(R.id.home_fragment);
        fragment.updateCountMessage();

    }


    public class AsynTaskCreatNewAccount extends AsyncTask <Void, Void, Void>
    {
        Account account = null;
        String responseString;

        Gson gson  = new Gson();
        @Override
        protected Void doInBackground(Void... voids) {

            Account account = new Account();
            account.setDeviceId(FarmNetStatic.getInstance().getDeviceId());
            account.setAnonymous(true);
            account.setDelete(false);

            try {
                responseString = Connector.doPostRequest(Connector.rootURL+ URL_FarmNet.url_createNewAccount
                        ,gson.toJson(account));

                System.out.println("Rsspone:"+ responseString);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            try{
                account = gson.fromJson(responseString, Account.class);

                FarmNetStatic.getInstance().setAccount(account);
                ChatFragment fragment = (ChatFragment)getSupportFragmentManager().findFragmentById(R.id.chat_fragment);
                fragment.refresh();
            }catch (Exception ex)
            {

            }

            if(account!= null)
            {
                new AsyncTaskGetMessage().execute();

                new AsyncTaskGetItemCart().execute();

                updateOrderFragment();
                System.out.println("Create Account Success");
            }else
            {
                System.out.println("Crate Account Fail");
            }

            super.onPostExecute(aVoid);
        }
    }

    public class AsyncTaskCheckAccount extends AsyncTask<Void, Void, Void>
    {
        Account account = null;
        String responseString;
        Gson gson  = new Gson();

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... voids) {

            DeviceId deviceId = new DeviceId();

            deviceId.setId(FarmNetStatic.getInstance().getDeviceId());
            try {
                responseString  = Connector.doPostRequest(Connector.rootURL+ URL_FarmNet.url_checkExistDeviceID
                        ,gson.toJson(deviceId));

                System.out.println("AcccountRes:"+ responseString);
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            try{
                account = gson.fromJson(responseString, Account.class);

            }catch (Exception ex)
            {
            }
            FarmNetStatic.getInstance().setAccount(account);
            if(account == null)
            {
                // call api tao 1 account
                new AsynTaskCreatNewAccount().execute();
            }else
            {

                new AsyncTaskGetMessage().execute();
                new AsyncTaskGetItemCart().execute();
                updateOrderFragment();
            }
            super.onPostExecute(aVoid);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        //resolve for tab Account when callback



        //to do other
        if (Data.onOrderHistoryDetailFragment){
            OrderHistoryFragment.rl_all.setVisibility(View.VISIBLE);
            Data.onOrderHistoryDetailFragment = false;
            return;
        }
        if (Data.onOrderHistoryFragment){
            tabBottom.setVisibility(View.VISIBLE);
            AccountFragment.rl_all.setVisibility(View.VISIBLE);
            Data.onOrderHistoryFragment = false;
            return;
        }



    }

    private void constructorView()
    {
        btnHome = (RelativeLayout)findViewById(R.id.btnHome);
        btnProduct = (RelativeLayout)findViewById(R.id.btnProduct);
        btnFarm = (RelativeLayout)findViewById(R.id.btnFarm);
       // btnOrder = (RelativeLayout)findViewById(R.id.btnOrder);
        btnAccount = (RelativeLayout)findViewById(R.id.btnAccount);
        btnNotification = (RelativeLayout)findViewById(R.id.btnNotification);

        tabHome = (RelativeLayout)findViewById(R.id.tab_home);
        tabProduct = (RelativeLayout)findViewById(R.id.tab_product);
        tabOrder = (RelativeLayout)findViewById(R.id.tab_order);
        tabBottom = (RelativeLayout)findViewById(R.id.r_bottom1);
        tabNotification = (RelativeLayout)findViewById(R.id.tab_notification);
        tabChat = (RelativeLayout)findViewById(R.id.tab_chat);
        tabAddress = (RelativeLayout)findViewById(R.id.tab_address);
        tabAccount = (RelativeLayout)findViewById(R.id.tab_account);
        tabFarm = (RelativeLayout)findViewById(R.id.tab_farm);
        tabSearch = (RelativeLayout)findViewById(R.id.tab_search);
        tabCombo = (RelativeLayout)findViewById(R.id.tab_combo);
        tabProductDetail = (RelativeLayout)findViewById(R.id.tab_product_detail);
        tabPayment = (RelativeLayout)findViewById(R.id.tab_payment);
        tabAddNewAddress = (RelativeLayout)findViewById(R.id.tab_addNewAddress);
        tabManageOrder = (RelativeLayout)findViewById(R.id.tab_manageOrder);




        imageViewHome = (ImageView)findViewById(R.id.imgHome);
        imageViewProduct = (ImageView)findViewById(R.id.imgProduct);
        imageViewFarm = (ImageView)findViewById(R.id.imgFarm);
        imageViewNotification = (ImageView)findViewById(R.id.imgNotification);
        imageViewAccount = (ImageView)findViewById(R.id.imgAccount);

        textViewHome = (TextView)findViewById(R.id.tvHome);

        showTabHome();
    }

    public static int dpToPx(int dp) {
        return (int) (dp * Resources.getSystem().getDisplayMetrics().density);
    }

    public static int pxToDp(int px) {
        return (int) (px / Resources.getSystem().getDisplayMetrics().density);
    }

    private void showTabHome()
    {

        tabHome.setVisibility(View.VISIBLE);
        tabProduct.setVisibility(View.GONE);
        tabOrder.setVisibility(View.GONE);
        tabNotification.setVisibility(View.GONE);
        tabChat.setVisibility(View.GONE);
        tabBottom.setVisibility(View.VISIBLE);
        tabAccount.setVisibility(View.GONE);
        tabFarm.setVisibility(View.GONE);
        tabSearch.setVisibility(View.GONE);
        tabCombo.setVisibility(View.GONE);
        tabProductDetail.setVisibility(View.GONE);
        tabPayment.setVisibility(View.GONE);
        tabAddNewAddress.setVisibility(View.GONE);
        tabAddress.setVisibility(View.GONE);
        tabManageOrder.setVisibility(View.GONE);


        //image_view.getLayoutParams().height = 20;
        //image_view.requestLayout()
        textViewHome.setVisibility(View.GONE);
        imageViewHome.getLayoutParams().height= dpToPx(50);
        imageViewHome.getLayoutParams().width = dpToPx(50) ;
        imageViewHome.requestLayout();
        imageViewHome.setBackgroundResource(R.drawable.menu_home2);

        imageViewProduct.getLayoutParams().height= dpToPx(30);
        imageViewProduct.getLayoutParams().width = dpToPx(30) ;
        imageViewProduct.requestLayout();
        imageViewProduct.setBackgroundResource(R.drawable.menu_product);


        imageViewFarm.getLayoutParams().height= dpToPx(30);
        imageViewFarm.getLayoutParams().width = dpToPx(30) ;
        imageViewFarm.setBackgroundResource(R.drawable.menu_farm);
        imageViewFarm.requestLayout();


        imageViewNotification.getLayoutParams().height= dpToPx(30);
        imageViewNotification.getLayoutParams().width = dpToPx(30) ;
        imageViewNotification.setBackgroundResource(R.drawable.menu_notify);
        imageViewNotification.requestLayout();


        imageViewAccount.getLayoutParams().height= dpToPx(30);
        imageViewAccount.getLayoutParams().width = dpToPx(30 );
        imageViewAccount.setBackgroundResource(R.drawable.menu_account);
        imageViewAccount.requestLayout();


    }

    public static void showTabProduct()
    {
        tabAccount.setVisibility(View.GONE);
        tabHome.setVisibility(View.GONE);
        tabProduct.setVisibility(View.VISIBLE);
        tabOrder.setVisibility(View.GONE);
        tabNotification.setVisibility(View.GONE);
        tabChat.setVisibility(View.GONE);
        tabBottom.setVisibility(View.VISIBLE);
        tabFarm.setVisibility(View.GONE);
        tabSearch.setVisibility(View.GONE);
        tabProductDetail.setVisibility(View.GONE);
        tabAddNewAddress.setVisibility(View.GONE);
        tabAddress.setVisibility(View.GONE);
        tabManageOrder.setVisibility(View.GONE);



        textViewHome.setVisibility(View.VISIBLE);

        imageViewHome.getLayoutParams().height= dpToPx(30);
        imageViewHome.getLayoutParams().width = dpToPx(30) ;
        imageViewHome.setBackgroundResource(R.drawable.menu_home);
        imageViewHome.requestLayout();

        imageViewProduct.getLayoutParams().height= dpToPx(30);
        imageViewProduct.getLayoutParams().width = dpToPx(30) ;
        imageViewProduct.setBackgroundResource(R.drawable.menu_product2);
        imageViewProduct.requestLayout();


        imageViewFarm.getLayoutParams().height= dpToPx(30);
        imageViewFarm.getLayoutParams().width = dpToPx(30) ;
        imageViewFarm.setBackgroundResource(R.drawable.menu_farm);
        imageViewFarm.requestLayout();


        imageViewNotification.getLayoutParams().height= dpToPx(30);
        imageViewNotification.getLayoutParams().width = dpToPx(30) ;
        imageViewNotification.setBackgroundResource(R.drawable.menu_notify);
        imageViewNotification.requestLayout();


        imageViewAccount.getLayoutParams().height= dpToPx(30);
        imageViewAccount.getLayoutParams().width = dpToPx(30) ;
        imageViewAccount.setBackgroundResource(R.drawable.menu_account);
        imageViewAccount.requestLayout();


    }
    public void showTabFarm()
    {
        tabAccount.setVisibility(View.GONE);
        tabHome.setVisibility(View.GONE);
        tabProduct.setVisibility(View.GONE);
        tabOrder.setVisibility(View.GONE);
        tabNotification.setVisibility(View.GONE);
        tabChat.setVisibility(View.GONE);
        tabBottom.setVisibility(View.VISIBLE);
        tabFarm.setVisibility(View.VISIBLE);
        tabSearch.setVisibility(View.GONE);
        tabCombo.setVisibility(View.GONE);
        tabProductDetail.setVisibility(View.GONE);
        tabAddNewAddress.setVisibility(View.GONE);
        tabAddress.setVisibility(View.GONE);
        tabManageOrder.setVisibility(View.GONE);



        textViewHome.setVisibility(View.VISIBLE);
        imageViewHome.getLayoutParams().height= dpToPx(30);
        imageViewHome.getLayoutParams().width = dpToPx(30) ;
        imageViewHome.setBackgroundResource(R.drawable.menu_home);

        imageViewHome.requestLayout();
        imageViewProduct.getLayoutParams().height= dpToPx(30);
        imageViewProduct.getLayoutParams().width = dpToPx(30) ;
        imageViewProduct.setBackgroundResource(R.drawable.menu_product);

        imageViewProduct.requestLayout();
        imageViewFarm.getLayoutParams().height= dpToPx(30);
        imageViewFarm.getLayoutParams().width = dpToPx(30) ;
        imageViewFarm.setBackgroundResource(R.drawable.menu_farm2);
        imageViewFarm.requestLayout();


        imageViewNotification.getLayoutParams().height= dpToPx(30);
        imageViewNotification.getLayoutParams().width = dpToPx(30) ;
        imageViewNotification.setBackgroundResource(R.drawable.menu_notify);

        imageViewNotification.requestLayout();
        imageViewAccount.getLayoutParams().height= dpToPx(30);
        imageViewAccount.getLayoutParams().width = dpToPx(30) ;
        imageViewAccount.setBackgroundResource(R.drawable.menu_account);
        imageViewAccount.requestLayout();

    }

    public static void  showTabOrder()
    {
        tabAddress.setVisibility(View.GONE);
        tabHome.setVisibility(View.GONE);
        tabProduct.setVisibility(View.GONE);
        tabOrder.setVisibility(View.VISIBLE);
        tabBottom.setVisibility(View.GONE);
        tabChat.setVisibility(View.GONE);
        tabAccount.setVisibility(View.GONE);
        tabNotification.setVisibility(View.GONE);
        tabFarm.setVisibility(View.GONE);
        tabSearch.setVisibility(View.GONE);
        tabCombo.setVisibility(View.GONE);
        tabProductDetail.setVisibility(View.GONE);
        tabPayment.setVisibility(View.GONE);
        tabAddNewAddress.setVisibility(View.GONE);
        tabAddress.setVisibility(View.GONE);
        tabManageOrder.setVisibility(View.GONE);


    }

    public static void  showTabAddNewAddress()
    {
        tabAddress.setVisibility(View.GONE);
        tabHome.setVisibility(View.GONE);
        tabProduct.setVisibility(View.GONE);
        tabOrder.setVisibility(View.GONE);
        tabBottom.setVisibility(View.GONE);
        tabChat.setVisibility(View.GONE);
        tabAccount.setVisibility(View.GONE);
        tabNotification.setVisibility(View.GONE);
        tabFarm.setVisibility(View.GONE);
        tabSearch.setVisibility(View.GONE);
        tabCombo.setVisibility(View.GONE);
        tabProductDetail.setVisibility(View.GONE);
        tabPayment.setVisibility(View.GONE);
        tabAddress.setVisibility(View.GONE);
        tabAddNewAddress.setVisibility(View.VISIBLE);
        tabManageOrder.setVisibility(View.GONE);



    }

    public void showTabSearch()
    {
        tabHome.setVisibility(View.GONE);
        tabProduct.setVisibility(View.GONE);
        tabOrder.setVisibility(View.GONE);
        tabBottom.setVisibility(View.GONE);
        tabChat.setVisibility(View.GONE);
        tabAccount.setVisibility(View.GONE);
        tabNotification.setVisibility(View.GONE);
        tabFarm.setVisibility(View.GONE);
        tabSearch.setVisibility(View.VISIBLE);
        tabCombo.setVisibility(View.GONE);
        tabProductDetail.setVisibility(View.GONE);
        tabPayment.setVisibility(View.GONE);
        tabAddNewAddress.setVisibility(View.GONE);
        tabAddress.setVisibility(View.GONE);
        tabManageOrder.setVisibility(View.GONE);





    }
    public void shoComment()
    {

//        f.setVisibility(View.VISIBLE);



    }

    public static void showTabCombo()
    {
        tabHome.setVisibility(View.GONE);
        tabProduct.setVisibility(View.GONE);
        tabOrder.setVisibility(View.GONE);
        tabBottom.setVisibility(View.GONE);
        tabChat.setVisibility(View.GONE);
        tabAccount.setVisibility(View.GONE);
        tabNotification.setVisibility(View.GONE);
        tabFarm.setVisibility(View.GONE);
        tabSearch.setVisibility(View.GONE);
        tabCombo.setVisibility(View.VISIBLE);
        tabProductDetail.setVisibility(View.GONE);
        tabPayment.setVisibility(View.GONE);
        tabAddNewAddress.setVisibility(View.GONE);
        tabAddress.setVisibility(View.GONE);
        tabManageOrder.setVisibility(View.GONE);


    }


    public static  void showTabProductDetail()
    {
        tabHome.setVisibility(View.GONE);
        tabProduct.setVisibility(View.GONE);
        tabOrder.setVisibility(View.GONE);
        tabBottom.setVisibility(View.GONE);
        tabChat.setVisibility(View.GONE);
        tabAccount.setVisibility(View.GONE);
        tabNotification.setVisibility(View.GONE);
        tabFarm.setVisibility(View.GONE);
        tabSearch.setVisibility(View.GONE);
        tabCombo.setVisibility(View.GONE);
        tabProductDetail.setVisibility(View.VISIBLE);
        tabPayment.setVisibility(View.GONE);
        tabAddNewAddress.setVisibility(View.GONE);
        tabAddress.setVisibility(View.GONE);
        tabManageOrder.setVisibility(View.GONE);


    }


    public static  void showTabPayment()
    {
        tabHome.setVisibility(View.GONE);
        tabProduct.setVisibility(View.GONE);
        tabOrder.setVisibility(View.GONE);
        tabBottom.setVisibility(View.GONE);
        tabChat.setVisibility(View.GONE);
        tabAccount.setVisibility(View.GONE);
        tabNotification.setVisibility(View.GONE);
        tabFarm.setVisibility(View.GONE);
        tabSearch.setVisibility(View.GONE);
        tabCombo.setVisibility(View.GONE);
        tabProductDetail.setVisibility(View.GONE);
        tabPayment.setVisibility(View.VISIBLE);
        tabAddNewAddress.setVisibility(View.GONE);
        tabAddress.setVisibility(View.GONE);
        tabManageOrder.setVisibility(View.GONE);


    }



    public  void showTabNotification()
    {
        textViewHome.setVisibility(View.VISIBLE);
        tabAccount.setVisibility(View.GONE);
        tabOrder.setVisibility(View.GONE);
        tabHome.setVisibility(View.GONE);
        tabProduct.setVisibility(View.GONE);
        tabChat.setVisibility(View.GONE);
        tabNotification.setVisibility(View.VISIBLE);
        tabBottom.setVisibility(View.VISIBLE);
        tabFarm.setVisibility(View.GONE);
        tabSearch.setVisibility(View.GONE);
        tabCombo.setVisibility(View.GONE);
        tabProductDetail.setVisibility(View.GONE);
        tabPayment.setVisibility(View.GONE);
        tabAddNewAddress.setVisibility(View.GONE);
        tabAddress.setVisibility(View.GONE);
        tabManageOrder.setVisibility(View.GONE);




        imageViewHome.getLayoutParams().height= dpToPx(30);
        imageViewHome.getLayoutParams().width = dpToPx(30) ;
        imageViewHome.setBackgroundResource(R.drawable.menu_home);

        imageViewHome.requestLayout();

        imageViewProduct.getLayoutParams().height= dpToPx(30);
        imageViewProduct.getLayoutParams().width = dpToPx(30) ;
        imageViewProduct.setBackgroundResource(R.drawable.menu_product);

        imageViewProduct.requestLayout();


        imageViewFarm.getLayoutParams().height= dpToPx(30);
        imageViewFarm.getLayoutParams().width = dpToPx(30) ;
        imageViewFarm.setBackgroundResource(R.drawable.menu_farm);

        imageViewFarm.requestLayout();


        imageViewNotification.getLayoutParams().height= dpToPx(30);
        imageViewNotification.getLayoutParams().width = dpToPx(30) ;
        imageViewNotification.setBackgroundResource(R.drawable.menu_notify2);

        imageViewNotification.requestLayout();


        imageViewAccount.getLayoutParams().height= dpToPx(30);
        imageViewAccount.getLayoutParams().width = dpToPx(30) ;
        imageViewAccount.setBackgroundResource(R.drawable.menu_account);

        imageViewAccount.requestLayout();


    }

    public  static final int TAB_HOME = 1;
    public  static final int TAB_PRODUCT = 2;
    public  static final int TAB_FARM = 3;
    public  static final int TAB_NOTIFICATION  = 4;
    public  static final int TAB_ACCOUNT = 5;
    public  static  int currentTab = 1;
    public void backFromSubView(int tab)
    {

        switch (tab)
        {
            case TAB_HOME:

                showTabHome();

                break;

            case TAB_PRODUCT:
                showTabProduct();

                break;
            case TAB_FARM:

                showTabFarm();

                break;

            case TAB_NOTIFICATION:
                showTabNotification();

                break;

            case TAB_ACCOUNT:

                showTabAccount();

                break;
        }
    }


    public   void showTabChat()
    {

        tabHome.setVisibility(View.GONE);
        tabProduct.setVisibility(View.GONE);
        tabOrder.setVisibility(View.GONE);
        tabBottom.setVisibility(View.GONE);
        tabChat.setVisibility(View.VISIBLE);
        tabNotification.setVisibility(View.GONE);
        tabAccount.setVisibility(View.GONE);
        tabFarm.setVisibility(View.GONE);
        tabSearch.setVisibility(View.GONE);
        tabProductDetail.setVisibility(View.GONE);
        tabPayment.setVisibility(View.GONE);
        tabAddNewAddress.setVisibility(View.GONE);
        tabAddress.setVisibility(View.GONE);
        tabManageOrder.setVisibility(View.GONE);




    }
    public   void showTabAddress()
    {
        tabAddress.setVisibility(View.VISIBLE);
        tabHome.setVisibility(View.GONE);
        tabProduct.setVisibility(View.GONE);
        tabOrder.setVisibility(View.GONE);
        tabBottom.setVisibility(View.GONE);
        tabChat.setVisibility(View.GONE);
        tabNotification.setVisibility(View.GONE);
        tabAccount.setVisibility(View.GONE);
        tabFarm.setVisibility(View.GONE);
        tabSearch.setVisibility(View.GONE);
        tabProductDetail.setVisibility(View.GONE);
        tabPayment.setVisibility(View.GONE);
        tabAddNewAddress.setVisibility(View.GONE);
        tabManageOrder.setVisibility(View.GONE);

    }

    public   void showTabManageOrder()
    {
        tabAddress.setVisibility(View.GONE);
        tabHome.setVisibility(View.GONE);
        tabProduct.setVisibility(View.GONE);
        tabOrder.setVisibility(View.GONE);
        tabBottom.setVisibility(View.GONE);
        tabChat.setVisibility(View.GONE);
        tabNotification.setVisibility(View.GONE);
        tabAccount.setVisibility(View.GONE);
        tabFarm.setVisibility(View.GONE);
        tabSearch.setVisibility(View.GONE);
        tabProductDetail.setVisibility(View.GONE);
        tabPayment.setVisibility(View.GONE);
        tabAddNewAddress.setVisibility(View.GONE);
        tabManageOrder.setVisibility(View.VISIBLE);

    }



    public static void showTabAccount()
    {
        textViewHome.setVisibility(View.VISIBLE);
        tabOrder.setVisibility(View.GONE);
        tabHome.setVisibility(View.GONE);
        tabProduct.setVisibility(View.GONE);
        tabChat.setVisibility(View.GONE);
        tabNotification.setVisibility(View.GONE);
        tabBottom.setVisibility(View.VISIBLE);
        tabAccount.setVisibility(View.VISIBLE);
        tabFarm.setVisibility(View.GONE);
        tabSearch.setVisibility(View.GONE);
        tabProductDetail.setVisibility(View.GONE);
        tabPayment.setVisibility(View.GONE);
        tabAddNewAddress.setVisibility(View.GONE);
        tabAddress.setVisibility(View.GONE);
        tabManageOrder.setVisibility(View.GONE);





        imageViewHome.getLayoutParams().height= dpToPx(30);
        imageViewHome.getLayoutParams().width = dpToPx(30) ;
        imageViewHome.setBackgroundResource(R.drawable.menu_home);
        imageViewHome.requestLayout();

        imageViewProduct.getLayoutParams().height= dpToPx(30);
        imageViewProduct.getLayoutParams().width = dpToPx(30) ;
        imageViewProduct.setBackgroundResource(R.drawable.menu_product);
        imageViewProduct.requestLayout();


        imageViewFarm.getLayoutParams().height= dpToPx(30);
        imageViewFarm.getLayoutParams().width = dpToPx(30) ;
        imageViewFarm.setBackgroundResource(R.drawable.menu_farm);
        imageViewFarm.requestLayout();


        imageViewNotification.getLayoutParams().height= dpToPx(30);
        imageViewNotification.getLayoutParams().width = dpToPx(30) ;
        imageViewNotification.setBackgroundResource(R.drawable.menu_notify);
        imageViewNotification.requestLayout();


        imageViewAccount.getLayoutParams().height= dpToPx(30);
        imageViewAccount.getLayoutParams().width = dpToPx(30) ;
        imageViewAccount.setBackgroundResource(R.drawable.menu_account2);
        imageViewAccount.requestLayout();



    }



    private void setOnAction()
    {
        btnHome.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                currentTab = TAB_HOME;
                showTabHome();
            }
        });
        btnProduct.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                currentTab = TAB_PRODUCT;
                showTabProduct();
            }
        });
        btnFarm.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                currentTab = TAB_FARM;
                showTabFarm();
            }
        });
        btnNotification.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                currentTab = TAB_NOTIFICATION;
                showTabNotification();
            }
        });
        btnAccount.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                currentTab = TAB_ACCOUNT;
                showTabAccount();
            }
        });
    }


    private void startSocket() {
        client = new OkHttpClient();
        Request request = new Request.Builder().url("ws://192.168.1.14:80/WebSocket/server").build();
        EchoWebSocketListener listener = new EchoWebSocketListener();
        WebSocket ws = client.newWebSocket(request, listener);
        ws.send("add_message");
        client.dispatcher().executorService().shutdown();

    }

    private OkHttpClient client;

    WebSocket webSocket = null;

    public static MainActivity instance = null;

    public static MainActivity getNewInstance()
    {
        if(instance== null)
        {
            instance = new MainActivity();
        }

        return instance;
    }

    public  WebSocket getWebSocket()
    {

        return webSocket;
    }
    public final class EchoWebSocketListener extends WebSocketListener {
        private static final int NORMAL_CLOSURE_STATUS = 1000;
        @Override
        public void onOpen(WebSocket webSocket, Response response) {

        }
        @Override
        public void onMessage(WebSocket webSocket, String text) {

            System.out.println("MESSSSSSS:"+text);

            if(text.contains("add_message"))
            {
                ChatFragment fragment = (ChatFragment)getSupportFragmentManager().findFragmentById(R.id.chat_fragment);
                fragment.refresh();
            }
        }
        @Override
        public void onMessage(WebSocket webSocket, ByteString bytes) {
        }
        @Override
        public void onClosing(WebSocket webSocket, int code, String reason) {
            webSocket.close(NORMAL_CLOSURE_STATUS, null);
        }
        @Override
        public void onFailure(WebSocket webSocket, Throwable t, Response response) {
        }
    }

    public class AsyncTaskGetMessage extends AsyncTask<Void, Void, Void>
    {
        List<Message> listMessage = new ArrayList<Message>();

        String responseString = null;
        Gson gson = new Gson();
        GetMessageId getMessageId = new GetMessageId();

        @Override
        protected void onPreExecute() {

            try{
                getMessageId.setRecieveId(FarmNetStatic.getInstance().getAccount().getAccountID());
                getMessageId.setSendId(0);

                System.out.println("Message:"+ getMessageId.toString());
            }catch (Exception ex)
            {

            }
            System.out.println("GETMESS:"+ getMessageId.toString());
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... voids) {

            try {
                responseString =  Connector.doPostRequest(Connector.rootURL+ URL_FarmNet.url_getMessage
                        ,gson.toJson(getMessageId));

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            try{

                System.out.println("AAAA"+responseString);
                TypeToken<List<Message>> token = new TypeToken<List<Message>>() {};
                listMessage = gson.fromJson(responseString, token.getType());




            }catch (Exception ex){

            }


            int sizeMessage = listMessage.size();

            FarmNetStatic.getInstance().setSizeMassage(sizeMessage);

            updateCountMessage();
        }
    }


    public  class AsyncTaskGetItemCart extends AsyncTask<Void, Void, Void>
    {
        String responseString = null;
        Gson gson = new Gson();
        AccountId accountId = new AccountId();
        List<CartResponse> cartList = new ArrayList<CartResponse>();

        @Override
        protected void onPreExecute() {
            accountId.setId(FarmNetStatic.getInstance().getAccount().getAccountID());
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... voids) {

            try
            {
                responseString = Connector.doPostRequest(Connector.rootURL+ URL_FarmNet.GETLIST_CART,gson.toJson(accountId));
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            TypeToken<List<CartResponse>> token = new TypeToken<List<CartResponse>>() {};
            cartList = gson.fromJson(responseString, token.getType());
            int sizeCart = cartList.size();
            FarmNetStatic.getInstance().setSizeCart(sizeCart);

            updateCountCart();

        }
    }


}
