package com.deepcode.farmnet.fragment;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.deepcode.farmnet.R;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;

import java.util.ArrayList;

public class Doanhthu2Fragment extends BaseFragment {

    BarChart barChart;


    private ArrayList<BarEntry> dataValue1()
    {
        ArrayList<BarEntry> dataVals = new ArrayList<>();
        dataVals.add(new BarEntry(0,110));
        dataVals.add(new BarEntry(1,90));
        dataVals.add(new BarEntry(2,80));
        dataVals.add(new BarEntry(3,120));

        return dataVals;
    }

    @Override
    public void constructorView() {

    }

    @Override
    public void setOnClick() {

    }

    @Override
    public void loadDateView() {

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_doanhthu2, container, false);

        barChart = (BarChart)view.findViewById(R.id.mp_BarChart);

        BarDataSet barDataSet1 = new BarDataSet(dataValue1(),"Doanh Thu");
        barDataSet1.setColor(Color.BLUE);
        BarData barData = new BarData();
        barData.addDataSet(barDataSet1);


        barChart.setData(barData);
        barChart.invalidate();

        float barSpace =0.2f;
        barData.setBarWidth(barSpace);  //set kich thuoc cot

        String[] days = new String[]{"Thang 1", "Thang 2", "Thang 3", "Thang 4" };
        XAxis xAxis = barChart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(days));
        xAxis.setCenterAxisLabels(true);

        xAxis.setAxisLineWidth(0.04f);     //  kich thuwoc
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1);
        xAxis.setGranularityEnabled(true);

        barChart.setDragEnabled(true);
        barChart.setVisibleXRangeMaximum(4);   // so luong cot

        return view;
    }
}
