package com.deepcode.farmnet.fragment;

import android.app.AlertDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.adapter.AddressAdpater;
import com.deepcode.farmnet.bean.AddressOrder;
import com.deepcode.farmnet.bean.Category;
import com.deepcode.farmnet.core.Connector;
import com.deepcode.farmnet.core.FarmNetStatic;
import com.deepcode.farmnet.core.URL_FarmNet;
import com.deepcode.farmnet.request.AccountId;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AddressFragment extends BaseFragment {
    @Override
    public void constructorView() {

    }

    @Override
    public void setOnClick() {

    }

    @Override
    public void loadDateView() {

    }
    RecyclerView recyclerView;
    List<AddressOrder> lstAddess = new ArrayList<AddressOrder>();
    AddressAdpater addressAdpater;
    RelativeLayout rl_addNewAddress;
    RelativeLayout rl_listAddress;
    Button btnBack, btnCheckBox;
    TextView txt_addNewAddress, btn_chooseAdress;
    MainActivity mainActivity;
    boolean isCheck;
    RelativeLayout tab_payment;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_address, container,false);
        mainActivity = (MainActivity)getActivity();
        btnBack = (Button) view.findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity mainActivity = (MainActivity)getActivity();
                mainActivity.showTabOrder();
            }
        });
      //  rl_addNewAddress = (RelativeLayout)view.findViewById(R.id.rl_addNewAddress);
        rl_listAddress = (RelativeLayout)view.findViewById(R.id.rl_listAddress);
        tab_payment = view.findViewById(R.id.tab_payment);

        txt_addNewAddress = (TextView) view.findViewById(R.id.txt_addNewAddress);
        txt_addNewAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                MainActivity mainActivity = (MainActivity)getActivity();
                mainActivity.showTabAddNewAddress();


            }
        });

        recyclerView = (RecyclerView) view.findViewById(R.id.rl_allAdress);
        lstAddess = FarmNetStatic.addressList;
        addressAdpater = new AddressAdpater(mainActivity, lstAddess);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(addressAdpater);

        btn_chooseAdress = (TextView) view.findViewById(R.id.btn_chooseAdress);
        btn_chooseAdress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity mainActivity = (MainActivity)getActivity();
                mainActivity.showTabPayment();




                PaymentFragment fragment = (PaymentFragment)getActivity().getSupportFragmentManager().findFragmentById(R.id.payment_fragment);
                fragment.reload();
            }
        });


        new AsyncTackGetListAddressOrder().execute();




        return view;
    }


    public  void adpaterChange(int position)
    {

       // addressAdpater.notifyDataSetChanged();

      for(int i=0;i< lstAddess.size();i++)
      {
          if(i== position)
          {
              lstAddess.get(position).setCheck(true);

          }else
          {
              lstAddess.get(i).setCheck(false);

          }
      }
        addressAdpater = new AddressAdpater(mainActivity, lstAddess);
        recyclerView.setAdapter(addressAdpater);
    }

    public void refresh()
    {
        new AsyncTackGetListAddressOrder().execute();


    }
    public class AsyncTackGetListAddressOrder extends AsyncTask {
        Gson gson = new Gson();

        String url = Connector.rootURL + URL_FarmNet.GETLIST_ADDRESS;
        String jsonString = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Object doInBackground(Object[] objects) {
            AccountId accountId = new AccountId();
            try{
                accountId.setId(FarmNetStatic.getInstance().getAccount().getAccountID());
            }catch (Exception ex){
            }
            try
            {
                jsonString = Connector.doPostRequest(url, gson.toJson(accountId));
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);

            TypeToken<List<AddressOrder>> token = new TypeToken<List<AddressOrder>>() {};

            System.out.println("JSON:"+ jsonString);

            try {
                lstAddess = gson.fromJson(jsonString, token.getType());

                for(int i=0;i<lstAddess.size();i++)
                {
                    lstAddess.get(i).setCheck(false);
                }
                addressAdpater = new AddressAdpater(mainActivity, lstAddess);
                recyclerView.setAdapter(addressAdpater);
            }catch (Exception ex){

            }



        }
    }
}
