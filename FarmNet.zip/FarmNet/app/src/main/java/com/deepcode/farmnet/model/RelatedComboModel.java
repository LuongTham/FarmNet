package com.deepcode.farmnet.model;

public class RelatedComboModel {
}
