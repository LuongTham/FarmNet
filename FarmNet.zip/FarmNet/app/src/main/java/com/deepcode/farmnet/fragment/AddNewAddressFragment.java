package com.deepcode.farmnet.fragment;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentTransaction;

import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.bean.AddressOrder;
import com.deepcode.farmnet.core.Connector;
import com.deepcode.farmnet.core.FarmNetStatic;
import com.deepcode.farmnet.core.URL_FarmNet;
import com.deepcode.farmnet.request.AddAdressOrder;
import com.google.gson.Gson;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AddNewAddressFragment extends BaseFragment {

    @Override
    public void constructorView() {

    }

    @Override
    public void setOnClick() {

    }

    @Override
    public void loadDateView() {

    }


    Button btnBack;
    RelativeLayout rl_addNewAddress, rl_listAddress, rl_fillItem;
    LinearLayout btnSave;
    EditText name;
    EditText phone;
    EditText province;
    EditText distric;
    EditText ward;
    EditText detailAddress;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.add_address, container, false);
     //   rl_addNewAddress = (RelativeLayout) view.findViewById(R.id.rl_addNewAddress);
        rl_listAddress = (RelativeLayout) view.findViewById(R.id.rl_listAddress);
        rl_fillItem = (RelativeLayout) view.findViewById(R.id.rl_fillItem);

        btnSave = (LinearLayout) view.findViewById(R.id.btnSave);
        name = view.findViewById(R.id.edt_name);
        phone = view.findViewById(R.id.edt_phone);
        province = view.findViewById(R.id.edt_province);
        distric = view.findViewById(R.id.edt_distric);
        ward = view.findViewById(R.id.edt_ward);
        detailAddress = view.findViewById(R.id.edt_addressDetail);


        btnBack = view.findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                FragmentTransaction ft = getFragmentManager().beginTransaction();
//                ft.replace(R.id.addNewAddress_fragment, new AddressFragment()).addToBackStack("").commit();

                MainActivity mainActivity = (MainActivity)getActivity();
                mainActivity.showTabAddress();
      //          rl_fillItem.setVisibility(View.GONE);
                AddressFragment fragment = (AddressFragment)getActivity().getSupportFragmentManager().findFragmentById(R.id.address_fragment);
                fragment.refresh();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                address.setAddressOrderID(1);
                if (!name.getText().toString().equals("") && !phone.getText().toString().equals("") && !distric.getText().toString().equals("") &&
                        !province.getText().toString().equals("") && !ward.getText().toString().equals("") && !detailAddress.getText().toString().equals("")) {
                    address.setName(name.getText().toString());
                    address.setPhone(phone.getText().toString());
                    address.setProvince(province.getText().toString());
                    address.setDistrict(distric.getText().toString());
                    address.setWard(ward.getText().toString());
                    address.setDetailAddress(detailAddress.getText().toString());


                    new AsyncTackAddNewAddressOrder().execute();
                    // FarmNetStatic.addressList.add(address);

                } else {
                    Toast.makeText(getContext(), "Không được để trống!!!", Toast.LENGTH_SHORT).show();
                }
            }

        });

        return view;

    }

    public AddressOrder address = new AddressOrder();

    public class AsyncTackAddNewAddressOrder extends AsyncTask {
        Gson gson = new Gson();
        String jsonString = null;
        String ur;

        AddAdressOrder addAdressOrder = new AddAdressOrder();

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            addAdressOrder.setId(FarmNetStatic.getInstance().getAccount().getAccountID());
            List<AddressOrder> addressOrderList = new ArrayList<>();
            addressOrderList.add(address);
            addAdressOrder.setListAddr(addressOrderList);

        }

        @Override
        protected Object doInBackground(Object[] objects) {

            try {
                jsonString = Connector.doPostRequest(Connector.rootURL+ URL_FarmNet.GETLIST_AddNewAddress, gson.toJson(addAdressOrder));

            }catch (IOException ex){

            }

            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);

            MainActivity mainActivity = (MainActivity)getActivity();
            mainActivity.showTabAddress();
            //          rl_fillItem.setVisibility(View.GONE);
            AddressFragment fragment = (AddressFragment)getActivity().getSupportFragmentManager().findFragmentById(R.id.address_fragment);
            fragment.refresh();
         //   rl_fillItem.setVisibility(View.GONE);
        }
    }

}
