package com.deepcode.farmnet.core;

import com.deepcode.farmnet.bean.Category;
import com.deepcode.farmnet.model.FarmModel;
import com.deepcode.farmnet.model.Order;

import java.util.ArrayList;
import java.util.List;

public class Data {
    public static boolean onOrderHistoryFragment = false;
    public static boolean onOrderHistoryDetailFragment = false;
    public static List<Category> categoryList = new ArrayList<>();
    public static int positionCategoryCurent = 0;

    public static List<Order> orderList = new ArrayList();
    public static List<FarmModel> farmModelList = new ArrayList<>();
    public static boolean onReportFragment = false;
}
