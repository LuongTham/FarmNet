package com.deepcode.farmnet.bean;

import java.util.Date;

public class TopProduct {

    private int topProductID;
    private int productId;
    private int prioritize;
    private boolean delete;
    private String desc;
    private String color;
    private Date creatDate;
    private boolean active;
    private int type;
    private int discount;
    private String image;
    private String productName;
    private String farmName;
    private  String price;
    private  String title_bnt;
    private long farmId;


    private boolean combo;
    public boolean isCombo() {
        return combo;
    }
    public void setCombo(boolean combo) {
        this.combo = combo;
    }
    public String getPrice() {
        return price;
    }
    public void setPrice(String price) {
        this.price = price;
    }
    public int getTopProductID() {
        return topProductID;
    }
    public void setTopProductID(int topProductID) {
        this.topProductID = topProductID;
    }
    public int getProductId() {
        return productId;
    }
    public void setProductId(int productId) {
        this.productId = productId;
    }
    public int getPrioritize() {
        return prioritize;
    }
    public void setPrioritize(int prioritize) {
        this.prioritize = prioritize;
    }
    public boolean isDelete() {
        return delete;
    }
    public void setDelete(boolean delete) {
        this.delete = delete;
    }
    public String getDesc() {
        return desc;
    }
    public void setDesc(String desc) {
        this.desc = desc;
    }
    public String getColor() {
        return color;
    }
    public void setColor(String color) {
        this.color = color;
    }
    public Date getCreatDate() {
        return creatDate;
    }
    public void setCreatDate(Date creatDate) {
        this.creatDate = creatDate;
    }
    public boolean isActive() {
        return active;
    }
    public void setActive(boolean active) {
        this.active = active;
    }
    public int getType() {
        return type;
    }
    public void setType(int type) {
        this.type = type;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getFarmName() {
        return farmName;
    }

    public void setFarmName(String farmName) {
        this.farmName = farmName;
    }

    public int getDiscount() {
        return discount;
    }

    public void setDiscount(int discount) {
        this.discount = discount;

    }

    public String getTitle_bnt() {
        return title_bnt;
    }

    public long getFarmId() {
        return farmId;
    }

    public void setFarmId(long farmId) {
        this.farmId = farmId;
    }

    public void setTitle_bnt(String title_bnt) {
        this.title_bnt = title_bnt;
    }
}
