package com.deepcode.farmnet.core;

import com.deepcode.farmnet.bean.Account;
import com.deepcode.farmnet.bean.AddressOrder;
import com.deepcode.farmnet.bean.OrderConfirm;
import com.deepcode.farmnet.response.CartResponse;

import java.util.ArrayList;
import java.util.List;

public class FarmNetStatic {

    private static AddressOrder addressDefaul;

    public static AddressOrder getAddressDefaul() {
        return addressDefaul;
    }

    public static void setAddressDefaul(AddressOrder addressDefaul) {
        FarmNetStatic.addressDefaul = addressDefaul;
    }

    public static FarmNetStatic instance = null;

    public static int getAddress() {
        return address;
    }

    public static void setAddress(int address) {
        FarmNetStatic.address = address;
    }

    public static List<AddressOrder> getAddressList() {
        return addressList;
    }

    public static void setAddressList(List<AddressOrder> addressList) {
        FarmNetStatic.addressList = addressList;
    }
    public static void  setAddresss(AddressOrder address){
        FarmNetStatic.addresss = address;

    }

    public static AddressOrder getAddresss() {
        return addresss;
    }


    private static AddressOrder addresss;


   public static  List<CartResponse> cartResponseList = new ArrayList<CartResponse>();

    private static int address = 1;

    private static int sizeCart = 0;
    private static int sizeMassage = 0;
    public static String name = "";

    public static int getSizeMassage() {
        return sizeMassage;
    }

    public static void setSizeMassage(int sizeMassage) {
        FarmNetStatic.sizeMassage = sizeMassage;
    }

    public static FarmNetStatic getInstance() {
        if (instance == null) {
            instance = new FarmNetStatic();
        }
        return instance;
    }

    public  String deviceId;

    public Account account = null;

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public static void setInstance(FarmNetStatic instance) {
        FarmNetStatic.instance = instance;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }


    public static int getSizeCart() {
        return sizeCart;
    }

    public  void setSizeCart(int sizeCart ){
        FarmNetStatic.sizeCart = sizeCart;
    }


    public static List<AddressOrder> addressList = new ArrayList<AddressOrder>();

}
