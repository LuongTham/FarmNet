package com.deepcode.farmnet.response;

import java.util.Date;
import java.util.List;

public class ProductResponse{

    private long productID;
    private long groupId;
    private long farmId;
    private String city;
    private String name;
    private String image;
    private int count;
    private int price;
    private int discount;
    private String unit;
    private Date createdDate;
    private int status;
    private String listRelatedProduct;
    private boolean top;
    private boolean delete;
    private long categoryId;

    private List<Rating> listRatings;

    @Override
    public String toString() {
        return "ProductResponse{" +
                "farmId=" + farmId +
                ", name='" + name + '\'' +
                ", price=" + price +
                ", unit='" + unit + '\'' +
                ", listRelatedProduct='" + listRelatedProduct + '\'' +
                '}';
    }

    public List<Rating> getListRatings() {
        return listRatings;
    }

    public long getProductID() {
        return productID;
    }

    public void setProductID(long productID) {
        this.productID = productID;
    }

    public long getGroupId() {
        return groupId;
    }

    public void setGroupId(long groupId) {
        this.groupId = groupId;
    }

    public long getFarmId() {
        return farmId;
    }

    public void setFarmId(long farmId) {
        this.farmId = farmId;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getDiscount() {
        return discount;
    }

    public void setDiscount(int discount) {
        this.discount = discount;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getListRelatedProduct() {
        return listRelatedProduct;
    }

    public void setListRelatedProduct(String listRelatedProduct) {
        this.listRelatedProduct = listRelatedProduct;
    }

    public boolean isTop() {
        return top;
    }

    public void setTop(boolean top) {
        this.top = top;
    }

    public boolean isDelete() {
        return delete;
    }

    public void setDelete(boolean delete) {
        this.delete = delete;
    }

    public long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(long categoryId) {
        this.categoryId = categoryId;
    }

    public void setListRatings(List<Rating> listRatings) {
        this.listRatings = listRatings;
    }
}

class Rating {
    private String deviceId;
    private String accountId;
    private float rate;
    private String comments;

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public float getRate() {
        return rate;
    }

    public void setRate(float rate) {
        this.rate = rate;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }
}
