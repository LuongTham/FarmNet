package com.deepcode.farmnet.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentTransaction;

import com.deepcode.farmnet.LoginActivity;
import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;

public class AccountFragment extends BaseFragment{
    @Override
    public void constructorView() {

    }

    @Override
    public void setOnClick() {

    }

    @Override
    public void loadDateView() {

    }


    public static RelativeLayout rl_OrderHistory, rl_all, rl_Report;
    RelativeLayout btnChat;
    RelativeLayout btnShoppingCart;
    TextView btn_SignIn;
    MainActivity mainActivity;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //return super.onCreateView(inflater, container, savedInstanceState);

        View view = inflater.inflate(R.layout.fragment_account, container, false);
         mainActivity = (MainActivity)getActivity();
        rl_OrderHistory = view.findViewById(R.id.relative_History);
        rl_Report = view.findViewById(R.id.relative_Report);

        rl_all = view.findViewById(R.id.rl_all);

        //refresh
        {

        }

        //có list lịch sử ở đây rồi mới hiển thị đc số chưa giao
        //=> số => setText =>

        rl_OrderHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rl_all.setVisibility(View.GONE);
                MainActivity.tabBottom.setVisibility(View.GONE);

                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.frame_fragment,new OrderHistoryFragment()).addToBackStack("").commit();
            }
        });


        rl_Report.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rl_all.setVisibility(View.GONE);
                MainActivity.tabBottom.setVisibility(View.GONE);

                FragmentTransaction ft1 = getFragmentManager().beginTransaction();
                ft1.replace(R.id.frame_fragment,new ReportFragment()).addToBackStack("").commit();
            }
        });
        btnChat = (RelativeLayout)view.findViewById(R.id.r_r);

        btnChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // MainActivity mainActivity = (MainActivity)getActivity();
                mainActivity.showTabChat();
            }
        });
        btnShoppingCart = (RelativeLayout)view.findViewById(R.id.r_shoppingcar);
        btnShoppingCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


               // MainActivity mainActivity = (MainActivity)getActivity();
                mainActivity.showTabOrder();

                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.order_fragment,new ListOrderFragment()).addToBackStack("").commit();

            }
        });
        btn_SignIn = (TextView)view.findViewById(R.id.btn_signin);
        btn_SignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // MainActivity mainActivity = (MainActivity)getActivity();
                Intent intent = new Intent(mainActivity, LoginActivity.class);
                startActivity(intent);
            }
        });

        return  view;
    }
}
