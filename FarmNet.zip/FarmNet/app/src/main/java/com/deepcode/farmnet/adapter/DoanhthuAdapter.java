package com.deepcode.farmnet.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.R;
import com.deepcode.farmnet.model.ProductDemo;


import java.util.List;

public class DoanhthuAdapter extends RecyclerView.Adapter<DoanhthuAdapter.ViewHolder> {

    Context context;
    List<ProductDemo> listProductDemo;
    public DoanhthuAdapter(List<ProductDemo> list , Context mContext)
    {
        listProductDemo = list;
        context = mContext;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.doanhthu_item, parent, false);
        return new ViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        ProductDemo productDemo = listProductDemo.get(position);
        holder.txtSTT.setText(productDemo.getStt()+"");
        holder.txtProName.setText(productDemo.getName());
        holder.txtType.setText(productDemo.getType());
        holder.txtSL.setText(productDemo.getSoLuong()+"");
        holder.txtDT.setText(productDemo.getDoanhThu()+"");

    }

    @Override
    public int getItemCount() {
        return listProductDemo.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView txtSTT;
        TextView txtProName;
        TextView txtType;
        TextView txtSL;
        TextView txtDT;

        public ViewHolder(View itemView)
        {
            super(itemView);
            // txtUserName = (TextView) itemView.findViewById(R.id.user_name);
            txtSTT = (TextView)itemView.findViewById(R.id.tv_stt);
            txtProName = (TextView)itemView.findViewById(R.id.tv_sanpham);
            txtType = (TextView)itemView.findViewById(R.id.tv_loai);
            txtSL = (TextView)itemView.findViewById(R.id.tv_soluong);
            txtDT = (TextView)itemView.findViewById(R.id.tv_doanhthu);

        }
    }
}
