package com.deepcode.farmnet.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.bean.Category;
import com.deepcode.farmnet.fragment.OrderHistoryDetailFragment;
import com.deepcode.farmnet.fragment.OrderHistoryFragment;
import com.deepcode.farmnet.model.OrderHistoryModel;

import java.util.ArrayList;
import java.util.List;


public class OrderHistoryAdapter extends RecyclerView.Adapter<OrderHistoryAdapter.RecyclerViewHolder>
{
    Context context;
    List<OrderHistoryModel> listOrder = new ArrayList<>();
    public OrderHistoryAdapter(List<OrderHistoryModel> list,Context mContext)
    {
        listOrder = list;
        context = mContext;
    }
    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.item_lichsu_giaodich, parent, false);

        return new RecyclerViewHolder(view);    }
    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position)
    {

        OrderHistoryModel itemdata = listOrder.get(position);
        holder.txtID.setText(itemdata.getName());
        holder.txtAddress.setText(itemdata.getAddress());
        holder.txtTime.setText(itemdata.getTime());

        if (itemdata.isStatus()==true) {
            holder.txtStatus.setText("Đã giao hàng");
            holder.txtStatus.setTextColor(ContextCompat.getColor(context,R.color.greenDark));
        }
        else {
            holder.txtStatus.setText("Chưa giao hàng");
            holder.txtStatus.setTextColor(ContextCompat.getColor(context,R.color.red));
        }

        holder.rl_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                OrderHistoryFragment.rl_all.setVisibility(View.GONE);

                FragmentTransaction ft = ((AppCompatActivity)context).getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.frame_fragment,new OrderHistoryDetailFragment()).addToBackStack("").commit();
            }
        });


    }
    @Override
    public int getItemCount()
    {
        return listOrder.size();
    }


    public class RecyclerViewHolder extends RecyclerView.ViewHolder
    {

        TextView txtID, txtAddress, txtTime, txtStatus;
        RelativeLayout rl_item;

        public RecyclerViewHolder(View itemView)
        {
            super(itemView);
            txtID = (TextView) itemView.findViewById(R.id.tvName);
            txtAddress = (TextView) itemView.findViewById(R.id.tvAddress);
            txtTime = (TextView) itemView.findViewById(R.id.tvTime);
            txtStatus = (TextView) itemView.findViewById(R.id.status);
            rl_item = (RelativeLayout) itemView.findViewById((R.id.rl_item));


        }
    }
}
