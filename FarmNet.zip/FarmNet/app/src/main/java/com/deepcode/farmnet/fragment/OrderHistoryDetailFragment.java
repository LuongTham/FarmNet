package com.deepcode.farmnet.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.R;
import com.deepcode.farmnet.adapter.OrderHistoryDetailAdapter;
import com.deepcode.farmnet.core.Data;
import com.deepcode.farmnet.model.OrderHistoryDetailModel;

import java.util.ArrayList;
import java.util.List;

public class OrderHistoryDetailFragment extends  BaseFragment
{
    @Override
    public void constructorView() {

    }

    @Override
    public void setOnClick() {

    }

    @Override
    public void loadDateView() {

    }
    RecyclerView recyclerView;

    private  void loadData()
    {


    }
    Button btnBack;
    public static RelativeLayout rl_all;
    TextView madonhang, diachikhachhang;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_orderhistory_detail, container, false);
        Data.onOrderHistoryDetailFragment = true;

        List<OrderHistoryDetailModel> list = new ArrayList<>();

        for(int i = 0; i <= 5; i++)
        {
            list.add(new OrderHistoryDetailModel("Trà đá","50.000 VND"));
            list.add(new OrderHistoryDetailModel("Trà thảo mộc","100.000 VND"));
            list.add(new OrderHistoryDetailModel("Trà Ô long","100.000 VND"));
            list.add(new OrderHistoryDetailModel("Cơm rang muối","500.000 VND"));
            list.add(new OrderHistoryDetailModel("Canh cua trộn huyết long","1.000.000 VND"));
            list.add(new OrderHistoryDetailModel("Xương xào mỡ muỗi","900.000 VND"));
        }
        diachikhachhang = view.findViewById(R.id.tvline22);
        madonhang = view.findViewById(R.id.tvline13);
        madonhang.setSelected(true);
        diachikhachhang.setSelected(true);

        recyclerView = (RecyclerView)view.findViewById(R.id.recyclerViewdetail);

        OrderHistoryDetailAdapter adapter = new OrderHistoryDetailAdapter(list);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);

        btnBack = (Button)view.findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });
        return view;
    }

}
