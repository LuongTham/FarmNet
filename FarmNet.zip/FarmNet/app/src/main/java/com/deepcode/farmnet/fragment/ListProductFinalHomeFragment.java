package com.deepcode.farmnet.fragment;

import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.adapter.CategoryTextAdapter;
import com.deepcode.farmnet.adapter.GroupTextAdapter;
import com.deepcode.farmnet.adapter.ListProductFinalHomeAdapter;
import com.deepcode.farmnet.bean.Category;
import com.deepcode.farmnet.core.Connector;
import com.deepcode.farmnet.core.Data;
import com.deepcode.farmnet.extend.RecyclerItemClickListener;
import com.deepcode.farmnet.model.CheckButton;
import com.deepcode.farmnet.model.ProductModel;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ListProductFinalHomeFragment extends  BaseFragment{
    @Override
    public void constructorView() {

    }

    @Override
    public void setOnClick() {

    }

    @Override
    public void loadDateView() {

    }

    ListProductFinalHomeAdapter listProductFinalHomeAdapter;
    CategoryTextAdapter categoryTextAdapter;
    RecyclerView recyclerViewProduct;
    RecyclerView recyclerViewCategory;

    List<ProductModel> productModelList = new ArrayList<>();
    List<Category> categoryList = new ArrayList<>();
    List<CheckButton> checkButtonList = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_home_listproduct_final, container, false);

        recyclerViewProduct = (RecyclerView)view.findViewById(R.id.rvlistproduct);
        recyclerViewCategory = (RecyclerView)view.findViewById(R.id.rvCategory);

        new LoadCategoryAsyncTask().execute();


      // et// recyclerViewCategory.getLayoutManager().s

        recyclerViewCategory.setHorizontalScrollBarEnabled(false);
        recyclerViewCategory.setNestedScrollingEnabled(false);
        //recyclerViewCategory.setScrollbarFadingEnabled(false);

        recyclerViewCategory.addOnItemTouchListener(new RecyclerItemClickListener(getContext(),
                recyclerViewCategory ,new RecyclerItemClickListener.OnItemClickListener()
                {
                    @Override public void onItemClick(View view, int position) {
                        productModelList = new ArrayList<>();

                        productModelList.add(new ProductModel("ABC",15000,0,"Lang Long Phu Yen","","Hà Nội", "100% cải bắp tươi sạch..."));
                        productModelList.add(new ProductModel("XYZ",10000,0,"Lang Long Phu Yen","","Hà Nội", "100% cải bắp tươi sạch..."));
                        productModelList.add(new ProductModel("THANH",30000,0,"Lang Long Phu Yen","","Hà Nội", "100% cải bắp tươi sạch..."));
                        productModelList.add(new ProductModel("ABC",15000,0,"Lang Long Phu Yen","","Hà Nội", "100% cải bắp tươi sạch..."));
                        productModelList.add(new ProductModel("XYZ",10000,0,"Lang Long Phu Yen","","Hà Nội", "100% cải bắp tươi sạch..."));
                        productModelList.add(new ProductModel("THANH",30000,0,"Lang Long Phu Yen","","Hà Nội","100% cải bắp tươi sạch..."));

                        for (int i = 0; i<productModelList.size();i++){
                            productModelList.get(i).setImage(Data.categoryList.get(position).getImage());
                        }
                        listProductFinalHomeAdapter.refreshData(productModelList);

                        Data.positionCategoryCurent = position;
                        categoryTextAdapter.notifyDataSetChanged();

                    }

                    @Override public void onLongItemClick(View view, int position) {
                        // do whatever
                    }
                })
        );
        return view;
    }


    private class LoadCategoryAsyncTask extends AsyncTask
    {
        String url =  Connector.rootURL+ "category/GetAll";
        String responseString = null;
        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
        }
        @Override
        protected Object doInBackground(Object[] objects)
        {
            try
            {
                responseString = Connector.doPostRequest(url,"");
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
        @Override
        protected void onPostExecute(Object o)
        {
            super.onPostExecute(o);
            System.out.println("Response:"+ responseString);

            Gson gson = new Gson();

            TypeToken<List<Category>> token = new TypeToken<List<Category>>() {};
            categoryList = gson.fromJson(responseString, token.getType());

            categoryTextAdapter = new CategoryTextAdapter(categoryList, getContext());
            LinearLayoutManager layoutManager2 = new LinearLayoutManager(getContext());
            layoutManager2.setOrientation(LinearLayoutManager.HORIZONTAL);
            recyclerViewCategory.setLayoutManager(layoutManager2);
            recyclerViewCategory.setAdapter(categoryTextAdapter);



            //chua co du lieu get Product by categoryID nen lay tam list nay
            productModelList.add(new ProductModel("Cải bắp",15000,0,"ABC","","Hà Nội", "100% cải bắp tươi sạch..."));
            productModelList.add(new ProductModel("Dưa chuột",10000,0,"ABC","","Hà Nội","100% cải bắp tươi sạch..."));
            productModelList.add(new ProductModel("Hành lá",30000,0,"ABC","","Hà Nội","100% cải bắp tươi sạch..."));
            productModelList.add(new ProductModel("Tỏi cô đơn",50000,0,"ABC","","Hà Nội","100% cải bắp tươi sạch..."));
            productModelList.add(new ProductModel("Bí dài",20000,0,"ABC","","Hà Nội","100% cải bắp tươi sạch..."));
            productModelList.add(new ProductModel("Rau muống",10000,0,"ABC","","Hà Nội","100% cải bắp tươi sạch..."));
            productModelList.add(new ProductModel("Dưa chua",10000,0,"ABC","","Hà Nội", "100% cải bắp tươi sạch..."));

            String image64 = categoryList.get(0).getImage(); //lay tam ava cua category dau tien cho product


            for(int i = 0; i<productModelList.size();i++){
                productModelList.get(i).setImage(image64);
            }


            // show list product
            listProductFinalHomeAdapter = new ListProductFinalHomeAdapter(productModelList, getContext());
            LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
            layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
            recyclerViewProduct.setLayoutManager(layoutManager);
            recyclerViewProduct.setAdapter(listProductFinalHomeAdapter);
        }
    }

}
