package com.deepcode.farmnet.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import com.deepcode.farmnet.R;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.bean.TopProduct;
import com.deepcode.farmnet.core.ImageUtil;
import com.deepcode.farmnet.model.ProductModel;

import java.util.List;

public class MediumSaleHomeAdapter extends RecyclerView.Adapter<MediumSaleHomeAdapter.RecyclerViewHolder> {
    List<TopProduct> listProductsale;

    public MediumSaleHomeAdapter(List<TopProduct> list)
    {
        listProductsale = list;
    }


    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.item_medium_sale_home, parent, false);
        return new RecyclerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position) {


        System.out.println("SIZELLL:"+listProductsale.size());
        try{
            TopProduct productModel = listProductsale.get(position);
            holder.image.setImageBitmap(ImageUtil.bitmapFromBase64(productModel.getImage()));

        }catch (Exception e)
        {

        }

    }

    @Override
    public int getItemCount() {
        return listProductsale.size();
    }

    public class RecyclerViewHolder extends RecyclerView.ViewHolder {
        ImageView image;
        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.imgView);
        }
    }
}
