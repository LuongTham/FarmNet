package com.deepcode.farmnet.model;

public class OrderHistoryDetailModel {
    private String name;
    private String giatien;

    public OrderHistoryDetailModel(String name, String giatien) {
        this.name = name;
        this.giatien = giatien;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGiatien() {
        return giatien;
    }

    public void setGiatien(String giatien) {
        this.giatien = giatien;
    }
}
