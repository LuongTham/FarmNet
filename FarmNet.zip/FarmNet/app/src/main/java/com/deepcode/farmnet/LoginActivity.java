package com.deepcode.farmnet;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.deepcode.farmnet.core.Data;
import com.deepcode.farmnet.fragment.AccountFragment;
import com.deepcode.farmnet.fragment.OrderHistoryFragment;
import com.deepcode.farmnet.sharepref.MyPreferenceManager;

public class LoginActivity extends AppCompatActivity {
    Button btn_Login;
    TextView btn_SignUp;
    RelativeLayout rl_sigIn, rl_signUp;
    TextView btn_login_signUp;
    CheckBox check_remember;
    EditText userName, passWord;


    public static final String MyPREFERENCES = "MyPrefs";
    public static final String UserName = "userName";
    public static final String PassWord = "passWord";

    MyPreferenceManager myPreferenceManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_account);

        btn_SignUp = findViewById(R.id.btn_signup);

        rl_sigIn = findViewById(R.id.rl_sigIn);

        rl_signUp = findViewById(R.id.rl_signup);
        btn_login_signUp = findViewById(R.id.btn_login_SignUp);

        userName = (EditText) findViewById(R.id.edt_username);
        passWord = (EditText) findViewById(R.id.edt_password);
        check_remember = (CheckBox) findViewById(R.id.check_rememberMe);

        btn_Login = findViewById(R.id.button_signin);

        myPreferenceManager = MyPreferenceManager.getInstance(this);
        userName.setText(myPreferenceManager.getValue(UserName, ""));
        passWord.setText(myPreferenceManager.getValue(PassWord, ""));
        btn_SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rl_sigIn.setVisibility(View.GONE);
                rl_signUp.setVisibility(View.VISIBLE);
            }
        });
        check_remember.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {

                }
            }
        });
        btn_Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = userName.getText().toString();
                String pass = passWord.getText().toString();

                myPreferenceManager.setValue(UserName, name);
                myPreferenceManager.setValue(PassWord, pass);

                Toast.makeText(LoginActivity.this, "Thanks", Toast.LENGTH_LONG).show();


                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
        btn_login_signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rl_sigIn.setVisibility(View.VISIBLE);
                rl_signUp.setVisibility(View.GONE);

            }
        });

    }

}
