package com.deepcode.farmnet.request;

public class ComboID {

    private long id;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
