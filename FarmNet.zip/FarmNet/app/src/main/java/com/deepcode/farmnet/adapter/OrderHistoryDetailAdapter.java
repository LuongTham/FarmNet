package com.deepcode.farmnet.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.R;
import com.deepcode.farmnet.model.OrderHistoryDetailModel;
import com.deepcode.farmnet.model.OrderHistoryModel;

import java.util.ArrayList;
import java.util.List;


public class OrderHistoryDetailAdapter extends RecyclerView.Adapter<OrderHistoryDetailAdapter.RecyclerViewHolder>
{
    List<OrderHistoryDetailModel> listOrder = new ArrayList<>();
    public OrderHistoryDetailAdapter(List<OrderHistoryDetailModel> list)
    {
        listOrder = list;
    }
    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.item_lichsu_giaodich_detail, parent, false);
        return new RecyclerViewHolder(view);    }
    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position)
    {
        OrderHistoryDetailModel itemdata = listOrder.get(position);
        holder.txtName.setText(itemdata.getName());
        holder.txtgiatien.setText(itemdata.getGiatien());

    }
    @Override
    public int getItemCount()
    {
        return listOrder.size();
    }


    public class RecyclerViewHolder extends RecyclerView.ViewHolder
    {

        TextView txtName, txtgiatien;

        public RecyclerViewHolder(View itemView)
        {
            super(itemView);
            txtName = (TextView) itemView.findViewById(R.id.tensp_LSGDD);
            txtgiatien = (TextView) itemView.findViewById(R.id.giatien_LSGDD);




        }
    }
}
