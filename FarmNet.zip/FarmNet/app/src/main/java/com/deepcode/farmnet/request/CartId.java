package com.deepcode.farmnet.request;

public class CartId {

    private long id;

    public CartId() {

    }

    public CartId(long id) {
        super();
        this.id = id;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

}
