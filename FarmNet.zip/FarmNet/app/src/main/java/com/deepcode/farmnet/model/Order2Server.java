package com.deepcode.farmnet.model;

import android.provider.SyncStateContract;

import com.deepcode.farmnet.bean.ProductOrder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.Date;
import java.util.List;

public class Order2Server {
    private long orderID;
    private List<ProductOrder> listProductOrder;
    private String address;
    private Date createdDate;
    private String userName;
    private String phone;
    private String userId;
    private String deviceId;
    private String deviceType;
    private boolean delete;

    public Order2Server() {
        super();
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public boolean isDelete() {
        return delete;
    }

    public void setDelete(boolean delete) {
        this.delete = delete;
    }

    public long getOrderID() {
        return orderID;
    }

    public void setOrderID(long orderID) {
        this.orderID = orderID;
    }

    public List<ProductOrder> getListProductOrder() {
        return listProductOrder;
    }

    public void setListProductOrder(List<ProductOrder> listProductOrder) {
        this.listProductOrder = listProductOrder;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Order2Server(String json) throws Exception {
        this(new JsonParser().parse(json).getAsJsonObject());
    }

    public Order2Server(JsonObject obj) throws Exception {
//        parse(obj);
    }

//    @SuppressWarnings("unchecked")
//    public void parse(JsonObject obj) throws Exception {
//
//        this.address = obj.get(Fields.F_ADDRESS).getAsString();
//        this.orderID = obj.get(Fields.F_ID).getAsLong();
//        JsonElement tmpCreatedDate = obj.get(Fields.F_CREATED_DATE);
//        if (tmpCreatedDate != null) {
//            this.createdDate = DateUtil.toDate(tmpCreatedDate.getAsString(), SyncStateContract.Constants.DEFAULT_DATETIME_TZ_FORMAT);
//        }
//        this.userName = obj.get(Fields.F_USER_NAME).getAsString();
//        this.phone = obj.get(Fields.F_PHONE).getAsString();
//        this.delete = obj.get(Fields.F_DELETE).getAsBoolean();
//        this.userId = obj.get(Fields.F_USER_ID).getAsString();
//        this.deviceId = obj.get(Fields.F_DEVICE_ID).getAsString();
//        this.deviceType = obj.get(Fields.F_DEVICE_TYPE).getAsString();
//        this.listProductOrder = (List<ProductOrder>) com.deepcode.util.JsonUtils
//                .toBeans(obj.get(Fields.F_ARRAY_PRODUCT_ORDER).getAsJsonArray(), ProductOrder.class);
//
//    }

//    public JsonObject toJsonObject() {
//        JsonObject obj = new JsonObject();
//        obj.addProperty(Fields.F_ID, this.orderID);
//        obj.addProperty(Fields.F_ADDRESS, StringUtil.nvl(this.address));
//        if (this.createdDate != null) {
//            obj.addProperty(Fields.F_CREATED_DATE,
//                    StringUtil.format(this.createdDate, SyncStateContract.Constants.DEFAULT_DATETIME_TZ_FORMAT));
//        }
//        obj.addProperty(Fields.F_USER_NAME, StringUtil.nvl(this.userName));
//        obj.addProperty(Fields.F_PHONE, StringUtil.nvl(this.phone));
//        obj.addProperty(Fields.F_DELETE, this.delete);
//        obj.addProperty(Fields.F_USER_ID, StringUtil.nvl(this.userId));
//        obj.addProperty(Fields.F_DEVICE_ID, StringUtil.nvl(this.deviceId));
//        obj.addProperty(Fields.F_DEVICE_TYPE, StringUtil.nvl(this.deviceType));
//        obj.add(Fields.F_ARRAY_PRODUCT_ORDER, JsonUtils.toJsonArray(this.listProductOrder));
//
//        return obj;
//    }

}
