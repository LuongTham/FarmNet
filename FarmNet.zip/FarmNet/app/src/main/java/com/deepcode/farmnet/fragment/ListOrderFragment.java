package com.deepcode.farmnet.fragment;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.adapter.ListProductFarmAdapter;
import com.deepcode.farmnet.adapter.OrderAdapter;
import com.deepcode.farmnet.adapter.ProductMoreLikeOrderAdapter;
import com.deepcode.farmnet.bean.Cart;
import com.deepcode.farmnet.bean.Category;
import com.deepcode.farmnet.bean.OrderConfirm;
import com.deepcode.farmnet.core.Connector;
import com.deepcode.farmnet.core.Data;
import com.deepcode.farmnet.core.FarmNetStatic;
import com.deepcode.farmnet.core.URL_FarmNet;
import com.deepcode.farmnet.extend.RecyclerItemClickListener;
import com.deepcode.farmnet.extend.WrappingGridView;
import com.deepcode.farmnet.model.Order;
import com.deepcode.farmnet.model.ProductMoreOrder;
import com.deepcode.farmnet.model.ShowCommentModel;
import com.deepcode.farmnet.request.AccountId;
import com.deepcode.farmnet.response.CartResponse;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static java.lang.Math.round;

public class ListOrderFragment extends BaseFragment {
    @Override
    public void constructorView() {
    }

    @Override
    public void setOnClick() {
    }

    @Override
    public void loadDateView() {
    }

    List<CartResponse> cartList = new ArrayList<CartResponse>();
    List<ProductMoreOrder> productMoreOrders = new ArrayList();

    long moneyText = 0;

    public void getData() {
        for (int i = 0; i < 11; i++) {
            productMoreOrders.add(new ProductMoreOrder()); //sản phẩm liên quan
        }
    }

    ProductMoreLikeOrderAdapter productMoreLikeOrderAdapter;
    OrderAdapter orderAdapter;
    RelativeLayout emptyCart;
    WrappingGridView gridViewItem;
    RecyclerView recyclerView;
    String textAddress, textPhone, textNote;
    Button btnBack, btn_emptyCart;
    Button btn_ExpandFarm;
    public static TextView totalMoney;
    TextView btnBuy;
    ImageView btnDelete;

    @SuppressLint("WrongConstant")
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_order, container, false);

        //btn back
        btnBack = (Button) view.findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                System.out.println("Back From Order:" + MainActivity.currentTab);
                MainActivity mainActivity = (MainActivity) getActivity();
                mainActivity.backFromSubView(MainActivity.currentTab);
            }
        });
        emptyCart = (RelativeLayout) view.findViewById(R.id.rl_emptyCart);
        btn_emptyCart = (Button) view.findViewById(R.id.btn_emptyCart);
        btn_emptyCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity mainActivity = (MainActivity) getActivity();
                mainActivity.backFromSubView(MainActivity.TAB_HOME);

            }
        });


        //get data order
        getData();

        //set total money
//        for (int i = 0; i < orderList.size(); i++) {
//            moneyText = moneyText + round(orderList.get(i).getPrice() * orderList.get(i).getCount()
//                    * (1 - orderList.get(i).getDiscount()));
//        }
//

        totalMoney = view.findViewById(R.id.total_money);
        totalMoney.setText("Tổng tiền: " + String.format("%,d", Long.parseLong("" + moneyText)) + "đ");


        // load recyclerview
        recyclerView = (RecyclerView) view.findViewById(R.id.rcv_listOrder);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);


        gridViewItem = (WrappingGridView) view.findViewById(R.id.gridView);
        productMoreLikeOrderAdapter = new ProductMoreLikeOrderAdapter(getContext(), productMoreOrders, getLayoutInflater());
        gridViewItem.setAdapter(productMoreLikeOrderAdapter);


        //btn Buy
        btnBuy = view.findViewById(R.id.btnBuy);
        btnBuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //to do buy
                //  toBuy(orderList);

                MainActivity mainActivity = (MainActivity) getActivity();
                mainActivity.showTabAddress();
                AddressFragment fragment = (AddressFragment)getActivity().getSupportFragmentManager().findFragmentById(R.id.address_fragment);
                fragment.refresh();

            }
        });

        btn_ExpandFarm = (Button) view.findViewById(R.id.expandFarm);
//        btn_ExpandFarm.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                MainActivity mainActivity = (MainActivity)getActivity();
//              mainActivity.showTabFarm();
//            }
//        }
//        );

        new AsyncTaskGetItemCart().execute();
//        recyclerView.addOnItemTouchListener(
//                new RecyclerItemClickListener(getContext(), recyclerView, new RecyclerItemClickListener.OnItemClickListener() {
//                    @Override
//                    public void onItemClick(View view, int position) {
//
//                        System.out.println("AAAAAAAAAAAA");
//
//                        MainActivity mainActivity = (MainActivity) getActivity();
//                        mainActivity.showTabCombo();
//                        // do whatever
//                    }
//
//                    @Override
//                    public void onLongItemClick(View view, int position) {
//                        // do whatever
//                    }
//                })
//        );


        return view;
    }


    public void refresh() {
        new AsyncTaskGetItemCart().execute();
    }

    private void toBuy(List<Order> orderList) {
//        new PostOrderAsyncTask().execute();

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

        LayoutInflater inflater = LayoutInflater.from(getContext());
        View dialogView = inflater.inflate(R.layout.tobuy_confirm_dialog, null);
        builder.setView(dialogView);

        final AlertDialog dialog = builder.create();
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        final TextView btn_cancel, btn_ok;
        final EditText phone, address, note;
        btn_cancel = (TextView) dialogView.findViewById(R.id.cancel_dialog);
        btn_ok = (TextView) dialogView.findViewById(R.id.ok_dialog);
        phone = (EditText) dialogView.findViewById(R.id.edt_numPhone);
        address = (EditText) dialogView.findViewById(R.id.edt_address);
        note = (EditText) dialogView.findViewById(R.id.edt_note);


        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().getWindow()
                        .setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
                dialog.dismiss();
                Toast.makeText(getContext(), "Back !!", Toast.LENGTH_SHORT).show();
            }
        });
        btn_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // xác nhận mua hàng, gửi lệnh


                Toast.makeText(getContext(), "Xác nhận đơn hàng " + textAddress + " - " + textPhone, Toast.LENGTH_SHORT).show();
                getActivity().getWindow()
                        .setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
                dialog.dismiss();
            }
        });

        address.requestFocus();
        address.setCursorVisible(false);
        address.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                textAddress = "";
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                textAddress = s + "";
            }

            @Override
            public void afterTextChanged(Editable s) {
                textAddress = s + "";
            }
        });

        phone.requestFocus();
        phone.setCursorVisible(false);
        phone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                textPhone = "";
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                textPhone = "" + s;
            }

            @Override
            public void afterTextChanged(Editable s) {
                textPhone = "" + s;
            }
        });
        dialog.show();
    }

    public class AsyncTaskGetItemCart extends AsyncTask<Void, Void, Void> {
        String responseString = null;
        Gson gson = new Gson();
        AccountId accountId = new AccountId();

        @Override
        protected void onPreExecute() {
            try {
                accountId.setId(FarmNetStatic.getInstance().getAccount().getAccountID());

            } catch (Exception ex) {

            }
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... voids) {

            try {
                responseString = Connector.doPostRequest(Connector.rootURL + URL_FarmNet.GETLIST_CART, gson.toJson(accountId));
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);


            try {

                TypeToken<List<CartResponse>> token = new TypeToken<List<CartResponse>>() {
                };
                cartList = gson.fromJson(responseString, token.getType());

                FarmNetStatic.cartResponseList = cartList;
                orderAdapter = new OrderAdapter((MainActivity)getActivity(),cartList, productMoreOrders);
                recyclerView.setAdapter(orderAdapter);

                int sizeCart = cartList.size();

                FarmNetStatic.getInstance().setSizeCart(sizeCart);

                if (cartList.size() == 0) {
                    emptyCart.setVisibility(View.VISIBLE);
                } else {
                    emptyCart.setVisibility(View.GONE);

                }

                updateCountCart();
            } catch (Exception ex) {

            }


        }
    }

    public void updateCountCart() {
        HomeFragment fragment = (HomeFragment) getActivity().getSupportFragmentManager().findFragmentById(R.id.home_fragment);
        fragment.updateCountCart();

    }

}
