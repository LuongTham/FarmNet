package com.deepcode.farmnet.network;

import com.deepcode.farmnet.bean.Category;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.POST;

public interface InterfaceAPI {
    @POST("/category/GetAll")
    Call<List<Category>> getAllCategory();

}