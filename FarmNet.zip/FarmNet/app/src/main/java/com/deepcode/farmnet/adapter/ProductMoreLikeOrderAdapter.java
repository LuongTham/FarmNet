package com.deepcode.farmnet.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.R;
import com.deepcode.farmnet.bean.Category;
import com.deepcode.farmnet.bean.Product;
import com.deepcode.farmnet.model.ProductMoreOrder;
import com.google.android.material.textfield.TextInputEditText;
import com.skyfishjy.library.RippleBackground;

import java.util.ArrayList;
import java.util.List;

public class ProductMoreLikeOrderAdapter extends BaseAdapter{
    private final Context mContext;
    private List<ProductMoreOrder> productMoreOrders = new ArrayList<ProductMoreOrder>();
    private LayoutInflater layoutInflater;

    public ProductMoreLikeOrderAdapter(Context mContext, List<ProductMoreOrder> productMoreOrders, LayoutInflater layoutInflater) {
        this.mContext = mContext;
        this.productMoreOrders = productMoreOrders;
        this.layoutInflater = layoutInflater;
    }

    @Override
    public int getCount() {
        return 10;
    }

    @Override
    public Object getItem(int position) {
        return productMoreOrders.get(position);
    }

    @Override
    public long getItemId(int position)
    {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
       // ProductMoreLikeOrderAdapter.ViewHolder holder = null;
        final ViewHolder holder;
        if (convertView == null)
        {
            LayoutInflater layoutInflater = LayoutInflater.from(mContext);
            convertView = layoutInflater.inflate(R.layout.order_item_more_product, null);
            holder = new ViewHolder();
            holder.detail = (TextView) convertView.findViewById(R.id.tvDes1);
            holder.imageView = (ImageView) convertView.findViewById(R.id.image);
            holder.price = (TextView) convertView.findViewById(R.id.txt_price);
            holder.txt_sold = (TextView) convertView.findViewById(R.id.number_sold);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        return convertView;
    }
    static class ViewHolder
    {
        TextView detail;
        ImageView imageView;
        TextView price;
        TextView txt_sold;

    }

}