package com.deepcode.farmnet.farmnet_interface;

public interface UpdateInterface {

    public  void updateCountCart();
    public void updateCountMessage();

}
