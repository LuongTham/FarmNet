package com.deepcode.farmnet.fragment;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.adapter.CategoryAdapter;
import com.deepcode.farmnet.bean.Category;
import com.deepcode.farmnet.core.Connector;
import com.deepcode.farmnet.core.Data;
import com.deepcode.farmnet.extend.WrappingGridView;
import com.deepcode.farmnet.model.CategoryModel;
import com.deepcode.farmnet.model.ProductModel;
import com.deepcode.farmnet.network.APIClient;
import com.deepcode.farmnet.network.InterfaceAPI;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CategoryHomeFragment extends BaseFragment

{

    @Override
    public void constructorView()
    {

    }
    @Override
    public void setOnClick()
    {

    }

    @Override
    public void loadDateView()
    {

    }
    WrappingGridView gridViewItem;

    CategoryAdapter categoryAdapter;

    List<Category> categoryList = new ArrayList<>();


    InterfaceAPI interfaceAPI;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_home_category, container, false);
        gridViewItem = (WrappingGridView)view.findViewById(R.id.gridView);

        new LoadCategoryAsyncTask().execute();

//        interfaceAPI = APIClient.getClient().create(InterfaceAPI.class);
//
//        Call<List<Category>> call = interfaceAPI.getAllCategory();
//
//
//        call.enqueue(new Callback<List<Category>>() {
//            @Override
//            public void onResponse(Call<List<Category>> call, Response<List<Category>> response) {
//
//                categoryList = response.body();
//
//                Gson gson = new Gson();
//
//                TypeToken<List<Category>> token = new TypeToken<List<Category>>() {};
//
//                try{
//                    Data.categoryList = categoryList;
//                    categoryAdapter = new CategoryAdapter(getActivity(), categoryList);
//                    gridViewItem.setAdapter(categoryAdapter);
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//
//            @Override
//            public void onFailure(Call<List<Category>> call, Throwable t) {
//
//            }
//        });

        gridViewItem.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Data.positionCategoryCurent = position;
                MainActivity.showTabProduct();
// ListProductFinalFragment.getInstance();


            }
        });


        return view;
    }



    private class LoadCategoryAsyncTask extends AsyncTask
    {
        String url = Connector.rootURL+ "category/GetAll";
        String responseString = null;
        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
        }
        @Override
        protected Object doInBackground(Object[] objects)
        {
            try
            {
                responseString = Connector.doPostRequest(url,"");
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
        @Override
        protected void onPostExecute(Object o)
        {
            super.onPostExecute(o);
            System.out.println("Response:"+ responseString);

            Gson gson = new Gson();

            TypeToken<List<Category>> token = new TypeToken<List<Category>>() {};

            try{
                categoryList = gson.fromJson(responseString, token.getType());
                Data.categoryList = categoryList;
                categoryAdapter = new CategoryAdapter(getActivity(), categoryList);
                gridViewItem.setAdapter(categoryAdapter);
            } catch (Exception e) {
                e.printStackTrace();
            }


// getFullProduct();

        }
    }

    String categoryID = "";
    List<ProductModel> productList = new ArrayList<>();


    public void getFullProduct() {
        for (int i = 0; i<categoryList.size();i++){
            categoryID = categoryList.get(i).getCategoryID()+"";
            new LoadProductbyCategoryAsyncTask();
           /// categoryList.get(i).setProductList(productList);
        }
        Data.categoryList = categoryList;
    }

    private class LoadProductbyCategoryAsyncTask extends AsyncTask
    {
        String url = Connector.rootURL+ "product/ByCategoryId";
        String responseString = null;

        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
        }
        @Override
        protected Object doInBackground(Object[] objects)
        {
            try
            {
                responseString = Connector.doPostRequest(url,categoryID);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
        @Override
        protected void onPostExecute(Object o)
        {
            super.onPostExecute(o);
            Gson gson = new Gson();

            TypeToken<List<Category>> token = new TypeToken<List<Category>>() {};
            productList = gson.fromJson(responseString, token.getType());

        }
    }

    interface RefreshInterface{
        public void refreshAdapter();
    }
}