package com.deepcode.farmnet.model;

public class CheckButton {

    private  boolean check ;

    public boolean isCheck() {
        return check;
    }

    public void setCheck(boolean check) {
        this.check = check;
    }
}
