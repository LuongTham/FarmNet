package com.deepcode.farmnet.bean;

import java.util.Date;
import java.util.List;

public class Account {

    private long accountID;
    private String name;
    private String phone;
    private String email;
    private String address;

    private String location;
    private Date createdDate;
    private Date modifiedDate;
    private boolean delete;
    private Boolean anonymous;
    private String deviceId;
    private Date chatTimeUpdate;


    private List<AddressOrder> listAddressOrder;

    public List<AddressOrder> getListAddressOrder() {
        return listAddressOrder;
    }

    public void setListAddressOrder(List<AddressOrder> listAddressOrder) {
        this.listAddressOrder = listAddressOrder;
    }

    public long getAccountID() {
        return accountID;
    }

    public void setAccountID(long accountID) {
        this.accountID = accountID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public boolean isDelete() {
        return delete;
    }

    public void setDelete(boolean delete) {
        this.delete = delete;
    }

    public Boolean getAnonymous() {
        return anonymous;
    }

    public void setAnonymous(Boolean anonymous) {
        this.anonymous = anonymous;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public Date getChatTimeUpdate() {
        return chatTimeUpdate;
    }

    public void setChatTimeUpdate(Date chatTimeUpdate) {
        this.chatTimeUpdate = chatTimeUpdate;
    }
}
