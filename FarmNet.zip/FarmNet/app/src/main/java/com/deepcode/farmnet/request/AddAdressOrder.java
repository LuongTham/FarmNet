package com.deepcode.farmnet.request;

import com.deepcode.farmnet.bean.AddressOrder;

import java.util.List;

public class AddAdressOrder {

    private long id;

    private List<AddressOrder> listAddr;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public List<AddressOrder> getListAddr() {
        return listAddr;
    }

    public void setListAddr(List<AddressOrder> listAddr) {
        this.listAddr = listAddr;
    }

}
