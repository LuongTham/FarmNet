package com.deepcode.farmnet.core;

public class URL_FarmNet {

    public static final String url_checkExistDeviceID = "account/CheckExistDeviceID";
    public static final String url_createNewAccount = "account/Add";
    public static final String url_getMessage = "message/SearchAllById";
    public static final String ADD_MESSAGE =  "message/Add";
    public static final String ADD_CART =  "cart/AddCart";
    public static final String DELETE_CART =  "cart/DeleteCart";

    public static final String GETLIST_CART =  "cart/SearchByAccountId";
    public static final String GETLIST_ADDRESS =  "account/GetListAddressOrder";
    public static final String GETLIST_AddNewAddress =  "account/AddAddress";
    public static final String GETLIST_DeleteAddress =  "account/DeleteAddress";
    public static final String Confirm_Order =  "";


}
