package com.deepcode.farmnet.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.deepcode.farmnet.R;

public class ReportFragment extends BaseFragment{
    RelativeLayout rl_exel;
    RelativeLayout rl_chart1;
    RelativeLayout rl_chart2;
    @Override
    public void constructorView() {

    }

    @Override
    public void setOnClick() {

    }

    @Override
    public void loadDateView() {

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.report_fragment, container, false);

        rl_exel = view.findViewById(R.id.rl_exel);
        rl_chart1 = view.findViewById(R.id.rl_chart1);
        rl_chart2 = view.findViewById(R.id.rl_chart2);
        return view;
    }
}
