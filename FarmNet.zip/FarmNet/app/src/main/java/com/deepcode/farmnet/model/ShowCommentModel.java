package com.deepcode.farmnet.model;

import java.sql.Time;
import java.util.Date;

public class ShowCommentModel {
    private int avatar;
    private String name;
    private String content;
    private float ratingStar;
    private String date;
    private String time;

    public int getAvatar() {
        return avatar;
    }

    public void setAvatar(int avatar) {
        this.avatar = avatar;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public float getRatingStar() {
        return ratingStar;
    }

    public void setRatingStar(float ratingStar) {
        this.ratingStar = ratingStar;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public ShowCommentModel(int avatar, String name, String content, float ratingStar, String date, String time) {
        this.avatar = avatar;
        this.name = name;
        this.content = content;
        this.ratingStar = ratingStar;
        this.date = date;
        this.time = time;
    }
}
