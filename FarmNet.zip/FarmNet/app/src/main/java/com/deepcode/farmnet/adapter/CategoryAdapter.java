package com.deepcode.farmnet.adapter;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.bean.Category;
import com.deepcode.farmnet.core.Data;
import com.deepcode.farmnet.core.ImageUtil;
import com.deepcode.farmnet.fragment.ListProductFinalFragment;
import com.deepcode.farmnet.fragment.ProductFragment;
import com.skyfishjy.library.RippleBackground;
import java.util.ArrayList;
import java.util.List;
public class CategoryAdapter extends BaseAdapter {
    private final Context mContext;
    private List<Category> categoryList = new ArrayList<Category>();
    private LayoutInflater layoutInflater;
    public CategoryAdapter(Context mContext, List<Category> categoryList) {
        this.mContext = mContext;
        this.categoryList = categoryList;
        layoutInflater = LayoutInflater.from(mContext);
    }
    @Override
    public int getCount() {
        return categoryList.size();
    }
    @Override
    public Object getItem(int position) {
        return categoryList.get(position);
    }
    @Override
    public long getItemId(int position)
    {
        return position;
    }
    @Override
    public View getView(final  int position, View convertView, ViewGroup parent) {
        final ViewHolder holder;
        if (convertView == null)
        {
            LayoutInflater layoutInflater = LayoutInflater.from(mContext);
            convertView = layoutInflater.inflate(R.layout.grid_category_item, null);
            holder = new ViewHolder();
            holder.itemImg = (ImageView) convertView.findViewById(R.id.imgIcon);
            holder.itemText = (TextView) convertView.findViewById(R.id.tvCategory);
            holder.r_category = (RippleBackground)convertView.findViewById(R.id.r_category);
            holder.rl_item = (RelativeLayout) convertView.findViewById(R.id.rl_item);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        Category category = categoryList.get(position);
        holder.itemImg.setImageBitmap(ImageUtil.bitmapFromBase64(category.getImage()));
        holder.itemText.setText(category.getName());
        String colorString = category.getColorBg();
        String [] colorArray = colorString.split("-");
        GradientDrawable gradientDrawable = ImageUtil.getGradientColor(colorArray[0],colorArray[1]);
        holder.r_category.setBackground(gradientDrawable);
        holder.itemImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             //   holder.r_category.startRippleAnimation();
            }
        });
        return convertView;
    }
    static class ViewHolder
    {
        RelativeLayout rl_item;
        RippleBackground r_category;
        ImageView itemImg;
        TextView itemText;
    }




}


