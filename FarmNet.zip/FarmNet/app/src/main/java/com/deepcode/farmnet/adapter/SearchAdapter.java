package com.deepcode.farmnet.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.R;
import com.deepcode.farmnet.model.ProductModel;
import java.util.List;
public class SearchAdapter extends RecyclerView.Adapter<SearchAdapter.RecyclerViewHolder>
{
    List<ProductModel> listProduct;
    public SearchAdapter(List<ProductModel> list)
    {
        listProduct = list;
    }
    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.search_item_view, parent, false);
        return new RecyclerViewHolder(view);    }
    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position)
    {
        // ProductModel productModel = listProduct.get(position);

        //        holder.txtUserName.setText(data.get(position));

    }
    @Override
    public int getItemCount()
    {
        return 20;
    }
    public class RecyclerViewHolder extends RecyclerView.ViewHolder
    {
        TextView txtPrice;
        TextView txtFarm;
        TextView txtProduct;
        ImageView imageView;

        public RecyclerViewHolder(View itemView)
        {
            super(itemView);
            // txtUserName = (TextView) itemView.findViewById(R.id.user_name);
        }
    }
}
