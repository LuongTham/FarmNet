package com.deepcode.farmnet.core;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.util.Base64;

public class ImageUtil {


    public static Bitmap bitmapFromBase64(String encodedImage)
    {
        byte[] decodedString = Base64.decode(encodedImage, Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        return  decodedByte;
    }

    public static GradientDrawable getGradientColor(String backgroundColor, String borderColor) {

        int[] colors = {Color.parseColor(backgroundColor), Color.parseColor(borderColor)};

        GradientDrawable shape = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, colors);
        shape.setShape(GradientDrawable.OVAL);
        shape.setCornerRadii(new float[]{0, 0, 0, 0, 0, 0, 0, 0});
        return shape;
    }


    public static GradientDrawable getGradientRectangleColor(String backgroundColor, String borderColor) {

        int[] colors = {Color.parseColor(backgroundColor), Color.parseColor(borderColor)};

        GradientDrawable shape = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, colors);
        shape.setShape(GradientDrawable.RECTANGLE);
        shape.setCornerRadii(new float[]{0, 0, 0, 0, 0, 0, 0, 0});
        shape.setCornerRadius(50);
        return shape;
    }



}
