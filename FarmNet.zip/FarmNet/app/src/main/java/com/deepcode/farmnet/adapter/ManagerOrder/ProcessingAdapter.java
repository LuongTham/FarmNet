package com.deepcode.farmnet.adapter.ManagerOrder;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.R;
import com.deepcode.farmnet.bean.Product;
import com.deepcode.farmnet.bean.ProductOrder;

import java.util.ArrayList;
import java.util.List;

public class ProcessingAdapter extends RecyclerView.Adapter<ProcessingAdapter.ViewHolder> {
    Context context;
    private List<Product> lstProduct = new ArrayList<Product>();

    public ProcessingAdapter(Context context, List<Product> lstProduct) {
        this.context = context;
        this.lstProduct = lstProduct;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product_processing, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {


    }

    @Override
    public int getItemCount() {
        return 5;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgIcon;
        TextView keyOrder, txt_status,tvProduct,tvDescription, tvPriceKM, txt_numberItem;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgIcon = itemView.findViewById(R.id.imgIcon);
            keyOrder = itemView.findViewById(R.id.keyOrder);
            txt_numberItem = itemView.findViewById(R.id.txt_numberItem);
            txt_status = itemView.findViewById(R.id.txt_status);
            tvPriceKM = itemView.findViewById(R.id.tvPriceKM);
            tvDescription = itemView.findViewById(R.id.tvDescription);
            tvProduct = itemView.findViewById(R.id.tvProduct);
        }
    }
}
