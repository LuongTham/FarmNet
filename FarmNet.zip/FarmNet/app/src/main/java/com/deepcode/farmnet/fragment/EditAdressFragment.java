//package com.deepcode.farmnet.fragment;
//
//import android.os.Bundle;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.EditText;
//import android.widget.LinearLayout;
//
//import androidx.annotation.NonNull;
//import androidx.annotation.Nullable;
//import androidx.fragment.app.FragmentTransaction;
//
//import com.deepcode.farmnet.R;
//import com.deepcode.farmnet.bean.Address;
//import com.deepcode.farmnet.core.FarmNetStatic;
//
//import java.util.ArrayList;
//import java.util.List;
//
//public class EditAdressFragment extends BaseFragment {
//    @Override
//    public void constructorView() {
//
//    }
//
//    @Override
//    public void setOnClick() {
//
//    }
//
//    @Override
//    public void loadDateView() {
//
//    }
//
//    List<Address> lstAddess = new ArrayList<Address>();
//    EditText name;
//    EditText phone;
//    EditText province;
//    EditText distric;
//    EditText ward;
//    EditText detailAddress;
//    LinearLayout btnSave;
//    @Nullable
//    @Override
//    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//        View view = inflater.inflate(R.layout.fragment_edit_address, container, false);
//        btnSave = (LinearLayout) view.findViewById(R.id.btnSave);
//        name = view.findViewById(R.id.edt_name);
//        phone = view.findViewById(R.id.edt_phone);
//        province = view.findViewById(R.id.edt_province);
//        distric = view.findViewById(R.id.edt_distric);
//        ward = view.findViewById(R.id.edt_ward);
//        detailAddress = view.findViewById(R.id.edt_addressDetail);
//
//        Address address = FarmNetStatic.getInstance();
//
//        address.setAddressID(1);
//        address.setName(name.getText().toString());
//        address.setPhone(phone.getText().toString());
//        address.setProvince(province.getText().toString());
//        address.setDistrict(distric.getText().toString());
//        address.setWard(ward.getText().toString());
//        address.setDetailAddress(detailAddress.getText().toString());
//
//        FarmNetStatic.addressList.add(address);
//
//        FragmentTransaction ft = getFragmentManager().beginTransaction();
//        ft.replace(R.id.address_fragment, new AddressFragment()).addToBackStack("").commit();
//
//        return  view;
//    }
//}
