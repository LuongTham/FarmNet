package com.deepcode.farmnet.fragment;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.adapter.CategoryAdapter;
import com.deepcode.farmnet.adapter.HeaderHomeAdapter;
import com.deepcode.farmnet.bean.Category;
import com.deepcode.farmnet.bean.TopProduct;
import com.deepcode.farmnet.core.Connector;
import com.deepcode.farmnet.extend.RecyclerItemClickListener;
import com.deepcode.farmnet.model.ProductModel;
import com.deepcode.farmnet.request.TopRequest;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.jar.JarEntry;

public class HeaderHomeFragment extends BaseFragment {
    @Override
    public void constructorView() {
    }
    @Override
    public void setOnClick()
    {
    }
    @Override
    public void loadDateView() {
    }
    HeaderHomeAdapter mRcvAdapter;
    List<TopProduct> topProductList = new ArrayList<>();
    RecyclerView recyclerView;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
         super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_home_header, container, false);
        recyclerView = (RecyclerView)view.findViewById(R.id.rvHeader);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        layoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.addOnItemTouchListener(
                new RecyclerItemClickListener(getContext(), recyclerView ,new RecyclerItemClickListener.OnItemClickListener()
                {
                    @Override public void onItemClick(View view, int position)
                    {
                        TopProduct topProduct = topProductList.get(position);
                        if(topProduct.isCombo())
                        {
                            // if topproduct is a combo .. go to combo fragment
                            MainActivity.showTabCombo();
                            ComboDetailFragment.getInstance().refresh(topProduct.getProductId());
                        }else {
                            // go to product fragment
                            MainActivity.showTabProductDetail();
                            ProductDetailFragment.getInstance().refresh(topProduct.getProductId());
                        }
                    }
                    @Override public void onLongItemClick(View view, int position)
                    {
                    }
                })
        );


        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(),RecyclerView.HORIZONTAL,false){
            @Override
            public boolean checkLayoutParams(RecyclerView.LayoutParams lp) {
                lp.width = (int) ((int)getWidth() / (1.1));
                return true;
            }
        });
        new LoadDataAsyncTask().execute();
        return view;
    }
    class  LoadDataAsyncTask extends AsyncTask {
        String url = Connector.rootURL+ "topproduct/SearchByTypeOnMobile";
        String responseString = null;
        Gson gson = new Gson();
        TopRequest topRequest = new TopRequest();
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            topRequest.setType(1);
        }
        @Override
        protected Object doInBackground(Object[] objects) {
            try
            {
                responseString = Connector.doPostRequest(url,gson.toJson(topRequest));
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            Gson gson = new Gson();
            TypeToken<List<TopProduct>> token = new TypeToken<List<TopProduct>>() {};
            try {
                topProductList = gson.fromJson(responseString, token.getType());
            } catch (Exception e) {
                System.out.println("Error " + e.getMessage());
            }
            if (topProductList != null){
                mRcvAdapter = new HeaderHomeAdapter(topProductList);
                recyclerView.setAdapter(mRcvAdapter);
            }
        }
    }

}
