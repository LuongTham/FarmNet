package com.deepcode.farmnet.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.R;
import com.deepcode.farmnet.bean.OrderConfirm;
import com.deepcode.farmnet.bean.TopProduct;
import com.deepcode.farmnet.core.ImageUtil;
import com.deepcode.farmnet.model.Order;
import com.deepcode.farmnet.response.CartResponse;

import java.util.List;

public class ListOrderPaymentAdapter extends RecyclerView.Adapter<ListOrderPaymentAdapter.ViewHorlder> {
    Context context;
    public List<CartResponse> orderConfirmList;

    public ListOrderPaymentAdapter(Context context, List<CartResponse> orderConfirmList) {
        this.context = context;
        this.orderConfirmList = orderConfirmList;
    }

    @NonNull
    @Override
    public ListOrderPaymentAdapter.ViewHorlder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view =  inflater.inflate(R.layout.item_product_payment, parent, false);
        return new ViewHorlder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ListOrderPaymentAdapter.ViewHorlder holder, int position) {
        CartResponse cartResponse =  orderConfirmList.get(position);
        holder.tvProduct.setText(cartResponse.getName());
       // holder.imgIcon.setImageIcon(cartResponse.getImage());
        holder.imgIcon.setImageBitmap(ImageUtil.bitmapFromBase64(cartResponse.getImage()));
        holder.tvPriceKM.setText(cartResponse.getDiscount()+"");
        holder.tvPriceOrigin.setText(cartResponse.getPrice()+"");
      //  holder.tvDescription.setText(cartResponse.getFarmName());
    }

    @Override
    public int getItemCount() {
        return orderConfirmList.size();
    }

    public static class ViewHorlder extends RecyclerView.ViewHolder {
        TextView tvProduct, tvDescription, tvPriceOrigin,tvPriceKM ,txt_numberItem;
        ImageView imgIcon;
        public ViewHorlder(@NonNull View itemView) {
            super(itemView);
            tvDescription = itemView.findViewById(R.id.tvDescription_payment);
            tvProduct = itemView.findViewById(R.id.tvProduct_payment);
            tvPriceKM = itemView.findViewById(R.id.tvPriceKM_payment);
            tvPriceOrigin = itemView.findViewById(R.id.tvPriceOrigin_payment);
            txt_numberItem = itemView.findViewById(R.id.txt_numberItem_payment);
            imgIcon = itemView.findViewById(R.id.imgIcon_payment);
        }
    }
}
