package com.deepcode.farmnet.fragment;

import android.app.AlertDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.adapter.ComboAdapter;
import com.deepcode.farmnet.adapter.ProductDetailAdapter;
import com.deepcode.farmnet.adapter.RelatedComboAdapter;
import com.deepcode.farmnet.adapter.ShowCommentAdapter;
import com.deepcode.farmnet.bean.ProductCombo;
import com.deepcode.farmnet.core.Connector;
import com.deepcode.farmnet.core.ImageUtil;
import com.deepcode.farmnet.model.Combo;
import com.deepcode.farmnet.model.RelatedComboModel;
import com.deepcode.farmnet.model.ShowCommentModel;
import com.deepcode.farmnet.request.ComboID;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.gson.Gson;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ComboDetailFragment extends BaseFragment {
    ComboAdapter comboAdapter;
    RelatedComboAdapter relatedComboAdapter;
    ArrayList<RelatedComboModel> relatedCombo = new ArrayList<>();
    List<Combo> comboList = new ArrayList<>();
    RecyclerView recyclerView, recyclerView_related;

    RecyclerView rcvShowCommentCombo;
    LinearLayout btnAllReview;

    public static ImageView img_cover;
    public static TextView tvDes, tvTitle, tvPrice, btnReadCmt, write_cmt;
    public static LinearLayout rating;
    public static String base64Img;
    RelativeLayout relativeShowCmtCombo;
    boolean click_cmt = true;
    boolean checkShowAll = false;
    public static TextView tv_allReview;
    public static ImageView ic_downArrow, ic_downArrow_readCmt;
    boolean isLoading = false;

    Button btnBack;
    public static ComboDetailFragment instance = null;

    public static ComboDetailFragment getInstance() {
        if (instance == null) {
            instance = new ComboDetailFragment();
        }
        return instance;
    }

    private ShowCommentAdapter showCommentAdapter;
    private LinearLayoutManager linearLayoutManager;
    private ArrayList<ShowCommentModel> lstModel = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_combo_detail, container, false);
        recyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
        recyclerView_related = (RecyclerView) view.findViewById(R.id.recyclerView_related);
        comboAdapter = new ComboAdapter(comboList);

        rcvShowCommentCombo = view.findViewById(R.id.rcv_show_cmt_combo);
        showCommentAdapter = new ShowCommentAdapter(getContext(), lstModel);
        ComboDetailFragment comboDetailFragment = ComboDetailFragment.getInstance();
        linearLayoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false);
        populateData();
        rcvShowCommentCombo.setLayoutManager(linearLayoutManager);
        rcvShowCommentCombo.setAdapter(showCommentAdapter);
        rcvShowCommentCombo.hasFixedSize();


        btnBack = (Button) view.findViewById(R.id.btnBack);
        img_cover = (ImageView) view.findViewById(R.id.img_cover);
        tvDes = view.findViewById(R.id.tvDes);
        tvTitle = view.findViewById(R.id.tvTitle);
        tvPrice = view.findViewById(R.id.tvPrice);
//        rating = view.findViewById(R.id.ln_rating);
        write_cmt = view.findViewById(R.id.txt_write_cmt);
        tv_allReview = view.findViewById(R.id.tv_all_review_combo);
        ic_downArrow = view.findViewById(R.id.ic_down_arrow_combo);
        ic_downArrow_readCmt = view.findViewById(R.id.ic_down_arrow_readCmt);

        write_cmt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toRate();
            }
        });


        relativeShowCmtCombo = view.findViewById(R.id.relative_show_cmt_combo);
        btnReadCmt = (TextView) view.findViewById(R.id.btn_readCmt);
        btnReadCmt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                click_cmt = !click_cmt;
                if (click_cmt) {
                    relativeShowCmtCombo.setVisibility(View.GONE);
                    btnReadCmt.setText("Read comments");
                    ic_downArrow_readCmt.setRotation(0);


                } else {
                    relativeShowCmtCombo.setVisibility(View.VISIBLE);
                    btnReadCmt.setText("Hide comments");
                    ic_downArrow_readCmt.setRotation(180);


                }
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity mainActivity = (MainActivity) getActivity();
                mainActivity.backFromSubView(MainActivity.currentTab);
            }
        });

        btnAllReview = (LinearLayout) view.findViewById(R.id.btn_all_review_combo);
        btnAllReview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                checkShowAll = !checkShowAll;
                if (checkShowAll) {
                    tv_allReview.setText("Show Less");
                    ic_downArrow.setRotation(-90f);
                    loadMore();
                } else {
                    tv_allReview.setText("All Review");
                    ic_downArrow.setRotation(90);
                    loadLess();
                }
            }
        });
        initScrollListener();

        comboAdapter = new ComboAdapter(comboList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext(), linearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(comboAdapter);

        relatedComboAdapter = new RelatedComboAdapter(relatedCombo);
        LinearLayoutManager linearLayoutManager_related= new LinearLayoutManager(getContext(), linearLayoutManager.HORIZONTAL, false);
        recyclerView_related.setLayoutManager(linearLayoutManager_related);
        recyclerView_related.setAdapter(relatedComboAdapter);
        return view;
    }

    private void populateData() {
        int i = 0;
        while (i < 3) {
            lstModel.add(new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái", 3, "21-08-2020", "2:20"));
            i++;
        }
    }

    private void loadLess() {
        lstModel.clear();
        lstModel.add(new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái", 3, "21-08-2020", "2:20"));
        lstModel.add(new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái", 3, "21-08-2020", "2:20"));
        lstModel.add(new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái", 3, "21-08-2020", "2:20"));
        Collections.reverse(lstModel);
        showCommentAdapter = new ShowCommentAdapter(getContext(), lstModel);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);// hien thij theo chieu doc
        layoutManager.setReverseLayout(false); // doi chieu
        rcvShowCommentCombo.setLayoutManager(layoutManager);
        rcvShowCommentCombo.setAdapter(showCommentAdapter);
        showCommentAdapter.notifyDataSetChanged();
    }

    private void initScrollListener() {
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();

                if (!isLoading) {
                    if (linearLayoutManager != null && linearLayoutManager.findLastCompletelyVisibleItemPosition() == lstModel.size() - 1) {
                        //bottom of list!
                        More();
                        isLoading = true;
                    }
                }
            }
        });
    }

    private void More() {
        lstModel.add(null);
        showCommentAdapter.notifyItemInserted(lstModel.size() - 1);


        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                lstModel.remove(lstModel.size() - 1);
                int scrollPosition = lstModel.size();
                showCommentAdapter.notifyItemRemoved(scrollPosition);
                int currentSize = scrollPosition;
                int nextLimit = currentSize + 10;

                while (currentSize - 1 < nextLimit) {
                    lstModel.add(new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái", 3, "21-08-2020", "2:20"));
                    currentSize++;
                }
                showCommentAdapter.notifyDataSetChanged();
                isLoading = false;
            }
        }, 2000);
    }

    private void loadMore() {
        comboList.clear();
        lstModel.add(new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái", 3, "21-08-2020", "2:20"));
        lstModel.add(new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái", 3, "21-08-2020", "2:20"));
        lstModel.add(new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái", 3, "21-08-2020", "2:20"));
        lstModel.add(new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái", 3, "21-08-2020", "2:20"));
        lstModel.add(new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái", 3, "21-08-2020", "2:20"));
        lstModel.add(new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái", 3, "21-08-2020", "2:20"));
        lstModel.add(new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái", 3, "21-08-2020", "2:20"));
        lstModel.add(new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái", 3, "21-08-2020", "2:20"));
        lstModel.add(new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái", 3, "21-08-2020", "2:20"));
        lstModel.add(new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái", 3, "21-08-2020", "2:20"));
        lstModel.add(new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái", 3, "21-08-2020", "2:20"));
        lstModel.add(new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái", 3, "21-08-2020", "2:20"));
        lstModel.add(new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái", 3, "21-08-2020", "2:20"));
        lstModel.add(new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái", 3, "21-08-2020", "2:20"));
        lstModel.add(new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái", 3, "21-08-2020", "2:20"));
        lstModel.add(new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái", 3, "21-08-2020", "2:20"));
        lstModel.add(new ShowCommentModel(R.drawable.avatar_user, "Shop ABC", "Điểm danh những con người ăn chè đậu đỏ năm ngoái", 3, "21-08-2020", "2:20"));
        Collections.reverse(lstModel);
        comboAdapter = new ComboAdapter(comboList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false); //viet tat
        rcvShowCommentCombo.setLayoutManager(layoutManager);
        rcvShowCommentCombo.setAdapter(showCommentAdapter);
        showCommentAdapter.notifyDataSetChanged();
    }

    private void toRate() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

        LayoutInflater inflater = LayoutInflater.from(getContext());
        final View dialogView = inflater.inflate(R.layout.rating_dialog, null);
        TextView txt_cancel = dialogView.findViewById(R.id.txt_cancel);
        final RatingBar rb_rating = dialogView.findViewById(R.id.rb_rating);
        final TextView txt_sendCmt = dialogView.findViewById(R.id.txt_sendCmt);
        final EditText txt_content_cmt = dialogView.findViewById(R.id.txt_content_cmt);

        builder.setView(dialogView);

        final AlertDialog dialog = builder.create();
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
//
//        LinearLayout star5, star4, star3, star2;
//
//        star2 = (LinearLayout) dialogView.findViewById(R.id.ln_rating2);
//        star3 = (LinearLayout) dialogView.findViewById(R.id.ln_rating3);
//        star4 = (LinearLayout) dialogView.findViewById(R.id.ln_rating4);
//        star5 = (LinearLayout) dialogView.findViewById(R.id.ln_rating5);
//
//        star2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(getContext(), "Thank you for your rating!!", Toast.LENGTH_SHORT).show();
//                getActivity().getWindow()
//                        .setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
//                dialog.dismiss();
//            }
//        });
//
//        star3.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(getContext(), "Thank you for your rating!!", Toast.LENGTH_SHORT).show();
//                getActivity().getWindow()
//                        .setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
//                dialog.dismiss();
//            }
//        });
//
//        star4.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(getContext(), "Thank you for your rating!!", Toast.LENGTH_SHORT).show();
//                getActivity().getWindow()
//                        .setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
//                dialog.dismiss();
//            }
//        });
//
//        star5.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(getContext(), "Thank you for your rating!!", Toast.LENGTH_SHORT).show();
//                getActivity().getWindow()
//                        .setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
//                dialog.dismiss();
//            }
//        });

//                dialog.getWindow().setGravity(Gravity.BOTTOM);
        dialog.show();
        txt_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        txt_sendCmt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lstModel.add(new ShowCommentModel(R.drawable.avatar, "ADjsf", txt_content_cmt.getText().toString(), rb_rating.getRating(), "23-3-3055", "56:09"));
                Collections.reverse(lstModel);
                comboAdapter.notifyDataSetChanged();
                dialog.dismiss();
            }
        });
    }


    @Override
    public void constructorView() {
    }

    @Override
    public void setOnClick() {
    }

    @Override
    public void loadDateView() {
    }

    public void refresh(int id) {


        new LoadDataAsyncTask(id).execute();
    }

    private class LoadDataAsyncTask extends AsyncTask {
        String url = Connector.rootURL + "productcombo/SearchByIdMobile";
        String responseString = null;
        Gson gson = new Gson();
        ComboID comboID = new ComboID();
        public int id;

        public LoadDataAsyncTask(int id) {
            this.id = id;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            comboID.setId(id); // chỗ này truyền vào ID
        }

        @Override
        protected Object doInBackground(Object[] objects) {
            try {
                responseString = Connector.doPostRequest(url, gson.toJson(comboID));
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            Gson gson = new Gson();
            try {
                ProductCombo combo = gson.fromJson(responseString, ProductCombo.class);
                img_cover.setImageBitmap(ImageUtil.bitmapFromBase64(combo.getImage()));

                tvDes.setText("Thực phẩm sạch! Ăn quá đã");
                tvTitle.setText((combo.getName() + " - cửa hàng xyz").toUpperCase());
                tvPrice.setText(String.format("%,d", Long.parseLong(120000 + "") + "đ/set"));

                // TopProduct topProduct = gson.fromJson(responseString, TopProduct.class);
                //  img_cover.setImageBitmap(ImageUtil.bitmapFromBase64(topProduct.getImage()));
                //   img_cover.setScaleType(ImageView.ScaleType.FIT_XY);
            } catch (Exception e) {
            }
        }
    }
}
