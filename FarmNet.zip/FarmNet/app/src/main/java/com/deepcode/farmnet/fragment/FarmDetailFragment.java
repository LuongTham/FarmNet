package com.deepcode.farmnet.fragment;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.adapter.CategoryTextAdapter;
import com.deepcode.farmnet.adapter.FarmHeaderAdapter;
import com.deepcode.farmnet.adapter.GroupTextAdapter;
import com.deepcode.farmnet.adapter.ListProductFarmAdapter;
import com.deepcode.farmnet.adapter.ListProductFinalHomeAdapter;
import com.deepcode.farmnet.adapter.ListProductHomeAdapter;
import com.deepcode.farmnet.bean.Cart;
import com.deepcode.farmnet.bean.Category;
import com.deepcode.farmnet.core.Connector;
import com.deepcode.farmnet.core.Data;
import com.deepcode.farmnet.core.FarmNetStatic;
import com.deepcode.farmnet.core.URL_FarmNet;
import com.deepcode.farmnet.extend.RecyclerItemClickListener;
import com.deepcode.farmnet.model.CategoryFarmId;
import com.deepcode.farmnet.model.CheckButton;
import com.deepcode.farmnet.model.FarmModel;
import com.deepcode.farmnet.model.ProductModel;
import com.deepcode.farmnet.model.ProductModelReal;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FarmDetailFragment extends BaseFragment
{
    @Override
    public void constructorView()
    {
    }

    @Override
    public void setOnClick()
    {
    }

    @Override
    public void loadDateView()
    {
    }
    FarmHeaderAdapter mRcvAdapter;
    RecyclerView recyclerView;
    List<FarmModel> farmModelList = new ArrayList<>();
    ListProductFarmAdapter listProductFarmAdapter;
    CategoryTextAdapter categoryTextAdapter;
    RecyclerView recyclerViewProduct;
    RecyclerView recyclerViewCategory;
    List<Category> categoryList = new ArrayList<>();
    List<ProductModelReal> productModelRealList = new ArrayList<>();
    long farmId = 0;
    long categoryId = 0;



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        super.onCreateView(inflater,container,savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_farm_detail, container, false);

        recyclerView = (RecyclerView)view.findViewById(R.id.recyclerView);
        recyclerViewCategory = (RecyclerView)view.findViewById(R.id.recyclerCategory);
        recyclerViewProduct = (RecyclerView)view.findViewById(R.id.recyclerViewProduct);
       // btn_addToCart = (TextView) view.findViewById(R.id.btn_addToCart);

        new FarmDetailFragment.LoadDataFirstProductAsyncTask().execute();

//        recyclerView.addOnItemTouchListener(
//                new RecyclerItemClickListener(getContext(), recyclerView ,new RecyclerItemClickListener.OnItemClickListener() {
//                    @Override public void onItemClick(View view, int position) {
//                        //    Toast.makeText(getContext(), "Click "+Data.farmModelList.get(position).getName(), Toast.LENGTH_SHORT).show();
//
//                        farmId = Data.farmModelList.get(position).getFarmID();
//                        categoryId = Data.categoryList.get(0).getCategoryID();
//                        Data.positionCategoryCurent = 0;
//                        categoryTextAdapter.notifyDataSetChanged();
//
//                        new FarmDetailFragment.LoadDataProductAsyncTask().execute();
//                    }
//
//                    @Override public void onLongItemClick(View view, int position) {
//                        // do whatever
//                    }
//                })
//        );


        recyclerViewCategory.addOnItemTouchListener(
                new RecyclerItemClickListener(getContext(), recyclerViewCategory ,new RecyclerItemClickListener.OnItemClickListener() {
                    @Override public void onItemClick(View view, int position) {
                        //    Toast.makeText(getContext(), "Click "+Data.categoryList.get(position).getName(), Toast.LENGTH_SHORT).show();
                        if (farmId==0)
                        {
                            farmId=Data.farmModelList.get(0).getFarmID();
                        }
                        categoryId = Data.categoryList.get(position).getCategoryID();
                        Data.positionCategoryCurent = position;
                        categoryTextAdapter.notifyDataSetChanged();

                        new FarmDetailFragment.LoadDataProductAsyncTask().execute();
                    }

                    @Override public void onLongItemClick(View view, int position) {
                        // do whatever
                    }
                })
        );



        return view;
    }


    private  void refresh()
    {



    }
    class  LoadDataFirstProductAsyncTask extends AsyncTask {

        String url = Connector.rootURL + "farm/SearchAllMobile";
        String responseString = null;
        Gson gson = new Gson();
        FarmModel farmRequest = new FarmModel();

        String url1 = Connector.rootURL + "category/GetAll";
        String responseString1 = null;
        Gson gson1 = new Gson();
        Category categoryRequest = new Category();

        String url2 = Connector.rootURL+ "product/ByCategoryAndFarm";
        String responseString2 = null;

        CategoryFarmId cateFarmId = new CategoryFarmId();

        @Override
        protected void onPreExecute() {
            super.onPreExecute();


        }

        @Override
        protected Object doInBackground(Object[] objects) {

            try
            {
                responseString = Connector.doPostRequest(url, gson.toJson(farmRequest));
                Gson gson = new Gson();
                TypeToken<List<FarmModel>> token = new TypeToken<List<FarmModel>>() {
                };
                farmModelList = gson.fromJson(responseString, token.getType());
                System.out.println("11farmModelList " + farmModelList.get(0).getFarmID());
                cateFarmId.setFarmId(farmModelList.get(0).getFarmID());

            } catch (IOException e) {
                e.printStackTrace();
            }

            try
            {
                responseString1 = Connector.doPostRequest(url1, gson1.toJson(categoryRequest));
                Gson gson1 = new Gson();
                TypeToken<List<Category>> token1 = new TypeToken<List<Category>>() {
                };
                categoryList = gson1.fromJson(responseString1, token1.getType());
                System.out.println("11categoryList " + categoryList.get(0).getCategoryID());
                cateFarmId.setCategoryId(categoryList.get(0).getCategoryID());



            } catch (IOException e) {
                e.printStackTrace();
            }

            try
            {
                Gson gson2 = new Gson();
                responseString2 = Connector.doPostRequest(url2,gson2.toJson(cateFarmId));
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);



            Data.farmModelList=farmModelList;
            mRcvAdapter = new FarmHeaderAdapter(farmModelList);
            LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
            layoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
            recyclerView.setLayoutManager(layoutManager);
            recyclerView.setAdapter(mRcvAdapter);

            Data.categoryList=categoryList;
            categoryTextAdapter = new CategoryTextAdapter(categoryList, getContext());
            LinearLayoutManager layoutManager2 = new LinearLayoutManager(getContext());
            layoutManager2.setOrientation(LinearLayoutManager.HORIZONTAL);
            recyclerViewCategory.setLayoutManager(layoutManager2);
            recyclerViewCategory.setAdapter(categoryTextAdapter);



            Gson gson2 = new Gson();

            TypeToken<List<ProductModelReal>> token2 = new TypeToken<List<ProductModelReal>>() {};
            List<ProductModelReal> productModelRealList = new ArrayList<>();

            try {
                productModelRealList = gson2.fromJson(responseString2, token2.getType());
            } catch (Exception e) {
                System.out.println("Error " + e.getMessage());
            }

            if (productModelRealList != null){


                listProductFarmAdapter = new ListProductFarmAdapter(productModelRealList,(MainActivity) getContext());
                LinearLayoutManager layoutManager3 = new LinearLayoutManager(getContext());
                layoutManager3.setOrientation(LinearLayoutManager.VERTICAL);
                recyclerViewProduct.setLayoutManager(layoutManager3);
                recyclerViewProduct.setAdapter(listProductFarmAdapter);
            }



        }
    }


    class  LoadDataProductAsyncTask extends AsyncTask {

        String url = Connector.rootURL+ "product/ByCategoryAndFarm";
        String responseString = null;
        Gson gson = new Gson();
        CategoryFarmId cateFarmId = new CategoryFarmId();

        @Override
        protected void onPreExecute() {
            super.onPreExecute();


            cateFarmId.setCategoryId(categoryId);
            cateFarmId.setFarmId(farmId);
        }

        @Override
        protected Object doInBackground(Object[] objects) {
            try
            {
                responseString = Connector.doPostRequest(url,gson.toJson(cateFarmId));
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);


            Gson gson = new Gson();

            TypeToken<List<ProductModelReal>> token = new TypeToken<List<ProductModelReal>>() {};


            try {
                productModelRealList = gson.fromJson(responseString, token.getType());
            } catch (Exception e) {
                System.out.println("Error " + e.getMessage());
            }

            if (productModelRealList != null){


                listProductFarmAdapter = new ListProductFarmAdapter(productModelRealList,(MainActivity) getActivity());
                LinearLayoutManager layoutManager3 = new LinearLayoutManager(getContext());
                layoutManager3.setOrientation(LinearLayoutManager.VERTICAL);
                recyclerViewProduct.setLayoutManager(layoutManager3);
                recyclerViewProduct.setAdapter(listProductFarmAdapter);
                Log.e("listSize", String.valueOf(productModelRealList.size()));

            }

        }
    }
}
