package com.deepcode.farmnet.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.deepcode.farmnet.R;
import com.deepcode.farmnet.fragment.BaseFragment;
import com.deepcode.farmnet.model.CategoryModel;
import com.deepcode.farmnet.model.ProductModel;

import java.util.ArrayList;
import java.util.List;

public class SuggestionSearchAdapter extends BaseAdapter {

    private final Context mContext;
    private List<ProductModel> productModelList = new ArrayList<>();
    private LayoutInflater layoutInflater;


    public SuggestionSearchAdapter(Context mContext, List<ProductModel> productModelList) {
        this.mContext = mContext;
        this.productModelList = productModelList;
        layoutInflater = LayoutInflater.from(mContext);
    }

    @Override
    public int getCount() {
        return 10;
    }

    @Override
    public Object getItem(int position) {
        return productModelList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null)
        {
            LayoutInflater layoutInflater = LayoutInflater.from(mContext);
            convertView = layoutInflater.inflate(R.layout.suggestion_item, null);
            holder = new ViewHolder();
            holder.itemText = (TextView) convertView.findViewById(R.id.tvSuggestion);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        return  convertView;

    }

    static class ViewHolder
    {

        TextView itemText;
    }
}
