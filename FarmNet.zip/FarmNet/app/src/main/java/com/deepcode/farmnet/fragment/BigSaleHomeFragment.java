package com.deepcode.farmnet.fragment;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.adapter.HeaderHomeAdapter;
import com.deepcode.farmnet.adapter.MediumSaleHomeAdapter;
import com.deepcode.farmnet.bean.TopProduct;
import com.deepcode.farmnet.core.Connector;
import com.deepcode.farmnet.core.ImageUtil;
import com.deepcode.farmnet.model.ProductModel;
import com.deepcode.farmnet.request.TopRequest;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class BigSaleHomeFragment  extends  BaseFragment{
    @Override
    public void constructorView() {

    }

    @Override
    public void setOnClick() {

    }

    @Override
    public void loadDateView() {

    }

    ImageView imageView;
    MediumSaleHomeAdapter mediumSaleHomeAdapter;
    RecyclerView recyclerView;
    List<ProductModel> listProductsale = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);


        View view = inflater.inflate(R.layout.fragment_home_mediumsale, container, false);
//
//        imageView = (ImageView)view.findViewById(R.id.imgView);
//        imageView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                MainActivity.showTabProductDetail();
//            }
//        });
        recyclerView = (RecyclerView)view.findViewById(R.id.rvlistproduct);

        new LoadDataAsyncTask().execute();

        return  view;

    }


    class  LoadDataAsyncTask extends AsyncTask {
        String url = Connector.rootURL+ "topproduct/SearchByTypeOnMobile";
        String responseString = null;
        Gson gson = new Gson();
        TopRequest topRequest = new TopRequest();

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            topRequest.setType(1);
        }

        @Override
        protected Object doInBackground(Object[] objects) {
            try
            {
                responseString = Connector.doPostRequest(url,gson.toJson(topRequest));
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            Gson gson = new Gson();
            TypeToken<List<TopProduct>> token = new TypeToken<List<TopProduct>>() {};
            List<TopProduct> topProductList = new ArrayList<>();

            if(responseString != null)
            {
                System.out.println("responnnnn: "+ responseString);


                try{
                    topProductList = gson.fromJson(responseString, token.getType());
                    mediumSaleHomeAdapter = new MediumSaleHomeAdapter(topProductList);
                    LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
                    recyclerView.setLayoutManager(linearLayoutManager);
                    recyclerView.setAdapter(mediumSaleHomeAdapter);

                }catch (Exception ex)
                {

                }

            }

            //  boolean check = false;
            for(TopProduct topProduct: topProductList)
            {

                System.out.println("Category:"+ topProduct.getProductName());
//                if(!check)
//                {
//                    imageView.setImageBitmap(ImageUtil.bitmapFromBase64(topProduct.getImage()));
//
//                    check = true;
//                }
            }
        }
    }
}
