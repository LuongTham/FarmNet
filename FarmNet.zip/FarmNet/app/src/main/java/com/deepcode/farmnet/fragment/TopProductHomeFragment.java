package com.deepcode.farmnet.fragment;

import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.deepcode.farmnet.R;
import com.deepcode.farmnet.bean.TopProduct;
import com.deepcode.farmnet.core.Connector;
import com.deepcode.farmnet.core.ImageUtil;
import com.deepcode.farmnet.request.TopRequest;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class TopProductHomeFragment  extends  BaseFragment{
    @Override
    public void constructorView() {

    }

    @Override
    public void setOnClick() {

    }

    @Override
    public void loadDateView() {

    }

    CircleImageView imageView1;
    CircleImageView imageView2;
    CircleImageView imageView3;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
         super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_home_topproduct, container, false);
        imageView1 = (CircleImageView)view.findViewById(R.id.imgIcon1);
        imageView2 = (CircleImageView)view.findViewById(R.id.imgIcon2);
        imageView3 = (CircleImageView)view.findViewById(R.id.imgIcon3);
        imageView1.setBorderColor(Color.GREEN);
        imageView2.setBorderColor(Color.GREEN);
        imageView3.setBorderColor(Color.GREEN);

        new LoadDataAsyncTask().execute();
        return  view;
    }

    class  LoadDataAsyncTask extends AsyncTask {
        String url = Connector.rootURL+ "topproduct/SearchByTypeOnMobile";
        String responseString = null;
        Gson gson = new Gson();
        TopRequest topRequest = new TopRequest();

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            topRequest.setType(3);
        }

        @Override
        protected Object doInBackground(Object[] objects) {
            try
            {
                responseString = Connector.doPostRequest(url,gson.toJson(topRequest));
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);

            System.out.println("responseString:"+ responseString);

            Gson gson = new Gson();
            TypeToken<List<TopProduct>> token = new TypeToken<List<TopProduct>>() {};
            List<TopProduct> topProductList = gson.fromJson(responseString, token.getType());

            boolean check1 = false;
            boolean check2 = false;
            boolean check3 = false;

            for(TopProduct topProduct: topProductList)
            {

                System.out.println("Category:"+ topProduct.getProductName());
                if(!check1)
                {
                    imageView1.setImageBitmap(ImageUtil.bitmapFromBase64(topProduct.getImage()));

                    check1 = true;
                    continue;
                }
                if(!check2)
                {
                    imageView2.setImageBitmap(ImageUtil.bitmapFromBase64(topProduct.getImage()));

                    check2 = true;
                    continue;
                }

                if(!check3)
                {
                    imageView3.setImageBitmap(ImageUtil.bitmapFromBase64(topProduct.getImage()));

                    check3 = true;
                }
            }
        }
    }
}
