package com.deepcode.farmnet.adapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.model.NotificationModel;
import com.deepcode.farmnet.model.OrderStatus;
import com.deepcode.farmnet.model.UpdateOrder;
import java.util.List;

public class NotificationAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>
{
    public List<NotificationModel> notificationModelList;
    public List<OrderStatus> orderStatusList;
    public List<UpdateOrder> updateOrderList;

    public NotificationAdapter(List<NotificationModel> notificationModelList , List<UpdateOrder> updateOrderList, List<OrderStatus> orderStatusList)
    {
        this.notificationModelList = notificationModelList;
        this.updateOrderList = updateOrderList;
        this.orderStatusList = orderStatusList;
    }
    public NotificationAdapter()
    {

    }
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        switch (viewType)
        {
            case  0:
                LayoutInflater inflater1 = LayoutInflater.from(parent.getContext());
                View view1 = inflater1.inflate(R.layout.notification_sale_item, parent, false);
                return new ViewHolderNotification_Sale(view1);

            case 1:

                LayoutInflater inflater2 = LayoutInflater.from(parent.getContext());
                View view2 = inflater2.inflate(R.layout.notification_live_item, parent, false);
                return new ViewHolderNotification_Live(view2);

            case 2:
                LayoutInflater inflater3 = LayoutInflater.from(parent.getContext());
                View view3 = inflater3.inflate(R.layout.notification_action_item, parent, false);
                return new ViewHolderNotification_Action(view3);
            case 3:
                LayoutInflater inflater4 = LayoutInflater.from(parent.getContext());
                View view4 = inflater4.inflate(R.layout.notification_update_item, parent, false);
                return new ViewHolderNotification_Update(view4);

            case 4:
                LayoutInflater inflater5 = LayoutInflater.from(parent.getContext());
                View view5 = inflater5.inflate(R.layout.notification_update_label, parent, false);
                return new ViewHolderNotification_Update_Label(view5);

            case 5:
                LayoutInflater inflater6 = LayoutInflater.from(parent.getContext());
                View view6 = inflater6.inflate(R.layout.notification_order_status, parent, false);
                return new ViewHolderNotification_Order_Status(view6);

        }
        return null;
    }
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position)
    {
    }
    @Override
    public int getItemCount()
    {
        return notificationModelList.size() + orderStatusList.size()+ updateOrderList.size();
    }
    @Override
    public int getItemViewType(int position)
    {
        if(position ==0)
        {
            return 0;
        }else if(position==1)
        {
            return  1;
        }else if(position==2)
        {
            return  2;
        }else  if(position ==3)
        {
            return  3;
        }else if(position == 4)
        {
            return  4;
        }else
        {
            return  5;
        }
    }
    class ViewHolderNotification_Update extends RecyclerView.ViewHolder
    {

        public ViewHolderNotification_Update(@NonNull View itemView) {
            super(itemView);

        }
    }
    class ViewHolderNotification_Live extends RecyclerView.ViewHolder
    {
        public ViewHolderNotification_Live(@NonNull View itemView) {
            super(itemView);
        }
    }
    class ViewHolderNotification_Action extends RecyclerView.ViewHolder
    {
        public ViewHolderNotification_Action(@NonNull View itemView)
        {
            super(itemView);
        }
    }
    class ViewHolderNotification_Sale extends RecyclerView.ViewHolder{
        public ViewHolderNotification_Sale(@NonNull View itemView) {
            super(itemView);
        }
    }

    class ViewHolderNotification_Update_Label extends RecyclerView.ViewHolder{
        public ViewHolderNotification_Update_Label(@NonNull View itemView) {
            super(itemView);
        }
    }

    class ViewHolderNotification_Order_Status extends RecyclerView.ViewHolder{
        public ViewHolderNotification_Order_Status(@NonNull View itemView) {
            super(itemView);
        }
    }


}

