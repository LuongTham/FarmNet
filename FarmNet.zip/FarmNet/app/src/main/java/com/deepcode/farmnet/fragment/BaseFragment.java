package com.deepcode.farmnet.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public abstract class BaseFragment extends Fragment {
    public  abstract  void constructorView();
    public abstract  void setOnClick();
    public  abstract  void loadDateView();
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        constructorView();
        loadDateView();
        setOnClick();
        return super.onCreateView(inflater, container, savedInstanceState);
    }

}
