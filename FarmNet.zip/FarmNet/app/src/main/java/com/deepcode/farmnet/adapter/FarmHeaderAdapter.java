package com.deepcode.farmnet.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.R;
import com.deepcode.farmnet.core.ImageUtil;
import com.deepcode.farmnet.model.FarmModel;
import com.deepcode.farmnet.model.ProductModel;

import java.util.List;

public class FarmHeaderAdapter extends RecyclerView.Adapter<FarmHeaderAdapter.RecyclerViewHolder>
{

    List<FarmModel> farmModelList;
    public FarmHeaderAdapter(List<FarmModel> list)
    {
        farmModelList = list;
    }
    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.farm_header_item, parent, false);
        return new RecyclerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position)
    {
        FarmModel farmModel = farmModelList.get(position);
        holder.txtFarm.setText(farmModel.getName());
        holder.imageView.setImageBitmap(ImageUtil.bitmapFromBase64(farmModel.getImage()));



    }

    @Override
    public int getItemCount()
    {
        return farmModelList.size();
    }
    public class RecyclerViewHolder extends RecyclerView.ViewHolder
    {
        TextView txtTitle;
        TextView txtFarm;
        TextView txtContent;
        ImageView imageView;


        public RecyclerViewHolder(View itemView)
        {
            super(itemView);
            // txtUserName = (TextView) itemView.findViewById(R.id.user_name);

            txtTitle = (TextView) itemView.findViewById(R.id.tvBrand);
            txtFarm = (TextView)itemView.findViewById(R.id.tvShop);
            txtContent = (TextView)itemView.findViewById(R.id.tvOpenTime);
            imageView = (ImageView)itemView.findViewById(R.id.imgIcon);


        }
    }
}
