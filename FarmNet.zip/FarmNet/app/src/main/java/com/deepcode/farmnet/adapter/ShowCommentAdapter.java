package com.deepcode.farmnet.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.model.ShowCommentModel;

import java.util.ArrayList;

public class ShowCommentAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context context;
    private ArrayList<ShowCommentModel> lstModel = new ArrayList<ShowCommentModel>();

    public ShowCommentAdapter(Context context, ArrayList<ShowCommentModel> lstModel) {
        this.context = context;
        this.lstModel = lstModel;
    }

    private final int VIEW_TYPE_ITEM = 0;
    private final int VIEW_TYPE_LOADING = 1;

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
      //  View view = LayoutInflater.from(context).inflate(R.layout.item_show_comment, parent, false);
        if (viewType == VIEW_TYPE_ITEM) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_show_comment, parent, false);
            return new ViewHolder(view);
        } else {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_loading, parent, false);
            return new LoadingViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof ViewHolder) {

            populateItemRows((ViewHolder) holder, position);
        } else if (holder instanceof LoadingViewHolder) {
            showLoadingView((LoadingViewHolder) holder, position);
        }
    }


    @Override
    public int getItemCount() {
        return lstModel == null ? 0 : lstModel.size();
    }
    @Override
    public int getItemViewType(int position) {
        return lstModel.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView avatar;
        private TextView name;
        private TextView content;
        private RatingBar ratingBar;
        private TextView day;
        private TextView time;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            avatar = itemView.findViewById(R.id.avt_show_comment);
            name = itemView.findViewById(R.id.txt_name);
            content = itemView.findViewById(R.id.txt_content);
            ratingBar = itemView.findViewById(R.id.simpleRatingBar);
            day = itemView.findViewById(R.id.txt_day);
            time = itemView.findViewById(R.id.txt_time);
        }
    }

    public class LoadingViewHolder extends RecyclerView.ViewHolder {
        ProgressBar progressBar;

        public LoadingViewHolder(@NonNull View itemView) {
            super(itemView);
            progressBar = itemView.findViewById(R.id.progressBar);
        }
    }

    private void showLoadingView(LoadingViewHolder holder, int position) {
        //ProgressBar would be displayed

    }

    private void populateItemRows(ViewHolder holder, int position) {

        ShowCommentModel showCommentModel = lstModel.get(position);
        holder.name.setText(showCommentModel.getName());
        holder.content.setText(showCommentModel.getContent());
        Glide.with(context).load(showCommentModel.getAvatar()).into(holder.avatar);
        holder.ratingBar.setRating(showCommentModel.getRatingStar());
        holder.day.setText(showCommentModel.getDate());
        holder.time.setText(showCommentModel.getTime());
    }

}
