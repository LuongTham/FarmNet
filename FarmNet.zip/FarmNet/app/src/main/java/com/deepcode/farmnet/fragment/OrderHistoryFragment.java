package com.deepcode.farmnet.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.adapter.ListMessageAdapter;
import com.deepcode.farmnet.adapter.ListProductFinalHomeAdapter;
import com.deepcode.farmnet.adapter.OrderHistoryAdapter;
import com.deepcode.farmnet.core.Data;
import com.deepcode.farmnet.model.MessageModel;
import com.deepcode.farmnet.model.OrderHistoryModel;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class OrderHistoryFragment extends  BaseFragment
{
    @Override
    public void constructorView() {

    }

    @Override
    public void setOnClick() {

    }

    @Override
    public void loadDateView() {

    }
    RecyclerView recyclerView;

    private  void loadData()
    {


    }

    Button btnBack;
    public static RelativeLayout rl_all;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_orderhistory, container, false);
        Data.onOrderHistoryFragment = true;

        btnBack = (Button)view.findViewById(R.id.btnBack);
        rl_all = view.findViewById(R.id.rl_all1);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });

        List<OrderHistoryModel> list = new ArrayList<>();
        String name;
        for(int i = 0; i<=10;i++)
        {
            list.add(new OrderHistoryModel("Đơn hàng số 1", "Kim Mã - Ba Đình", "10:00 17/4", true));
            list.add(new OrderHistoryModel("Đơn hàng số 2", "Kim Mã - Ba Đình", "10:00 17/4", false));
            list.add(new OrderHistoryModel("Đơn hàng số 3", "Kim Mã - Ba Đình", "10:00 17/4", true));
            list.add(new OrderHistoryModel("Đơn hàng số 4", "Kim Mã - Ba Đình", "10:00 17/4", false));
            list.add(new OrderHistoryModel("Đơn hàng số 5", "Kim Mã - Ba Đình", "10:00 17/4", true));
        }

        recyclerView = (RecyclerView)view.findViewById(R.id.recyLSGD);


        OrderHistoryAdapter adapter = new OrderHistoryAdapter(list, getContext());
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);


        return view;
    }

}
