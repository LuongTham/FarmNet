package com.deepcode.farmnet.adapter;

import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.R;
import com.deepcode.farmnet.model.Combo;
import com.deepcode.farmnet.model.RelatedComboModel;

import java.util.List;

import static com.deepcode.farmnet.R.*;


public class RelatedComboAdapter extends RecyclerView.Adapter<RelatedComboAdapter.RecyclerViewHolder> {
    List<RelatedComboModel> listProduct;
    public RelatedComboAdapter(List<RelatedComboModel> list)
    {
        listProduct = list;
    }
    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(layout.item_related_combo, parent, false);
        return new RecyclerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position) {



    }

    @Override
    public int getItemCount() {
        return 10;
    }

    public class RecyclerViewHolder extends RecyclerView.ViewHolder {
        ImageView imgIcon;

        public RecyclerViewHolder(View view) {
            super(view);
            imgIcon = view.findViewById(id.imgIcon);

        }
    }
}
