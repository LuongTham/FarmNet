package com.deepcode.farmnet.request;

public class ProductID {

    private  long id;

    public long getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
