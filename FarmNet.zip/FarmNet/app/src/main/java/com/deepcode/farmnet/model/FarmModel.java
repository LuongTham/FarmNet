package com.deepcode.farmnet.model;

import java.util.Date;
import java.util.List;

public class FarmModel {
    private long farmID;
    private String name;
    private String address;
    private String city;
    private String image;
    private String phone;
    private String owner;
    private String account;
    private String password;
    private boolean top;
    private int status;
    private Date createdDate;
    private boolean delete;
    private List<Rating> listRatings;


    public long getFarmID() {
        return farmID;
    }

    public void setFarmID(long farmID) {
        this.farmID = farmID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isTop() {
        return top;
    }

    public void setTop(boolean top) {
        this.top = top;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public boolean isDelete() {
        return delete;
    }

    public void setDelete(boolean delete) {
        this.delete = delete;
    }

    public List<Rating> getListRatings() {
        return listRatings;
    }

    public void setListRatings(List<Rating> listRatings) {
        this.listRatings = listRatings;
    }
}
