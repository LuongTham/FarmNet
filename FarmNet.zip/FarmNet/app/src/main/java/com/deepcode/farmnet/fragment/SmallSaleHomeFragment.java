package com.deepcode.farmnet.fragment;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.deepcode.farmnet.MainActivity;
import com.deepcode.farmnet.R;
import com.deepcode.farmnet.adapter.MediumSaleHomeAdapter;
import com.deepcode.farmnet.adapter.SmallSaleHomeAdapter;
import com.deepcode.farmnet.bean.TopProduct;
import com.deepcode.farmnet.core.Connector;
import com.deepcode.farmnet.core.ImageUtil;
import com.deepcode.farmnet.request.TopRequest;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SmallSaleHomeFragment extends BaseFragment {
    @Override
    public void constructorView() {

    }

    @Override
    public void setOnClick() {

    }

    @Override
    public void loadDateView() {

    }

    RelativeLayout rl_small1, rl_small2;
    SmallSaleHomeAdapter smallSaleHomeAdapter;
    RecyclerView recyclerView;

    ImageView imageView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);


        View view = inflater.inflate(R.layout.fragment_home_smallsale, container, false);
        recyclerView = (RecyclerView) view.findViewById(R.id.rcv_smallSale);

//        imageView = (ImageView)view.findViewById(R.id.imgIcon);
//        rl_small1 = view.findViewById(R.id.rl_small1);
//        rl_small2 = view.findViewById(R.id.rl_small2);
//
//        rl_small1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                MainActivity.showTabCombo();
//
//            }
//        });
//
//        rl_small2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                MainActivity.showTabCombo();
//
//            }
//        });

        new LoadDataAsyncTask().execute();

        return view;
    }

    class LoadDataAsyncTask extends AsyncTask {
        String url = Connector.rootURL + "topproduct/SearchByTypeOnMobile";
        String responseString = null;
        Gson gson = new Gson();
        TopRequest topRequest = new TopRequest();

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            topRequest.setType(1);
        }

        @Override
        protected Object doInBackground(Object[] objects) {
            try {
                responseString = Connector.doPostRequest(url, gson.toJson(topRequest));
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);
            Gson gson = new Gson();
            TypeToken<List<TopProduct>> token = new TypeToken<List<TopProduct>>() {
            };
            List<TopProduct> topProductList = new ArrayList<>();

            if (responseString != null) {

                try {
                    topProductList = gson.fromJson(responseString, token.getType());
                    smallSaleHomeAdapter = new SmallSaleHomeAdapter(topProductList);
                    LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
                    recyclerView.setLayoutManager(linearLayoutManager);
                    recyclerView.setAdapter(smallSaleHomeAdapter);


                } catch (Exception ex) {


                }

                boolean check = false;
                for (TopProduct topProduct : topProductList) {
//
//                    System.out.println("Category:" + topProduct.getProductName());
//                    if (!check) {
//                        imageView.setImageBitmap(ImageUtil.bitmapFromBase64(topProduct.getImage()));
//
//                        check = true;
//                    }
                }
            }
        }
    }
}
